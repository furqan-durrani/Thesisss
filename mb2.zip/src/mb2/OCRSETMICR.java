package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class OCRSETMICR extends Structure {
	/** Classification technology */
	public int Classifier;
	/** Deskew image */
	public int DeskewImage;
	/** MAX speckle size */
	public int MaxSpeckleRadius;
	/** MAX vertical gap between group of characters */
	public int MaxVerticalOffset;
	/** Minimum characters group */
	public int MinValidGroup;
	/**
	 * Map non numeric CMC7 symbols + Unknow char replace<br>
	 * C type : char[7]
	 */
	public byte[] SymbolsOutput = new byte[7];
	public OCRSETMICR() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("Classifier", "DeskewImage", "MaxSpeckleRadius", "MaxVerticalOffset", "MinValidGroup", "SymbolsOutput");
	}
	/**
	 * @param Classifier Classification technology<br>
	 * @param DeskewImage Deskew image<br>
	 * @param MaxSpeckleRadius MAX speckle size<br>
	 * @param MaxVerticalOffset MAX vertical gap between group of characters<br>
	 * @param MinValidGroup Minimum characters group<br>
	 * @param SymbolsOutput Map non numeric CMC7 symbols + Unknow char replace<br>
	 * C type : char[7]
	 */
	public OCRSETMICR(int Classifier, int DeskewImage, int MaxSpeckleRadius, int MaxVerticalOffset, int MinValidGroup, byte SymbolsOutput[]) {
		super();
		this.Classifier = Classifier;
		this.DeskewImage = DeskewImage;
		this.MaxSpeckleRadius = MaxSpeckleRadius;
		this.MaxVerticalOffset = MaxVerticalOffset;
		this.MinValidGroup = MinValidGroup;
		if ((SymbolsOutput.length != this.SymbolsOutput.length)) 
			throw new IllegalArgumentException("Wrong array size !");
		this.SymbolsOutput = SymbolsOutput;
	}
	public OCRSETMICR(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends OCRSETMICR implements Structure.ByReference {
		
	};
	public static class ByValue extends OCRSETMICR implements Structure.ByValue {
		
	};
}

