package mb2;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

/**
import com.sun.jna.NativeLibrary;


 */
public class SIZEDOC extends Structure {
	public int length;
	public int width;
	public SIZEDOC() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("length", "width");
	}
	public SIZEDOC(int length, int width) {
		super();
		this.length = length;
		this.width = width;
	}
	public SIZEDOC(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends SIZEDOC implements Structure.ByReference {
		
	};
	public static class ByValue extends SIZEDOC implements Structure.ByValue {
		
	};
}

