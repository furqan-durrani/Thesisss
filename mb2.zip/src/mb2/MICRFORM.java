package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class MICRFORM extends Structure {
	/** 1 or 3 */
	public byte retries;
	/** 1 or 3 */
	public byte font;
	/** 1 or 3 */
	public byte space_detect;
	/** 1 or 3 */
	public byte autom;
	public MICRFORM() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("retries", "font", "space_detect", "autom");
	}
	/**
	 * @param retries 1 or 3<br>
	 * @param font 1 or 3<br>
	 * @param space_detect 1 or 3<br>
	 * @param autom 1 or 3
	 */
	public MICRFORM(byte retries, byte font, byte space_detect, byte autom) {
		super();
		this.retries = retries;
		this.font = font;
		this.space_detect = space_detect;
		this.autom = autom;
	}
	public MICRFORM(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends MICRFORM implements Structure.ByReference {
		
	};
	public static class ByValue extends MICRFORM implements Structure.ByValue {
		
	};
}

