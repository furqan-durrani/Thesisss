package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class WNDFORM extends Structure {
	public int orientation;
	public int type;
	/** meaningless fields if type!=CUSTOM */
	public int unit;
	/** 0 means default */
	public int startx;
	/** 0 means default */
	public int starty;
	/** 0 means default (max. 8, 330 mm) */
	public int lenx;
	/** 0 means default (max. 8, 330 mm) */
	public int leny;
	public WNDFORM() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("orientation", "type", "unit", "startx", "starty", "lenx", "leny");
	}
	/**
	 * @param unit meaningless fields if type!=CUSTOM<br>
	 * @param startx 0 means default<br>
	 * @param starty 0 means default<br>
	 * @param lenx 0 means default (max. 8, 330 mm)<br>
	 * @param leny 0 means default (max. 8, 330 mm)
	 */
	public WNDFORM(int orientation, int type, int unit, int startx, int starty, int lenx, int leny) {
		super();
		this.orientation = orientation;
		this.type = type;
		this.unit = unit;
		this.startx = startx;
		this.starty = starty;
		this.lenx = lenx;
		this.leny = leny;
	}
	public WNDFORM(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends WNDFORM implements Structure.ByReference {
		
	};
	public static class ByValue extends WNDFORM implements Structure.ByValue {
		
	};
}

