package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class BARCODEWR extends Structure {
	/** 0 - 8 */
	public byte type;
	/** 0 - 99 (in 8/72 of inch) */
	public byte height;
	/** 10 - 99 (in decims) */
	public byte width;
	/** TRUE if you want the human readable line */
	public byte barline;
	public BARCODEWR() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("type", "height", "width", "barline");
	}
	/**
	 * @param type 0 - 8<br>
	 * @param height 0 - 99 (in 8/72 of inch)<br>
	 * @param width 10 - 99 (in decims)<br>
	 * @param barline TRUE if you want the human readable line
	 */
	public BARCODEWR(byte type, byte height, byte width, byte barline) {
		super();
		this.type = type;
		this.height = height;
		this.width = width;
		this.barline = barline;
	}
	public BARCODEWR(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends BARCODEWR implements Structure.ByReference {
		
	};
	public static class ByValue extends BARCODEWR implements Structure.ByValue {
		
	};
}

