package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class BUFREAD extends Structure {
	/** answer length */
	public int len;
	/**
	 * this value is for short answers (!)<br>
	 * C type : BYTE[2100]
	 */
	public byte[] BufRead = new byte[2100];
	public BUFREAD() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("len", "BufRead");
	}
	/**
	 * @param len answer length<br>
	 * @param BufRead this value is for short answers (!)<br>
	 * C type : BYTE[2100]
	 */
	public BUFREAD(int len, byte BufRead[]) {
		super();
		this.len = len;
		if ((BufRead.length != this.BufRead.length)) 
			throw new IllegalArgumentException("Wrong array size !");
		this.BufRead = BufRead;
	}
	public BUFREAD(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends BUFREAD implements Structure.ByReference {
		
	};
	public static class ByValue extends BUFREAD implements Structure.ByValue {
		
	};
}

