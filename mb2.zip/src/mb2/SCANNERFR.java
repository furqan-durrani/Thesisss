package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class SCANNERFR extends Structure {
	public int grayscaleF;
	public int LuminF;
	public int SogliaF;
	public int grayscaleR;
	public int LuminR;
	public int SogliaR;
	public int ScanMode;
	/**
	 * reading area<br>
	 * C type : SCANRECTFR
	 */
	public SCANRECTFR window;
	public SCANNERFR() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("grayscaleF", "LuminF", "SogliaF", "grayscaleR", "LuminR", "SogliaR", "ScanMode", "window");
	}
	/**
	 * @param window reading area<br>
	 * C type : SCANRECTFR
	 */
	public SCANNERFR(int grayscaleF, int LuminF, int SogliaF, int grayscaleR, int LuminR, int SogliaR, int ScanMode, SCANRECTFR window) {
		super();
		this.grayscaleF = grayscaleF;
		this.LuminF = LuminF;
		this.SogliaF = SogliaF;
		this.grayscaleR = grayscaleR;
		this.LuminR = LuminR;
		this.SogliaR = SogliaR;
		this.ScanMode = ScanMode;
		this.window = window;
	}
	public SCANNERFR(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends SCANNERFR implements Structure.ByReference {
		
	};
	public static class ByValue extends SCANNERFR implements Structure.ByValue {
		
	};
}

