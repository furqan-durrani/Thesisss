package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class OCRREADMICR extends Structure {
	/** Number of characters recognized */
	public int CharNum;
	/** Media of the confidences */
	public int Confidence;
	/**
	 * Result of the OCR process.<br>
	 * C type : BYTE[2100]
	 */
	public byte[] OcrString = new byte[2100];
	public OCRREADMICR() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("CharNum", "Confidence", "OcrString");
	}
	/**
	 * @param CharNum Number of characters recognized<br>
	 * @param Confidence Media of the confidences<br>
	 * @param OcrString Result of the OCR process.<br>
	 * C type : BYTE[2100]
	 */
	public OCRREADMICR(int CharNum, int Confidence, byte OcrString[]) {
		super();
		this.CharNum = CharNum;
		this.Confidence = Confidence;
		if ((OcrString.length != this.OcrString.length)) 
			throw new IllegalArgumentException("Wrong array size !");
		this.OcrString = OcrString;
	}
	public OCRREADMICR(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends OCRREADMICR implements Structure.ByReference {
		
	};
	public static class ByValue extends OCRREADMICR implements Structure.ByValue {
		
	};
}

