package mb2;

import java.util.StringTokenizer;
import java.util.Arrays;
import java.util.List;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class gPort
{
    public static String Global;
    public static String PrType;
    public static Boolean HasMagneticH;
    public static Boolean HasMagneticV80;
    public static Boolean HasMagneticV160;
    public static Boolean HasMicr;
    public static Boolean HasScanner;
    public static Boolean HasADF;

    public static Boolean ScanToMem;
    //Puntatori dell'immagine
    public static IntByReference pImageF;
    public static int llImageF;
    public static IntByReference pImageR;
    public static int llImageR;
    // fine
}
