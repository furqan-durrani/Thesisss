package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class DAT_FORM extends Structure {
	/** kind of document */
	public byte doctype;
	/** characters per inch */
	public byte cpi;
	public short quality;
	/** linefeed steps (determines the lines per inch) */
	public short lpi;
	/** line number in format */
	public short lineno;
	/** number of steps for TOP */
	public short step_offset;
	/** first column in line */
	public short Left_margin;
	public short input_dev;
	/** default I/O devices: same as XXXInput() and XXXOutput() function parameters */
	public short output_dev;
	public short cutter_pos;
	public DAT_FORM() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("doctype", "cpi", "quality", "lpi", "lineno", "step_offset", "Left_margin", "input_dev", "output_dev", "cutter_pos");
	}
	public DAT_FORM(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends DAT_FORM implements Structure.ByReference {
		
	};
	public static class ByValue extends DAT_FORM implements Structure.ByValue {
		
	};
}

