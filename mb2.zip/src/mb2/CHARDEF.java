package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class CHARDEF extends Structure {
	public byte oldchar;
	public boolean upper_align;
	/**
	 * was BYTE<br>
	 * C type : LONG[12]
	 */
	public NativeLong[] colbytes = new NativeLong[12];
	public CHARDEF() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("oldchar", "upper_align", "colbytes");
	}
	/**
	 * @param colbytes was BYTE<br>
	 * C type : LONG[12]
	 */
	public CHARDEF(byte oldchar, boolean upper_align, NativeLong colbytes[]) {
		super();
		this.oldchar = oldchar;
		this.upper_align = upper_align;
		if ((colbytes.length != this.colbytes.length)) 
			throw new IllegalArgumentException("Wrong array size !");
		this.colbytes = colbytes;
	}
	public CHARDEF(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends CHARDEF implements Structure.ByReference {
		
	};
	public static class ByValue extends CHARDEF implements Structure.ByValue {
		
	};
}

