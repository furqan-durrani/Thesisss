package mb2;

import java.util.StringTokenizer;
import java.util.Arrays;
import java.util.List;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class MB2 {

	/**
	 * JNA Wrapper for library <b>MB2</b><br>
	 */

	public MB2() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
		/*
        byte[] d = Native.toByteArray("USB01");
        byte nullChar = '\u0000';
        byte [] data= new byte[d.length+1];
        for(int i=0;i<d.length;i++) data[i]=d[i];
        data[d.length]=nullChar;
        
        */

		System.out.println("Hello, World");
	    MB2Printer MB2obj = new MB2Printer();

	    String property = System.getProperty("java.library.path");
	    System.out.println(property);

	    String path = System.getProperty("user.home") + java.io.File.separator + "Documents" + java.io.File.separator ;
	    System.out.println(path);
	    
	    try {
	        short rc = MB2obj.OpenPort("USB", true);
	        if (((rc != (short) MB2Library.PR_OK)) && (rc != (short) MB2Library.PR_ALR_OPEN)) {
	            System.out.println("Open Port Error");
	            System.out.println(MB2obj.GetErrorString(rc));
	            	return;
	        }
	        
	        // print text
	        String Buff = "HHHHHHHHHH\r\nHHHHHHHHHH";
	        // MB2obj.PrintText(Buff);
	        // MB2obj.Eject(MB2Library.FRONTSLOT);
	        
	        // read micr
	        StringBuilder StrMicrOut = new StringBuilder();
	        // MB2obj.ReadMicr(StrMicrOut);
	        // MB2obj.Eject(MB2Library.FRONTSLOT);
	        
	        // scan

	        // StringBuilder StrMicrOut = new StringBuilder();
	        // MB2obj.Scan("fileName"
	        // 	                , MB2Library.SCAN_FRONT_REAR
	        // 	        		, MB2Library.BITS_PER_PIXEL_8
	        // 	                , MB2Library.SC_RESOLUTION_200
	        // 	        		, MB2Library.SC_REAR_FORWARD_FRONT_FORWARD
	        // 	        		, true
	        // 	        		, 0, 0, 5000, 5000
	        // 	        		, MB2Library.SCAN_OUTPUT_FORMAT_FILE_BMP
	        // 	        		, 2 /*readcode*/);
	        // MB2obj.Eject(MB2Library.FRONTSLOT);
	        
	        MB2obj.Scan(path+"FILENAME_");
	        MB2obj.Eject(MB2Library.FRONTSLOT);
	        
	    } catch (UnsatisfiedLinkError e) {
	        System.err.println("Native code library failed to load.\n" + e);
	        System.exit(1);
	    }
	}

}
