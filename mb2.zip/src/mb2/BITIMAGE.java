package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class BITIMAGE extends Structure {
	/** print type */
	public byte typeprt;
	/** line length in pixels */
	public int linelen;
	/** horizontal spacing (dots per inch) */
	public byte spacing;
	public BITIMAGE() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("typeprt", "linelen", "spacing");
	}
	/**
	 * @param typeprt print type<br>
	 * @param linelen line length in pixels<br>
	 * @param spacing horizontal spacing (dots per inch)
	 */
	public BITIMAGE(byte typeprt, int linelen, byte spacing) {
		super();
		this.typeprt = typeprt;
		this.linelen = linelen;
		this.spacing = spacing;
	}
	public BITIMAGE(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends BITIMAGE implements Structure.ByReference {
		
	};
	public static class ByValue extends BITIMAGE implements Structure.ByValue {
		
	};
}
