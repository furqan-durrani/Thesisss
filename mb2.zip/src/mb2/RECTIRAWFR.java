package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class RECTIRAWFR extends Structure {
	public int startx;
	public int starty;
	public int endx;
	public int endy;
	/** C type : HANDLE */
	public NativeLong pImageF;
	public NativeLong llImageF;
	/** C type : HANDLE */
	public NativeLong pImageR;
	public NativeLong llImageR;
	public int NumLinesWritten;
	public RECTIRAWFR() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("startx", "starty", "endx", "endy", "pImageF", "llImageF", "pImageR", "llImageR", "NumLinesWritten");
	}
	/**
	 * @param pImageF C type : HANDLE<br>
	 * @param pImageR C type : HANDLE
	 */
	public RECTIRAWFR(int startx, int starty, int endx, int endy, NativeLong pImageF, NativeLong llImageF, NativeLong pImageR, NativeLong llImageR, int NumLinesWritten) {
		super();
		this.startx = startx;
		this.starty = starty;
		this.endx = endx;
		this.endy = endy;
		this.pImageF = pImageF;
		this.llImageF = llImageF;
		this.pImageR = pImageR;
		this.llImageR = llImageR;
		this.NumLinesWritten = NumLinesWritten;
	}
	public RECTIRAWFR(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends RECTIRAWFR implements Structure.ByReference {
		
	};
	public static class ByValue extends RECTIRAWFR implements Structure.ByValue {
		
	};
}

