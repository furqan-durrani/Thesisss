package mb2;

import java.util.StringTokenizer;
import java.util.Arrays;
import java.util.List;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

/**
 * JNA Wrapper for library <b>MB2</b><br>

 */
public interface MB2Library extends Library {
	
	public static final String JNA_LIBRARY_NAME = "PR2";
	public static final NativeLibrary JNA_NATIVE_LIB = NativeLibrary.getInstance(MB2Library.JNA_LIBRARY_NAME);
	public static final MB2Library INSTANCE = (MB2Library)Native.loadLibrary(MB2Library.JNA_LIBRARY_NAME, MB2Library.class);
	
	public static final int GRAY16 = (int)1;
	public static final int PR2_GS = (int)0x1D;
	public static final int RD_INDUSTRIAL_2OF5 = (int)7;
	public static final int DF_MODE_HOST_DRIVEN = (int)1;
	public static final int PR2845TYPE = (int)3;
	public static final int MICR_CMC7ALPHA = (int)0;
	public static final int SC_REAR_REVERSE_FRONT_FORWARD = (int)3;
	public static final int ISRAEL = (int)150;
	public static final int PR_NOADF = (int)805;
	public static final int FRANCE = (int)60;
	public static final int SETATTR = (int)0;
	public static final int SDC = (int)510;
	public static final int PR_BIM = (int)605;
	public static final int PAPER_JAMS = (int)6;
	public static final int PR_TXTIMEOUT = (int)819;
	public static final int HAS_UV = (int)0x008;
	public static final int DPI060 = (int)4;
	public static final int PR_TX_OVERRUN = (int)665;
	public static final int PORTUGAL = (int)30;
	public static final int GRAY2 = (int)0;
	public static final int HMAGNETIC_OPS = (int)16;
	public static final int LEFT = (int)2;
	public static final int USB_PORT_NAME_LEN = (int)6;
	public static final int SET_Sorter1 = (int)0;
	public static final int SET_Sorter2 = (int)1;
	public static final char SUBSCRIPT = (char)'7';
	public static final int PR_WRN_EOP = (int)814;
	public static final int POWER_ON_HOURS = (int)11;
	public static final int CPIPROP = (int)1;
	public static final int PRT_LQ2IT = (int)20;
	public static final int PR_NOSCANNER_FRONT = (int)843;
	public static final int DOCEJECTED = (int)1;
	public static final int DBLHEIGHT1 = (int)0;
	public static final int BPI160 = (int)0x00;
	public static final int DPI072 = (int)0;
	public static final int DIGITAL = (int)0x20;
	public static final int MAX_USB_PORTS = (int)10;
	public static final int PRT_UNLOCK = (int)2;
	public static final int SORTER1_SLOT = (int)8;
	public static final int PRT_OCRB = (int)9;
	public static final int PRT_OCRA = (int)10;
	public static final int PR_LOCAL = (int)810;
	public static final int FRONTSLOT = (int)1;
	public static final int PR2E_PLUS_TYPE = (int)7;
	public static final int HAS_INFRARED = (int)0x002;
	public static final int HMICR_READINGS_CMC7 = (int)14;
	public static final int RD_UPC_A = (int)0;
	public static final int VMAGNETIC_OPS = (int)17;
	public static final int SCAN_OUTPUT_FORMAT_MEM_JPEG = (int)2;
	public static final int BITS_PER_PIXEL_24 = (int)24;
	public static final int ADF_DOCPRESENT = (int)4;
	public static final int DF_MODE_AUTOMATIC = (int)0;
	public static final char ABS = (char)'L';
	public static final int WR_UPC_A = (int)1;
	public static final int PR_NOT_SET = (int)607;
	public static final int PR2_EOT = (int)0x04;
	public static final int PRT_NLQ2IT = (int)6;
	public static final int DPI080 = (int)3;
	public static final int SC_REAR_REVERSE_FRONT_REVERSE = (int)4;
	public static final int SC_GREEN = (int)2;
	public static final int SWITZERLAND = (int)90;
	public static final int CODEPAGE_PC = (int)710;
	public static final int DENNOR = (int)50;
	public static final int STANDARD = (int)0;
	public static final int WR_UPC_E = (int)2;
	public static final int RD_EAN_13 = (int)3;
	public static final int INT1 = (int)0;
	public static final int INT2 = (int)10;
	public static final int SCAN_OUTPUT_FORMAT_FILE_BMP = (int)1;
	public static final char UNDROVRSCORE = (char)'9';
	public static final int SP_SLOW_MOTION = (int)2;
	public static final int SC_EX_GREY_RGB_UV = (int)10;
	public static final int WR_CODE_128 = (int)9;
	public static final int PR_RX_OVERRUN = (int)662;
	public static final int SC_EX_COLOR_RGB_UV = (int)11;
	public static final int PRT_LOCK = (int)1;
	public static final int PR_BADBUF = (int)653;
	public static final int PR_DOC_NOT_ALIGNED = (int)841;
	public static final char REL = (char)'I';
	public static final int SC_EX_COLOR_RGB = (int)5;
	public static final int PR_BADSTRIP = (int)822;
	public static final int LINE_FEEDS = (int)3;
	public static final int WR_EAN_13 = (int)4;
	public static final int PR_NOT_OWNED = (int)604;
	public static final int PR_WRN_DOC = (int)833;
	public static final int RD_INTERLEAVED_2OF5 = (int)6;
	public static final int PR_ERR_STRIPE = (int)802;
	public static final int TURKEY = (int)520;
	public static final int INTNL_PC = (int)700;
	public static final int SC_EX_INFRARED = (int)6;
	public static final int PRT_LQ2 = (int)17;
	public static final int SCAN_OUTPUT_FORMAT_MEM_PDF = (int)4;
	public static final int ADF_Disabled = (int)0;
	public static final int SCANNER_REAR = (int)4;
	public static final int SC_EX_GREY_RGB_INFRARED = (int)7;
	public static final int GRAY256 = (int)2;
	public static final int PR_NOT_SUPPORTED = (int)609;
	public static final int USASCII = (int)110;
	public static final int HEBREW_PC = (int)625;
	public static final int PR_HUNG = (int)710;
	public static final int PR_FRAMING_ERR = (int)664;
	public static final int SC_EX_GREEN = (int)2;
	public static final int BPI080 = (int)0x02;
	public static final int SC_RESOLUTION_300 = (int)3;
	public static final int ITALY = (int)70;
	public static final int SC_EX_UV = (int)9;
	public static final int SC_EX_BLUE = (int)3;
	public static final int CYRILL3_PC = (int)615;
	public static final int PR_PORT_BUSY = (int)655;
	public static final int PR2_XOFF = (int)0x13;
	public static final int PR2_LF = (int)0x0A;
	public static final int RD_UPC_E = (int)1;
	public static final int SCANNER_FRONT = (int)3;
	public static final int SC_BLUE = (int)4;
	public static final int PRINTED_CHARS_PARTIAL = (int)2;
	public static final int ISO2_PC = (int)605;
	public static final int DOCREADY = (int)2;
	public static final int POSITIVE = (int)0;
	public static final int CANADA = (int)500;
	public static final int PR_PAPJAM = (int)713;
	public static final int SC_RED_GREEN = (int)3;
	public static final int PRT_VHSD = (int)15;
	public static final int CANFRENCH_PC = (int)730;
	public static final char BOLDFACE = (char)'(';
	public static final int CYRILL2_PC = (int)783;
	public static final int PR_RX_BREAK = (int)666;
	public static final int PR_WRN_SOF = (int)832;
	public static final char SINGLEDOC = (char)'@';
	public static final int PORTUGAL_PC = (int)720;
	public static final int PR2_ACK = (int)0x06;
	public static final int PR2_BEL = (int)0x07;
	public static final int PR_ERRTYPE = (int)821;
	public static final int VERT160BPI = (int)1;
	public static final int ARABIC_PC = (int)782;
	public static final int DOCPRESENT = (int)3;
	public static final int PR_NO_DOC = (int)815;
	public static final int SC_RESOLUTION_200 = (int)2;
	public static final int HAS_MAGN = (int)0x001;
	public static final int RD_CODEBAR = (int)5;
	public static final int CLRATTR = (int)1;
	public static final int GREECE1_PC = (int)770;
	public static final int WR_CODE_39 = (int)5;
	public static final int SC_RESOLUTION_203 = (int)1;
	public static final int LATIN2_PC = (int)750;
	public static final char CPI16_6 = (char)'>';
	public static final int DUPLIC = (int)0x20;
	public static final int COLOR_ORDER_GRAY = (int)1;
	public static final int PRINTED_CHARS_FULL = (int)1;
	public static final int PR_ERR_COMMAPI = (int)650;
	public static final int SC_BY_COMMAND = (int)1;
	public static final int SC_RED_GREEN_BLUE = (int)3;
	public static final int PR_HWERR = (int)817;
	public static final char UNDERSCORE = (char)'5';
	public static final int PR2_STX = (int)0x02;
	public static final int DPI100 = (int)1;
	public static final int SCAN_FULL_WITH_MEASURE = (int)0;
	public static final int BITS_PER_PIXEL_1 = (int)1;
	public static final int PR_NO_OPEN = (int)600;
	public static final int STANDBY_HOURS = (int)12;
	public static final int PR_NOSCANNER = (int)807;
	public static final int WAIT_OPER = (int)0x20;
	public static final int PR_NOMAGN = (int)801;
	public static final int DOC_INSERTIONS = (int)4;
	public static final int STD31 = (int)410;
	public static final int USER_SET = (int)-1;
	public static final int ISO1_PC = (int)600;
	public static final int NONE = (int)0x00;
	public static final char DBLWIDTH = (char)'3';
	public static final int PRT_NLQ2 = (int)14;
	public static final int ARABIC = (int)530;
	public static final int PR2_XON = (int)0x11;
	public static final int PR_BAD_RESPONSE = (int)651;
	public static final int SP_TRANSPARENT_BORDER = (int)1;
	public static final int TURKLAT2_PC = (int)602; // previously PR_ABORTED
	public static final int SCAN_REAR = (int)1;
	public static final int SCAN_FULL_WITHOUT_MEASURE = (int)1;
	public static final int GREECE3_PC = (int)623;
	public static final int PR_BUSY = (int)606;
	public static final int BITS_PER_PIXEL_8 = (int)8;
	public static final char SUPERSCRIPT = (char)'6';
	public static final int CPI17_1 = (int)6;
	public static final int BITS_PER_PIXEL_4 = (int)4;
	public static final int CIBC = (int)540;
	public static final int SORTER2_SLOT = (int)9;
	public static final int OPERATOR2 = (int)0x02;
	public static final int OPERATOR1 = (int)0x01;
	public static final int DPI120 = (int)2;
	public static final int SPAIN_PC = (int)701;
	public static final int DPI240 = (int)1;
	public static final int ADF_DOCPRESENT_PR_DOCEJECTED = (int)5;
	public static final int ADF_Enabled = (int)1;
	public static final char CPI12 = (char)'=';
	public static final int RETRY1 = (int)0x00;
	public static final int GRTBRT = (int)100;
	public static final int ADF_DOCPRESENT_PR_DOCPRESENT = (int)7;
	public static final int OLIMODE = (int)0;
	public static final int TURKLAT1_PC = (int)742;
	public static final char BOOKV = (char)'D';
	public static final int RETRY3 = (int)0x10;
	public static final int PR_SWITCHED_OFF = (int)608;
	public static final int WR_EAN_8 = (int)3;
	public static final int ISRAEL_PC = (int)781;
	public static final int EOS0C = (int)0x08;
	public static final char CPI10 = (char)'<';
	public static final int EOS0F = (int)0x00;
	public static final int GREECE2_PC = (int)771;
	public static final int PR2_DEL = (int)0x7F;
	public static final int RD_EAN_8 = (int)2;
	public static final int SC_AUTOMATIC = (int)2;
	public static final int CPI05 = (int)9;
	public static final int PR_ERR_LINE = (int)811;
	public static final char DBLHEIGHT = (char)'d';
	public static final int SCAN_OUTPUT_FORMAT_FILE = (int)1;
	public static final int HAS_ADF = (int)0x004;
	public static final int LATIN1_PC = (int)740;
	public static final int RIGHT = (int)1;
	public static final int USSR = (int)180;
	public static final int YUGOSLAVIA = (int)200;
	public static final int ADF_DOCPRESENT_PR_DOCREADY = (int)6;
	public static final int PR_DISCONNECTED = (int)711;
	public static final int ANSI = (int)2;
	public static final int IBMMODE = (int)1;
	public static final int LIGHTOFF = (int)0x00;
	public static final int IBM3604 = (int)0;
	public static final int PR_ABORTED = (int)602;
	public static final int PR_NO_MEMORY = (int)603;
	public static final int PR2TYPE = (int)4;
	public static final int SWEFIN = (int)80;
	public static final int DEFAULTDEV = (int)0;
	public static final int DINISO = (int)1;
	public static final int PR2_RS = (int)0x1E;
	public static final int CYRILL1_PC = (int)780;
	public static final char OVERSCORE = (char)'8';
	public static final int HAS_SCANNER = (int)0x040;
	public static final int PRT_DRAFTIT = (int)7;
	public static final int CPI15 = (int)3;
	public static final int SC_EX_COLOR_RGB_INFRARED = (int)8;
	public static final int HAS_MICR = (int)0x080;
	public static final int SP_IGNORE_JAM = (int)3;
	public static final int SC_RED = (int)1;
	public static final int SCAN_OUTPUT_FORMAT_MEM_BMP = (int)0;
	public static final int SPAIN1 = (int)40;
	public static final int PR2_CR = (int)0x0D;
	public static final int SPAIN2 = (int)170;
	public static final int SC_EX_GREY_RGB = (int)4;
	public static final int REAR = (int)7;
	public static final int PLUS20 = (int)0x02;
	public static final int SCAN_OUTPUT_FORMAT_FILE_JPEG = (int)3;
	public static final int HMICR_READINGS_E13B = (int)15;
	public static final int WR_INDUSTRIAL_2OF5 = (int)8;
	public static final int PRT_NLQ = (int)3;
	public static final int SCAN_OUTPUT_FORMAT_MEM = (int)0;
	public static final int PR50TYPE = (int)1;
	public static final int COVER_OPENINGS = (int)5;
	public static final int PR_NULLEN = (int)800;
	public static final int ADF_DOUBLE_FEED = (int)10;
	public static final int PRT_NLQ1IT = (int)18;
	public static final int PR_BAD_PARAMETER = (int)652;
	public static final int PR_STRIPE_NODATA = (int)813;
	public static final int ANALOGIC = (int)0x10;
	public static final int LIGHTON = (int)0x10;
	public static final int GREECE = (int)140;
	public static final int POWER_ON_CYCLES = (int)13;
	public static final int PR_NOMICR = (int)797;
	public static final int PR_CARTER = (int)812;
	public static final int PR_ALR_OPEN = (int)601;
	public static final int WR_BARCODE_DFLT = (int)0;
	public static final int PR_NOSCANNER_REAR = (int)842;
	public static final int REAR_SCANS = (int)8;
	public static final int NODUPLIC = (int)0;
	public static final int SCANNER_FRONT_REAR = (int)5;
	public static final int UNIX_PC = (int)680;
	public static final int PR_OK = (int)0;
	public static final char BOOKH = (char)'F';
	public static final int PRT_LOCK_STATE = (int)3;
	public static final int NEGATIVE = (int)1;
	public static final int HORIZONTAL = (int)3;
	public static final int PRT_DRAFT0 = (int)0;
	public static final int PRT_DRAFT2 = (int)2;
	public static final int DEN2_PC = (int)712;
	public static final int PR_WRN_LOCCART = (int)830;
	public static final int SC_REAR_FORWARD_FRONT_REVERSE = (int)2;
	public static final int LATARAB_PC = (int)620;
	public static final int PRT_HSD = (int)1;
	public static final int DPI200 = (int)3;
	public static final int PR2_ESC = (int)0x1B;
	public static final int INTERSPACE = (int)1;
	public static final int COLOR_ORDER_RGB = (int)2;
	public static final int COLOR_ORDER_BGR = (int)3;
	public static final int DOCABSENT = (int)0;
	public static final int STATION_2 = (int)0x80;
	public static final int PR2_SOH = (int)0x01;
	public static final int SCAN_FRONT_REAR = (int)2;
	public static final int GERMANY = (int)20;
	public static final int SCAN_OUTPUT_FORMAT_FILE_PDF = (int)5;
	public static final int RD_CODE_39 = (int)4;
	public static final int VERT080BPI = (int)2;
	public static final int WR_CODEBAR = (int)6;
	public static final int WR_INTERLEAVED_2OF5 = (int)7;
	public static final int FRONT_SCANS = (int)7;
	public static final int PR2_FS = (int)0x1C;
	public static final int PLUS10 = (int)0x01;
	public static final int SC_INFRARED = (int)4;
	public static final int SC_EX_RED = (int)1;
	public static final int PR2_ETB = (int)0x17;
	public static final int PR_BAD_COMMAND = (int)816;
	public static final int PR2_TAB = (int)0x09;
	public static final int PR_PARITY_ERR = (int)663;
	public static final int PR_RXTIMEOUT = (int)820;
	public static final int CPIDFLT = (int)0;
	public static final int SCAN_FRONT = (int)0;
	public static final int PR2_FF = (int)0x0C;
	public static final int DENNOR_PC = (int)711;
	public static final int SC_REAR_FORWARD_FRONT_FORWARD = (int)1;
	public static final int PRINTER = (int)0;
	public static final int PR2_ETX = (int)0x03;
	public static final int COLOR_ORDER_GAMMA = (int)4;
	public static final int MICR_E13B = (int)1;
	public static final int SC_RESOLUTION_600 = (int)4;
	public static final int MICR_CMC7NUM = (int)2;
	
	/* from .NET sample code */
	public static final int SCAN_RESOLUTION_200 = 200;
	public static final int SCAN_RESOLUTION_203 = 203;
	public static final int SCAN_RESOLUTION_300 = 300;
	public static final int SCAN_RESOLUTION_600 = 600;

	public static final int MAX_PAGE_WIDTH = 1664;
	public static final int MAX_PAGE_HEIGHT = 2338;

	public static final int MAX_PAGE_WIDTH_200 = 1664;
	public static final int MAX_PAGE_HEIGH_200 = 2338;

	public static final int MAX_PAGE_WIDTH_203 = 1680;
	public static final int MAX_PAGE_HEIGH_203 = 2376;

	public static final int MAX_PAGE_WIDTH_300 = 2480;
	public static final int MAX_PAGE_HEIGH_300 = 3507;

	public static final int MAX_PAGE_WIDTH_600 = 4960;
	public static final int MAX_PAGE_HEIGH_600 = 7015;
	/* end */
	
	/**
	 * ----------------------------------<br>
	 * first thing to do<br>
	 * Original signature : <code>WORD DrvOpen(LPSTR, PSETUPPRT, PDAT_CONF)</code><br>
	 * @param PDAT_CONF1 first thing to do<br>
	 * <i>native declaration : line 888</i><br>
	 * @deprecated use the safer methods {@link #DrvOpen(java.nio.ByteBuffer, mb2.SETUPPRT, mb2.DAT_CONF)} and {@link #DrvOpen(com.sun.jna.Pointer, mb2.SETUPPRT, mb2.DAT_CONF)} instead
	 */
	@Deprecated 
	short DrvOpen(Pointer LPSTR1, SETUPPRT PSETUPPRT1, DAT_CONF PDAT_CONF1);
	/**
	 * ----------------------------------<br>
	 * first thing to do<br>
	 * Original signature : <code>WORD DrvOpen(LPSTR, PSETUPPRT, PDAT_CONF)</code><br>
	 * @param PDAT_CONF1 first thing to do<br>
	 * <i>native declaration : line 888</i>
	 */
	short DrvOpen(ByteBuffer LPSTR1, SETUPPRT PSETUPPRT1, DAT_CONF PDAT_CONF1);
	/**
	 * Original signature : <code>WORD DrvClose(LPSTR)</code><br>
	 * <i>native declaration : line 889</i><br>
	 * @deprecated use the safer methods {@link #DrvClose(java.nio.ByteBuffer)} and {@link #DrvClose(com.sun.jna.Pointer)} instead
	 */
	@Deprecated 
	short DrvClose(Pointer LPSTR1);
	/**
	 * Original signature : <code>WORD DrvClose(LPSTR)</code><br>
	 * <i>native declaration : line 889</i>
	 */
	short DrvClose(ByteBuffer LPSTR1);
	/**
	 * Original signature : <code>WORD DrvEscape(LPSTR, LPSTR, int, BUFREAD*, RESPINFO*)</code><br>
	 * <i>native declaration : line 890</i><br>
	 * @deprecated use the safer methods {@link #DrvEscape(java.nio.ByteBuffer, java.nio.ByteBuffer, int, mb2.BUFREAD, mb2.RESPINFO)} and {@link #DrvEscape(com.sun.jna.Pointer, com.sun.jna.Pointer, int, mb2.BUFREAD, mb2.RESPINFO)} instead
	 */
	@Deprecated 
	short DrvEscape(Pointer LPSTR1, Pointer LPSTR2, int int1, BUFREAD BUFREADPtr1, RESPINFO RESPINFOPtr1);
	/**
	 * Original signature : <code>WORD DrvEscape(LPSTR, LPSTR, int, BUFREAD*, RESPINFO*)</code><br>
	 * <i>native declaration : line 890</i>
	 */
	short DrvEscape(ByteBuffer LPSTR1, ByteBuffer LPSTR2, int int1, BUFREAD BUFREADPtr1, RESPINFO RESPINFOPtr1);
	/**
	 * Original signature : <code>WORD DrvEscapeEx(LPSTR, LPSTR, int, int, BUFREAD*, RESPINFO*)</code><br>
	 * <i>native declaration : line 891</i><br>
	 * @deprecated use the safer methods {@link #DrvEscapeEx(java.nio.ByteBuffer, java.nio.ByteBuffer, int, int, mb2.BUFREAD, mb2.RESPINFO)} and {@link #DrvEscapeEx(com.sun.jna.Pointer, com.sun.jna.Pointer, int, int, mb2.BUFREAD, mb2.RESPINFO)} instead
	 */
	@Deprecated 
	short DrvEscapeEx(Pointer LPSTR1, Pointer LPSTR2, int int1, int int2, BUFREAD BUFREADPtr1, RESPINFO RESPINFOPtr1);
	/**
	 * Original signature : <code>WORD DrvEscapeEx(LPSTR, LPSTR, int, int, BUFREAD*, RESPINFO*)</code><br>
	 * <i>native declaration : line 891</i>
	 */
	short DrvEscapeEx(ByteBuffer LPSTR1, ByteBuffer LPSTR2, int int1, int int2, BUFREAD BUFREADPtr1, RESPINFO RESPINFOPtr1);
	/**
	 * Original signature : <code>WORD DrvWriteRaw(LPSTR, DWORD, LPDWORD, LPSTR)</code><br>
	 * <i>native declaration : line 892</i><br>
	 * @deprecated use the safer methods {@link #DrvWriteRaw(java.nio.ByteBuffer, int, java.nio.IntBuffer, java.nio.ByteBuffer)} and {@link #DrvWriteRaw(com.sun.jna.Pointer, int, com.sun.jna.ptr.IntByReference, com.sun.jna.Pointer)} instead
	 */
	@Deprecated 
	short DrvWriteRaw(Pointer LPSTR1, int dwBytesToWrite, IntByReference pdwBytesWritten, Pointer pWriteBuff);
	/**
	 * Original signature : <code>WORD DrvWriteRaw(LPSTR, DWORD, LPDWORD, LPSTR)</code><br>
	 * <i>native declaration : line 892</i>
	 */
	short DrvWriteRaw(ByteBuffer LPSTR1, int dwBytesToWrite, IntBuffer pdwBytesWritten, ByteBuffer pWriteBuff);
	/**
	 * Original signature : <code>WORD DrvReadRaw(LPSTR, DWORD, LPDWORD, LPSTR, bool*)</code><br>
	 * <i>native declaration : line 893</i><br>
	 * @deprecated use the safer methods {@link #DrvReadRaw(java.nio.ByteBuffer, int, java.nio.IntBuffer, java.nio.ByteBuffer, java.nio.ByteBuffer)} and {@link #DrvReadRaw(com.sun.jna.Pointer, int, com.sun.jna.ptr.IntByReference, com.sun.jna.Pointer, com.sun.jna.Pointer)} instead
	 */
	@Deprecated 
	short DrvReadRaw(Pointer LPSTR1, int dwBytesToRead, IntByReference pdwBytesRead, Pointer pReadBuff, Pointer otherDataPresent);
	/**
	 * Original signature : <code>WORD DrvReadRaw(LPSTR, DWORD, LPDWORD, LPSTR, bool*)</code><br>
	 * <i>native declaration : line 893</i>
	 */
	short DrvReadRaw(ByteBuffer LPSTR1, int dwBytesToRead, IntBuffer pdwBytesRead, ByteBuffer pReadBuff, ByteBuffer otherDataPresent);
	/**
	 * Original signature : <code>WORD DrvReset(LPSTR)</code><br>
	 * <i>native declaration : line 894</i><br>
	 * @deprecated use the safer methods {@link #DrvReset(java.nio.ByteBuffer)} and {@link #DrvReset(com.sun.jna.Pointer)} instead
	 */
	@Deprecated 
	short DrvReset(Pointer LPSTR1);
	/**
	 * Original signature : <code>WORD DrvReset(LPSTR)</code><br>
	 * <i>native declaration : line 894</i>
	 */
	short DrvReset(ByteBuffer LPSTR1);
	/**
	 * Original signature : <code>WORD DrvAbort(LPSTR)</code><br>
	 * <i>native declaration : line 895</i><br>
	 * @deprecated use the safer methods {@link #DrvAbort(java.nio.ByteBuffer)} and {@link #DrvAbort(com.sun.jna.Pointer)} instead
	 */
	@Deprecated 
	short DrvAbort(Pointer LPSTR1);
	/**
	 * Original signature : <code>WORD DrvAbort(LPSTR)</code><br>
	 * <i>native declaration : line 895</i>
	 */
	short DrvAbort(ByteBuffer LPSTR1);
	/**
	 * Original signature : <code>WORD DrvFlushDevRxBuffer(LPSTR)</code><br>
	 * <i>native declaration : line 896</i><br>
	 * @deprecated use the safer methods {@link #DrvFlushDevRxBuffer(java.nio.ByteBuffer)} and {@link #DrvFlushDevRxBuffer(com.sun.jna.Pointer)} instead
	 */
	@Deprecated 
	short DrvFlushDevRxBuffer(Pointer LPSTR1);
	/**
	 * Original signature : <code>WORD DrvFlushDevRxBuffer(LPSTR)</code><br>
	 * <i>native declaration : line 896</i>
	 */
	short DrvFlushDevRxBuffer(ByteBuffer LPSTR1);
	/**
	 * front feed related functions<br>
	 * Original signature : <code>WORD PrtSet(LPSTR, PDAT_FORM)</code><br>
	 * <i>native declaration : line 898</i><br>
	 * @deprecated use the safer methods {@link #PrtSet(java.nio.ByteBuffer, mb2.DAT_FORM)} and {@link #PrtSet(com.sun.jna.Pointer, mb2.DAT_FORM)} instead
	 */
	@Deprecated 
	short PrtSet(Pointer LPSTR1, DAT_FORM PDAT_FORM1);
	/**
	 * front feed related functions<br>
	 * Original signature : <code>WORD PrtSet(LPSTR, PDAT_FORM)</code><br>
	 * <i>native declaration : line 898</i>
	 */
	short PrtSet(ByteBuffer LPSTR1, DAT_FORM PDAT_FORM1);
	/**
	 * Original signature : <code>WORD PrtSetAttrib(LPSTR, int, int)</code><br>
	 * <i>native declaration : line 899</i><br>
	 * @deprecated use the safer methods {@link #PrtSetAttrib(java.nio.ByteBuffer, int, int)} and {@link #PrtSetAttrib(com.sun.jna.Pointer, int, int)} instead
	 */
	@Deprecated 
	short PrtSetAttrib(Pointer LPSTR1, int int1, int int2);
	/**
	 * Original signature : <code>WORD PrtSetAttrib(LPSTR, int, int)</code><br>
	 * <i>native declaration : line 899</i>
	 */
	short PrtSetAttrib(ByteBuffer LPSTR1, int int1, int int2);
	/**
	 * Original signature : <code>WORD PrtSetChar(LPSTR, int)</code><br>
	 * <i>native declaration : line 900</i><br>
	 * @deprecated use the safer methods {@link #PrtSetChar(java.nio.ByteBuffer, int)} and {@link #PrtSetChar(com.sun.jna.Pointer, int)} instead
	 */
	@Deprecated 
	short PrtSetChar(Pointer LPSTR1, int int1);
	/**
	 * Original signature : <code>WORD PrtSetChar(LPSTR, int)</code><br>
	 * <i>native declaration : line 900</i>
	 */
	short PrtSetChar(ByteBuffer LPSTR1, int int1);
	/**
	 * Original signature : <code>WORD PrtSetPins(LPSTR, int)</code><br>
	 * <i>native declaration : line 901</i><br>
	 * @deprecated use the safer methods {@link #PrtSetPins(java.nio.ByteBuffer, int)} and {@link #PrtSetPins(com.sun.jna.Pointer, int)} instead
	 */
	@Deprecated 
	short PrtSetPins(Pointer LPSTR1, int int1);
	/**
	 * Original signature : <code>WORD PrtSetPins(LPSTR, int)</code><br>
	 * <i>native declaration : line 901</i>
	 */
	short PrtSetPins(ByteBuffer LPSTR1, int int1);
	/**
	 * Original signature : <code>WORD PrtInput(LPSTR, int)</code><br>
	 * <i>native declaration : line 902</i><br>
	 * @deprecated use the safer methods {@link #PrtInput(java.nio.ByteBuffer, int)} and {@link #PrtInput(com.sun.jna.Pointer, int)} instead
	 */
	@Deprecated 
	short PrtInput(Pointer LPSTR1, int int1);
	/**
	 * Original signature : <code>WORD PrtInput(LPSTR, int)</code><br>
	 * <i>native declaration : line 902</i>
	 */
	short PrtInput(ByteBuffer LPSTR1, int int1);
	/**
	 * Original signature : <code>WORD PrtOutput(LPSTR, int)</code><br>
	 * <i>native declaration : line 903</i><br>
	 * @deprecated use the safer methods {@link #PrtOutput(java.nio.ByteBuffer, int)} and {@link #PrtOutput(com.sun.jna.Pointer, int)} instead
	 */
	@Deprecated 
	short PrtOutput(Pointer LPSTR1, int int1);
	/**
	 * Original signature : <code>WORD PrtOutput(LPSTR, int)</code><br>
	 * <i>native declaration : line 903</i>
	 */
	short PrtOutput(ByteBuffer LPSTR1, int int1);
	/**
	 * Original signature : <code>WORD PrtPrintMacro(LPSTR, int)</code><br>
	 * <i>native declaration : line 904</i><br>
	 * @deprecated use the safer methods {@link #PrtPrintMacro(java.nio.ByteBuffer, int)} and {@link #PrtPrintMacro(com.sun.jna.Pointer, int)} instead
	 */
	@Deprecated 
	short PrtPrintMacro(Pointer LPSTR1, int int1);
	/**
	 * Original signature : <code>WORD PrtPrintMacro(LPSTR, int)</code><br>
	 * <i>native declaration : line 904</i>
	 */
	short PrtPrintMacro(ByteBuffer LPSTR1, int int1);
	/**
	 * on-fly mode setting (tooli + toibm)<br>
	 * Original signature : <code>WORD PrtMode(LPSTR, int)</code><br>
	 * @param int1 on-fly mode setting (tooli + toibm)<br>
	 * <i>native declaration : line 906</i><br>
	 * @deprecated use the safer methods {@link #PrtMode(java.nio.ByteBuffer, int)} and {@link #PrtMode(com.sun.jna.Pointer, int)} instead
	 */
	@Deprecated 
	short PrtMode(Pointer LPSTR1, int int1);
	/**
	 * on-fly mode setting (tooli + toibm)<br>
	 * Original signature : <code>WORD PrtMode(LPSTR, int)</code><br>
	 * @param int1 on-fly mode setting (tooli + toibm)<br>
	 * <i>native declaration : line 906</i>
	 */
	short PrtMode(ByteBuffer LPSTR1, int int1);
	/**
	 * Original signature : <code>WORD PrtGetstatus(LPSTR, BUFREAD*)</code><br>
	 * <i>native declaration : line 907</i><br>
	 * @deprecated use the safer methods {@link #PrtGetstatus(java.nio.ByteBuffer, mb2.BUFREAD)} and {@link #PrtGetstatus(com.sun.jna.Pointer, mb2.BUFREAD)} instead
	 */
	@Deprecated 
	short PrtGetstatus(Pointer LPSTR1, BUFREAD BUFREADPtr1);
	/**
	 * Original signature : <code>WORD PrtGetstatus(LPSTR, BUFREAD*)</code><br>
	 * <i>native declaration : line 907</i>
	 */
	short PrtGetstatus(ByteBuffer LPSTR1, BUFREAD BUFREADPtr1);
	/**
	 * Original signature : <code>WORD PrtPositionV(LPSTR, char, short)</code><br>
	 * <i>native declaration : line 908</i><br>
	 * @deprecated use the safer methods {@link #PrtPositionV(java.nio.ByteBuffer, byte, short)} and {@link #PrtPositionV(com.sun.jna.Pointer, byte, short)} instead
	 */
	@Deprecated 
	short PrtPositionV(Pointer LPSTR1, byte char1, short s1);
	/**
	 * Original signature : <code>WORD PrtPositionV(LPSTR, char, short)</code><br>
	 * <i>native declaration : line 908</i>
	 */
	short PrtPositionV(ByteBuffer LPSTR1, byte char1, short s1);
	/**
	 * Original signature : <code>WORD PrtPositionH(LPSTR, char, short)</code><br>
	 * <i>native declaration : line 909</i><br>
	 * @deprecated use the safer methods {@link #PrtPositionH(java.nio.ByteBuffer, byte, short)} and {@link #PrtPositionH(com.sun.jna.Pointer, byte, short)} instead
	 */
	@Deprecated 
	short PrtPositionH(Pointer LPSTR1, byte char1, short s1);
	/**
	 * Original signature : <code>WORD PrtPositionH(LPSTR, char, short)</code><br>
	 * <i>native declaration : line 909</i>
	 */
	short PrtPositionH(ByteBuffer LPSTR1, byte char1, short s1);
	/**
	 * Original signature : <code>WORD PrtWrite(LPSTR, LPSTR, DWORD)</code><br>
	 * <i>native declaration : line 910</i><br>
	 * @deprecated use the safer methods {@link #PrtWrite(java.nio.ByteBuffer, java.nio.ByteBuffer, int)} and {@link #PrtWrite(com.sun.jna.Pointer, com.sun.jna.Pointer, int)} instead
	 */
	@Deprecated 
	short PrtWrite(Pointer LPSTR1, Pointer LPSTR2, int DWORD1);
	/**
	 * Original signature : <code>WORD PrtWrite(LPSTR, LPSTR, DWORD)</code><br>
	 * <i>native declaration : line 910</i>
	 */
	short PrtWrite(ByteBuffer LPSTR1, ByteBuffer LPSTR2, int DWORD1);
	/**
	 * Original signature : <code>WORD PrtWriteBmp(LPSTR, LPVOID)</code><br>
	 * <i>native declaration : line 911</i><br>
	 * @deprecated use the safer methods {@link #PrtWriteBmp(java.nio.ByteBuffer, com.sun.jna.Pointer)} and {@link #PrtWriteBmp(com.sun.jna.Pointer, com.sun.jna.Pointer)} instead
	 */
	@Deprecated 
	short PrtWriteBmp(Pointer LPSTR1, Pointer LPVOID1);
	/**
	 * Original signature : <code>WORD PrtWriteBmp(LPSTR, LPVOID)</code><br>
	 * <i>native declaration : line 911</i>
	 */
	short PrtWriteBmp(ByteBuffer LPSTR1, Pointer LPVOID1);
	/**
	 * Original signature : <code>WORD PrtWriteBmpEx(LPSTR, LPVOID, int)</code><br>
	 * <i>native declaration : line 912</i><br>
	 * @deprecated use the safer methods {@link #PrtWriteBmpEx(java.nio.ByteBuffer, com.sun.jna.Pointer, int)} and {@link #PrtWriteBmpEx(com.sun.jna.Pointer, com.sun.jna.Pointer, int)} instead
	 */
	@Deprecated 
	short PrtWriteBmpEx(Pointer LPSTR1, Pointer LPVOID1, int int1);
	/**
	 * Original signature : <code>WORD PrtWriteBmpEx(LPSTR, LPVOID, int)</code><br>
	 * <i>native declaration : line 912</i>
	 */
	short PrtWriteBmpEx(ByteBuffer LPSTR1, Pointer LPVOID1, int int1);
	/**
	 * Original signature : <code>WORD PrtWriteBmpFromFile(LPSTR, LPSTR, int)</code><br>
	 * <i>native declaration : line 913</i><br>
	 * @deprecated use the safer methods {@link #PrtWriteBmpFromFile(java.nio.ByteBuffer, java.nio.ByteBuffer, int)} and {@link #PrtWriteBmpFromFile(com.sun.jna.Pointer, com.sun.jna.Pointer, int)} instead
	 */
	@Deprecated 
	short PrtWriteBmpFromFile(Pointer LPSTR1, Pointer LPSTR2, int int1);
	/**
	 * Original signature : <code>WORD PrtWriteBmpFromFile(LPSTR, LPSTR, int)</code><br>
	 * <i>native declaration : line 913</i>
	 */
	short PrtWriteBmpFromFile(ByteBuffer LPSTR1, ByteBuffer LPSTR2, int int1);
	/**
	 * lamp setting/resetting<br>
	 * Original signature : <code>WORD PrtPanel(LPSTR, PDAT_PANEL)</code><br>
	 * @param PDAT_PANEL1 lamp setting/resetting<br>
	 * <i>native declaration : line 914</i><br>
	 * @deprecated use the safer methods {@link #PrtPanel(java.nio.ByteBuffer, mb2.DAT_PANEL)} and {@link #PrtPanel(com.sun.jna.Pointer, mb2.DAT_PANEL)} instead
	 */
	@Deprecated 
	short PrtPanel(Pointer LPSTR1, DAT_PANEL PDAT_PANEL1);
	/**
	 * lamp setting/resetting<br>
	 * Original signature : <code>WORD PrtPanel(LPSTR, PDAT_PANEL)</code><br>
	 * @param PDAT_PANEL1 lamp setting/resetting<br>
	 * <i>native declaration : line 914</i>
	 */
	short PrtPanel(ByteBuffer LPSTR1, DAT_PANEL PDAT_PANEL1);
	/**
	 * Original signature : <code>WORD PrtGraph(LPSTR, PBITIMAGE)</code><br>
	 * <i>native declaration : line 915</i><br>
	 * @deprecated use the safer methods {@link #PrtGraph(java.nio.ByteBuffer, mb2.BITIMAGE)} and {@link #PrtGraph(com.sun.jna.Pointer, mb2.BITIMAGE)} instead
	 */
	@Deprecated 
	short PrtGraph(Pointer LPSTR1, BITIMAGE PBITIMAGE1);
	/**
	 * Original signature : <code>WORD PrtGraph(LPSTR, PBITIMAGE)</code><br>
	 * <i>native declaration : line 915</i>
	 */
	short PrtGraph(ByteBuffer LPSTR1, BITIMAGE PBITIMAGE1);
	/**
	 * Original signature : <code>WORD PrtClearbim(LPSTR)</code><br>
	 * <i>native declaration : line 916</i><br>
	 * @deprecated use the safer methods {@link #PrtClearbim(java.nio.ByteBuffer)} and {@link #PrtClearbim(com.sun.jna.Pointer)} instead
	 */
	@Deprecated 
	short PrtClearbim(Pointer LPSTR1);
	/**
	 * Original signature : <code>WORD PrtClearbim(LPSTR)</code><br>
	 * <i>native declaration : line 916</i>
	 */
	short PrtClearbim(ByteBuffer LPSTR1);
	/**
	 * Original signature : <code>WORD PrtDownload(LPSTR, PCHARDEF)</code><br>
	 * <i>native declaration : line 917</i><br>
	 * @deprecated use the safer methods {@link #PrtDownload(java.nio.ByteBuffer, mb2.CHARDEF)} and {@link #PrtDownload(com.sun.jna.Pointer, mb2.CHARDEF)} instead
	 */
	@Deprecated 
	short PrtDownload(Pointer LPSTR1, CHARDEF PCHARDEF1);
	/**
	 * Original signature : <code>WORD PrtDownload(LPSTR, PCHARDEF)</code><br>
	 * <i>native declaration : line 917</i>
	 */
	short PrtDownload(ByteBuffer LPSTR1, CHARDEF PCHARDEF1);
	/**
	 * get document size<br>
	 * Original signature : <code>WORD PrtRead(LPSTR, PSIZEDOC)</code><br>
	 * @param PSIZEDOC1 get document size<br>
	 * <i>native declaration : line 918</i><br>
	 * @deprecated use the safer methods {@link #PrtRead(java.nio.ByteBuffer, mb2.SIZEDOC)} and {@link #PrtRead(com.sun.jna.Pointer, mb2.SIZEDOC)} instead
	 */
	@Deprecated 
	short PrtRead(Pointer LPSTR1, SIZEDOC PSIZEDOC1);
	/**
	 * get document size<br>
	 * Original signature : <code>WORD PrtRead(LPSTR, PSIZEDOC)</code><br>
	 * @param PSIZEDOC1 get document size<br>
	 * <i>native declaration : line 918</i>
	 */
	short PrtRead(ByteBuffer LPSTR1, SIZEDOC PSIZEDOC1);
	/**
	 * get document width<br>
	 * Original signature : <code>WORD PrtReadWidth(LPSTR, LPINT)</code><br>
	 * @param LPINT1 get document width<br>
	 * <i>native declaration : line 919</i><br>
	 * @deprecated use the safer methods {@link #PrtReadWidth(java.nio.ByteBuffer, java.nio.IntBuffer)} and {@link #PrtReadWidth(com.sun.jna.Pointer, com.sun.jna.ptr.IntByReference)} instead
	 */
	@Deprecated 
	short PrtReadWidth(Pointer LPSTR1, IntByReference LPINT1);
	/**
	 * get document width<br>
	 * Original signature : <code>WORD PrtReadWidth(LPSTR, LPINT)</code><br>
	 * @param LPINT1 get document width<br>
	 * <i>native declaration : line 919</i>
	 */
	short PrtReadWidth(ByteBuffer LPSTR1, IntBuffer LPINT1);
	/**
	 * get document distance from left side<br>
	 * Original signature : <code>WORD PrtReadLeftDistance(LPSTR, LPINT)</code><br>
	 * @param LPINT1 get document distance from left side<br>
	 * <i>native declaration : line 920</i><br>
	 * @deprecated use the safer methods {@link #PrtReadLeftDistance(java.nio.ByteBuffer, java.nio.IntBuffer)} and {@link #PrtReadLeftDistance(com.sun.jna.Pointer, com.sun.jna.ptr.IntByReference)} instead
	 */
	@Deprecated 
	short PrtReadLeftDistance(Pointer LPSTR1, IntByReference LPINT1);
	/**
	 * get document distance from left side<br>
	 * Original signature : <code>WORD PrtReadLeftDistance(LPSTR, LPINT)</code><br>
	 * @param LPINT1 get document distance from left side<br>
	 * <i>native declaration : line 920</i>
	 */
	short PrtReadLeftDistance(ByteBuffer LPSTR1, IntBuffer LPINT1);
	/**
	 * taken off from PrtSet()<br>
	 * Original signature : <code>WORD PrtCPI(LPSTR, BYTE)</code><br>
	 * <i>native declaration : line 923</i><br>
	 * @deprecated use the safer methods {@link #PrtCPI(java.nio.ByteBuffer, byte)} and {@link #PrtCPI(com.sun.jna.Pointer, byte)} instead
	 */
	@Deprecated 
	short PrtCPI(Pointer LPSTR1, byte BYTE1);
	/**
	 * taken off from PrtSet()<br>
	 * Original signature : <code>WORD PrtCPI(LPSTR, BYTE)</code><br>
	 * <i>native declaration : line 923</i>
	 */
	short PrtCPI(ByteBuffer LPSTR1, byte BYTE1);
	/**
	 * Original signature : <code>WORD PrtLPI(LPSTR, WORD)</code><br>
	 * <i>native declaration : line 924</i><br>
	 * @deprecated use the safer methods {@link #PrtLPI(java.nio.ByteBuffer, short)} and {@link #PrtLPI(com.sun.jna.Pointer, short)} instead
	 */
	@Deprecated 
	short PrtLPI(Pointer LPSTR1, short WORD1);
	/**
	 * Original signature : <code>WORD PrtLPI(LPSTR, WORD)</code><br>
	 * <i>native declaration : line 924</i>
	 */
	short PrtLPI(ByteBuffer LPSTR1, short WORD1);
	/**
	 * Original signature : <code>WORD PrtQuality(LPSTR, WORD)</code><br>
	 * <i>native declaration : line 925</i><br>
	 * @deprecated use the safer methods {@link #PrtQuality(java.nio.ByteBuffer, short)} and {@link #PrtQuality(com.sun.jna.Pointer, short)} instead
	 */
	@Deprecated 
	short PrtQuality(Pointer LPSTR1, short WORD1);
	/**
	 * Original signature : <code>WORD PrtQuality(LPSTR, WORD)</code><br>
	 * <i>native declaration : line 925</i>
	 */
	short PrtQuality(ByteBuffer LPSTR1, short WORD1);
	/**
	 * WORD PrtModule(LPSTR, BYTE);<br>
	 * Original signature : <code>WORD PrtEscJ(LPSTR, BOOL)</code><br>
	 * <i>native declaration : line 927</i><br>
	 * @deprecated use the safer methods {@link #PrtEscJ(java.nio.ByteBuffer, boolean)} and {@link #PrtEscJ(com.sun.jna.Pointer, boolean)} instead
	 */
	@Deprecated 
	short PrtEscJ(Pointer LPSTR1, boolean BOOL1);
	/**
	 * WORD PrtModule(LPSTR, BYTE);<br>
	 * Original signature : <code>WORD PrtEscJ(LPSTR, BOOL)</code><br>
	 * <i>native declaration : line 927</i>
	 */
	short PrtEscJ(ByteBuffer LPSTR1, boolean BOOL1);
	/**
	 * Original signature : <code>WORD MagnSetH(LPSTR, PSTRIPFORMH)</code><br>
	 * <i>native declaration : line 929</i><br>
	 * @deprecated use the safer methods {@link #MagnSetH(java.nio.ByteBuffer, mb2.STRIPFORMH)} and {@link #MagnSetH(com.sun.jna.Pointer, mb2.STRIPFORMH)} instead
	 */
	@Deprecated 
	short MagnSetH(Pointer LPSTR1, STRIPFORMH PSTRIPFORMH1);
	/**
	 * Original signature : <code>WORD MagnSetH(LPSTR, PSTRIPFORMH)</code><br>
	 * <i>native declaration : line 929</i>
	 */
	short MagnSetH(ByteBuffer LPSTR1, STRIPFORMH PSTRIPFORMH1);
	/**
	 * Original signature : <code>WORD MagnSetV(LPSTR, PSTRIPFORMV)</code><br>
	 * <i>native declaration : line 930</i><br>
	 * @deprecated use the safer methods {@link #MagnSetV(java.nio.ByteBuffer, mb2.STRIPFORMV)} and {@link #MagnSetV(com.sun.jna.Pointer, mb2.STRIPFORMV)} instead
	 */
	@Deprecated 
	short MagnSetV(Pointer LPSTR1, STRIPFORMV PSTRIPFORMV1);
	/**
	 * Original signature : <code>WORD MagnSetV(LPSTR, PSTRIPFORMV)</code><br>
	 * <i>native declaration : line 930</i>
	 */
	short MagnSetV(ByteBuffer LPSTR1, STRIPFORMV PSTRIPFORMV1);
	/**
	 * Original signature : <code>WORD MagnWrite(LPSTR, LPSTR, WORD)</code><br>
	 * <i>native declaration : line 931</i><br>
	 * @deprecated use the safer methods {@link #MagnWrite(java.nio.ByteBuffer, java.nio.ByteBuffer, short)} and {@link #MagnWrite(com.sun.jna.Pointer, com.sun.jna.Pointer, short)} instead
	 */
	@Deprecated 
	short MagnWrite(Pointer LPSTR1, Pointer LPSTR2, short WORD1);
	/**
	 * Original signature : <code>WORD MagnWrite(LPSTR, LPSTR, WORD)</code><br>
	 * <i>native declaration : line 931</i>
	 */
	short MagnWrite(ByteBuffer LPSTR1, ByteBuffer LPSTR2, short WORD1);
	/**
	 * Stripe<br>
	 * Original signature : <code>WORD MagnRead(LPSTR, LPSTR, LPWORD)</code><br>
	 * @param LPWORD1 Stripe<br>
	 * <i>native declaration : line 932</i><br>
	 * @deprecated use the safer methods {@link #MagnRead(java.nio.ByteBuffer, java.nio.ByteBuffer, java.nio.ShortBuffer)} and {@link #MagnRead(com.sun.jna.Pointer, com.sun.jna.Pointer, com.sun.jna.ptr.ShortByReference)} instead
	 */
	@Deprecated 
	short MagnRead(Pointer LPSTR1, Pointer LPSTR2, ShortByReference LPWORD1);
	/**
	 * Stripe<br>
	 * Original signature : <code>WORD MagnRead(LPSTR, LPSTR, LPWORD)</code><br>
	 * @param LPWORD1 Stripe<br>
	 * <i>native declaration : line 932</i>
	 */
	short MagnRead(ByteBuffer LPSTR1, ByteBuffer LPSTR2, ShortBuffer LPWORD1);
	/**
	 * Original signature : <code>WORD MicrSet(LPSTR, PMICRFORM)</code><br>
	 * <i>native declaration : line 933</i><br>
	 * @deprecated use the safer methods {@link #MicrSet(java.nio.ByteBuffer, mb2.MICRFORM)} and {@link #MicrSet(com.sun.jna.Pointer, mb2.MICRFORM)} instead
	 */
	@Deprecated 
	short MicrSet(Pointer LPSTR1, MICRFORM PMICRFORM1);
	/**
	 * Original signature : <code>WORD MicrSet(LPSTR, PMICRFORM)</code><br>
	 * <i>native declaration : line 933</i>
	 */
	short MicrSet(ByteBuffer LPSTR1, MICRFORM PMICRFORM1);
	/**
	 * Original signature : <code>WORD MicrRead(LPSTR, LPSTR, LPWORD)</code><br>
	 * <i>native declaration : line 934</i><br>
	 * @deprecated use the safer methods {@link #MicrRead(java.nio.ByteBuffer, java.nio.ByteBuffer, java.nio.ShortBuffer)} and {@link #MicrRead(com.sun.jna.Pointer, com.sun.jna.Pointer, com.sun.jna.ptr.ShortByReference)} instead
	 */
	@Deprecated 
	short MicrRead(Pointer LPSTR1, Pointer LPSTR2, ShortByReference LPWORD1);
	/**
	 * Original signature : <code>WORD MicrRead(LPSTR, LPSTR, LPWORD)</code><br>
	 * <i>native declaration : line 934</i>
	 */
	short MicrRead(ByteBuffer LPSTR1, ByteBuffer LPSTR2, ShortBuffer LPWORD1);
	/**
	 * Original signature : <code>WORD BarSetWr(LPSTR, PBARCODEWR)</code><br>
	 * <i>native declaration : line 935</i><br>
	 * @deprecated use the safer methods {@link #BarSetWr(java.nio.ByteBuffer, mb2.BARCODEWR)} and {@link #BarSetWr(com.sun.jna.Pointer, mb2.BARCODEWR)} instead
	 */
	@Deprecated 
	short BarSetWr(Pointer LPSTR1, BARCODEWR PBARCODEWR1);
	/**
	 * Original signature : <code>WORD BarSetWr(LPSTR, PBARCODEWR)</code><br>
	 * <i>native declaration : line 935</i>
	 */
	short BarSetWr(ByteBuffer LPSTR1, BARCODEWR PBARCODEWR1);
	/**
	 * Original signature : <code>WORD BarWrite(LPSTR, LPSTR)</code><br>
	 * <i>native declaration : line 936</i><br>
	 * @deprecated use the safer methods {@link #BarWrite(java.nio.ByteBuffer, java.nio.ByteBuffer)} and {@link #BarWrite(com.sun.jna.Pointer, com.sun.jna.Pointer)} instead
	 */
	@Deprecated 
	short BarWrite(Pointer LPSTR1, Pointer LPSTR2);
	/**
	 * Original signature : <code>WORD BarWrite(LPSTR, LPSTR)</code><br>
	 * <i>native declaration : line 936</i>
	 */
	short BarWrite(ByteBuffer LPSTR1, ByteBuffer LPSTR2);
	/**
	 * added for PR2E scanner<br>
	 * Original signature : <code>WORD ScanReadFR(LPSTR, int, PSCANNERFR, long)</code><br>
	 * <i>native declaration : line 939</i><br>
	 * @deprecated use the safer methods {@link #ScanReadFR(java.nio.ByteBuffer, int, mb2.SCANNERFR, com.sun.jna.NativeLong)} and {@link #ScanReadFR(com.sun.jna.Pointer, int, mb2.SCANNERFR, com.sun.jna.NativeLong)} instead
	 */
	@Deprecated 
	short ScanReadFR(Pointer LPSTR1, int int1, SCANNERFR PSCANNERFR1, NativeLong l1);
	/**
	 * added for PR2E scanner<br>
	 * Original signature : <code>WORD ScanReadFR(LPSTR, int, PSCANNERFR, long)</code><br>
	 * <i>native declaration : line 939</i>
	 */
	short ScanReadFR(ByteBuffer LPSTR1, int int1, SCANNERFR PSCANNERFR1, NativeLong l1);
	/**
	 * Original signature : <code>WORD ScanReadMemFR(LPSTR, int, PSCANMEMFR, long)</code><br>
	 * <i>native declaration : line 940</i><br>
	 * @deprecated use the safer methods {@link #ScanReadMemFR(java.nio.ByteBuffer, int, mb2.SCANMEMFR, com.sun.jna.NativeLong)} and {@link #ScanReadMemFR(com.sun.jna.Pointer, int, mb2.SCANMEMFR, com.sun.jna.NativeLong)} instead
	 */
	@Deprecated 
	short ScanReadMemFR(Pointer LPSTR1, int int1, SCANMEMFR PSCANMEMFR1, NativeLong l1);
	/**
	 * Original signature : <code>WORD ScanReadMemFR(LPSTR, int, PSCANMEMFR, long)</code><br>
	 * <i>native declaration : line 940</i>
	 */
	short ScanReadMemFR(ByteBuffer LPSTR1, int int1, SCANMEMFR PSCANMEMFR1, NativeLong l1);
	/**
	 * Original signature : <code>WORD ScanSet(LPSTR, PSCAN_SET)</code><br>
	 * <i>native declaration : line 941</i><br>
	 * @deprecated use the safer methods {@link #ScanSet(java.nio.ByteBuffer, mb2.SCAN_SET)} and {@link #ScanSet(com.sun.jna.Pointer, mb2.SCAN_SET)} instead
	 */
	@Deprecated 
	short ScanSet(Pointer LPSTR1, SCAN_SET PSCAN_SET1);
	/**
	 * Original signature : <code>WORD ScanSet(LPSTR, PSCAN_SET)</code><br>
	 * <i>native declaration : line 941</i>
	 */
	short ScanSet(ByteBuffer LPSTR1, SCAN_SET PSCAN_SET1);
	/**
	 * Original signature : <code>WORD ScanReadFullPaperFR(LPSTR, PSCANNERFR_FULL, long)</code><br>
	 * <i>native declaration : line 942</i><br>
	 * @deprecated use the safer methods {@link #ScanReadFullPaperFR(java.nio.ByteBuffer, mb2.SCANNERFR_FULL, com.sun.jna.NativeLong)} and {@link #ScanReadFullPaperFR(com.sun.jna.Pointer, mb2.SCANNERFR_FULL, com.sun.jna.NativeLong)} instead
	 */
	@Deprecated 
	short ScanReadFullPaperFR(Pointer LPSTR1, SCANNERFR_FULL PSCANNERFR_FULL1, NativeLong l1);
	/**
	 * Original signature : <code>WORD ScanReadFullPaperFR(LPSTR, PSCANNERFR_FULL, long)</code><br>
	 * <i>native declaration : line 942</i>
	 */
	short ScanReadFullPaperFR(ByteBuffer LPSTR1, SCANNERFR_FULL PSCANNERFR_FULL1, NativeLong l1);
	/**
	 * Original signature : <code>WORD ScanReadMemFullPaperFR(LPSTR, PSCANNERFR_FULL, long)</code><br>
	 * <i>native declaration : line 943</i><br>
	 * @deprecated use the safer methods {@link #ScanReadMemFullPaperFR(java.nio.ByteBuffer, mb2.SCANNERFR_FULL, com.sun.jna.NativeLong)} and {@link #ScanReadMemFullPaperFR(com.sun.jna.Pointer, mb2.SCANNERFR_FULL, com.sun.jna.NativeLong)} instead
	 */
	@Deprecated 
	short ScanReadMemFullPaperFR(Pointer LPSTR1, SCANNERFR_FULL PSCANNERFR_FULL1, NativeLong l1);
	/**
	 * Original signature : <code>WORD ScanReadMemFullPaperFR(LPSTR, PSCANNERFR_FULL, long)</code><br>
	 * <i>native declaration : line 943</i>
	 */
	short ScanReadMemFullPaperFR(ByteBuffer LPSTR1, SCANNERFR_FULL PSCANNERFR_FULL1, NativeLong l1);
	/**
	 * Original signature : <code>WORD ScanReadMemRawFR(LPSTR, int, PSCANMEMRAWFR)</code><br>
	 * <i>native declaration : line 944</i><br>
	 * @deprecated use the safer methods {@link #ScanReadMemRawFR(java.nio.ByteBuffer, int, mb2.SCANMEMRAWFR)} and {@link #ScanReadMemRawFR(com.sun.jna.Pointer, int, mb2.SCANMEMRAWFR)} instead
	 */
	@Deprecated 
	short ScanReadMemRawFR(Pointer LPSTR1, int int1, SCANMEMRAWFR PSCANMEMRAWFR1);
	/**
	 * Original signature : <code>WORD ScanReadMemRawFR(LPSTR, int, PSCANMEMRAWFR)</code><br>
	 * <i>native declaration : line 944</i>
	 */
	short ScanReadMemRawFR(ByteBuffer LPSTR1, int int1, SCANMEMRAWFR PSCANMEMRAWFR1);
	/**
	 * ------------------------ added for PR2 PLUS / MB2 / MB2-ADF ----------------------------------------<br>
	 * Original signature : <code>WORD ScanSet_Plus(LPSTR, PSCAN_SET_PLUS)</code><br>
	 * <i>native declaration : line 947</i><br>
	 * @deprecated use the safer methods {@link #ScanSet_Plus(java.nio.ByteBuffer, mb2.SCAN_SET_PLUS)} and {@link #ScanSet_Plus(com.sun.jna.Pointer, mb2.SCAN_SET_PLUS)} instead
	 */
	@Deprecated 
	short ScanSet_Plus(Pointer LPSTR1, SCAN_SET_PLUS PSCAN_SET_PLUS1);
	/**
	 * ------------------------ added for PR2 PLUS / MB2 / MB2-ADF ----------------------------------------<br>
	 * Original signature : <code>WORD ScanSet_Plus(LPSTR, PSCAN_SET_PLUS)</code><br>
	 * <i>native declaration : line 947</i>
	 */
	short ScanSet_Plus(ByteBuffer LPSTR1, SCAN_SET_PLUS PSCAN_SET_PLUS1);
	/**
	 * Original signature : <code>WORD ScanReadFull_Plus(LPSTR, PSCANNER_FULL_PLUS, int, int)</code><br>
	 * <i>native declaration : line 948</i><br>
	 * @deprecated use the safer methods {@link #ScanReadFull_Plus(java.nio.ByteBuffer, mb2.SCANNER_FULL_PLUS, int, int)} and {@link #ScanReadFull_Plus(com.sun.jna.Pointer, mb2.SCANNER_FULL_PLUS, int, int)} instead
	 */
	@Deprecated 
	short ScanReadFull_Plus(Pointer LPSTR1, SCANNER_FULL_PLUS PSCANNER_FULL_PLUS1, int int1, int int2);
	/**
	 * Original signature : <code>WORD ScanReadFull_Plus(LPSTR, PSCANNER_FULL_PLUS, int, int)</code><br>
	 * <i>native declaration : line 948</i>
	 */
	short ScanReadFull_Plus(ByteBuffer LPSTR1, SCANNER_FULL_PLUS PSCANNER_FULL_PLUS1, int int1, int int2);
	/**
	 * Original signature : <code>WORD ScanRead_Plus(LPSTR, PSCANNER_FR_PLUS, PSCANNER_BMP_PLUS, int, int, long)</code><br>
	 * <i>native declaration : line 949</i><br>
	 * @deprecated use the safer methods {@link #ScanRead_Plus(java.nio.ByteBuffer, mb2.SCANNER_FR_PLUS, mb2.SCANNER_BMP_PLUS, int, int, com.sun.jna.NativeLong)} and {@link #ScanRead_Plus(com.sun.jna.Pointer, mb2.SCANNER_FR_PLUS, mb2.SCANNER_BMP_PLUS, int, int, com.sun.jna.NativeLong)} instead
	 */
	@Deprecated 
	short ScanRead_Plus(Pointer LPSTR1, SCANNER_FR_PLUS PSCANNER_FR_PLUS1, SCANNER_BMP_PLUS PSCANNER_BMP_PLUS1, int int1, int int2, NativeLong l1);
	/**
	 * Original signature : <code>WORD ScanRead_Plus(LPSTR, PSCANNER_FR_PLUS, PSCANNER_BMP_PLUS, int, int, long)</code><br>
	 * <i>native declaration : line 949</i>
	 */
	short ScanRead_Plus(ByteBuffer LPSTR1, SCANNER_FR_PLUS PSCANNER_FR_PLUS1, SCANNER_BMP_PLUS PSCANNER_BMP_PLUS1, int int1, int int2, NativeLong l1);
	/**
	 * Original signature : <code>WORD ScanReadRaw_Plus(LPSTR, int, PSCANNER_PLUS)</code><br>
	 * <i>native declaration : line 950</i><br>
	 * @deprecated use the safer methods {@link #ScanReadRaw_Plus(java.nio.ByteBuffer, int, mb2.SCANNER_PLUS)} and {@link #ScanReadRaw_Plus(com.sun.jna.Pointer, int, mb2.SCANNER_PLUS)} instead
	 */
	@Deprecated 
	short ScanReadRaw_Plus(Pointer LPSTR1, int int1, SCANNER_PLUS PSCANNER_PLUS1);
	/**
	 * Original signature : <code>WORD ScanReadRaw_Plus(LPSTR, int, PSCANNER_PLUS)</code><br>
	 * <i>native declaration : line 950</i>
	 */
	short ScanReadRaw_Plus(ByteBuffer LPSTR1, int int1, SCANNER_PLUS PSCANNER_PLUS1);
	/**
	 * ---------------------- added for Infrared & UV  device ---------------<br>
	 * Original signature : <code>WORD ScanSet_PlusEx(LPSTR, PSCAN_SET_PLUS_EX)</code><br>
	 * <i>native declaration : line 953</i><br>
	 * @deprecated use the safer methods {@link #ScanSet_PlusEx(java.nio.ByteBuffer, mb2.SCAN_SET_PLUS_EX)} and {@link #ScanSet_PlusEx(com.sun.jna.Pointer, mb2.SCAN_SET_PLUS_EX)} instead
	 */
	@Deprecated 
	short ScanSet_PlusEx(Pointer name, SCAN_SET_PLUS_EX pScPlus);
	/**
	 * ---------------------- added for Infrared & UV  device ---------------<br>
	 * Original signature : <code>WORD ScanSet_PlusEx(LPSTR, PSCAN_SET_PLUS_EX)</code><br>
	 * <i>native declaration : line 953</i>
	 */
	short ScanSet_PlusEx(ByteBuffer name, SCAN_SET_PLUS_EX pScPlus);
	/**
	 * Original signature : <code>WORD ScanReadFull_PlusEx(LPSTR, PSCANNER_FULL_PLUS_EX, int)</code><br>
	 * <i>native declaration : line 954</i><br>
	 * @deprecated use the safer methods {@link #ScanReadFull_PlusEx(java.nio.ByteBuffer, mb2.SCANNER_FULL_PLUS_EX, int)} and {@link #ScanReadFull_PlusEx(com.sun.jna.Pointer, mb2.SCANNER_FULL_PLUS_EX, int)} instead
	 */
	@Deprecated 
	short ScanReadFull_PlusEx(Pointer name, SCANNER_FULL_PLUS_EX pScPlusEx, int OutputFormat);
	/**
	 * Original signature : <code>WORD ScanReadFull_PlusEx(LPSTR, PSCANNER_FULL_PLUS_EX, int)</code><br>
	 * <i>native declaration : line 954</i>
	 */
	short ScanReadFull_PlusEx(ByteBuffer name, SCANNER_FULL_PLUS_EX pScPlusEx, int OutputFormat);
	/**
	 * Original signature : <code>WORD ScanRead_PlusEx(LPSTR, PSCANNER_PLUS_EX, int)</code><br>
	 * <i>native declaration : line 955</i><br>
	 * @deprecated use the safer methods {@link #ScanRead_PlusEx(java.nio.ByteBuffer, mb2.SCANNER_PLUS_EX, int)} and {@link #ScanRead_PlusEx(com.sun.jna.Pointer, mb2.SCANNER_PLUS_EX, int)} instead
	 */
	@Deprecated 
	short ScanRead_PlusEx(Pointer name, SCANNER_PLUS_EX pScPlusEx, int OutputFormat);
	/**
	 * Original signature : <code>WORD ScanRead_PlusEx(LPSTR, PSCANNER_PLUS_EX, int)</code><br>
	 * <i>native declaration : line 955</i>
	 */
	short ScanRead_PlusEx(ByteBuffer name, SCANNER_PLUS_EX pScPlusEx, int OutputFormat);
	/**
	 * --------------------------------<br>
	 * Original signature : <code>WORD PrtGetRelease(LPSTR, PFIRMWAREID)</code><br>
	 * <i>native declaration : line 1005</i><br>
	 * @deprecated use the safer methods {@link #PrtGetRelease(java.nio.ByteBuffer, mb2.FIRMWAREID)} and {@link #PrtGetRelease(com.sun.jna.Pointer, mb2.FIRMWAREID)} instead
	 */
	@Deprecated 
	short PrtGetRelease(Pointer LPSTR1, FIRMWAREID PFIRMWAREID1);
	/**
	 * --------------------------------<br>
	 * Original signature : <code>WORD PrtGetRelease(LPSTR, PFIRMWAREID)</code><br>
	 * <i>native declaration : line 1005</i>
	 */
	short PrtGetRelease(ByteBuffer LPSTR1, FIRMWAREID PFIRMWAREID1);
	/**
	 * Original signature : <code>WORD PrtPosMetricV(LPSTR, char, short)</code><br>
	 * <i>native declaration : line 1006</i><br>
	 * @deprecated use the safer methods {@link #PrtPosMetricV(java.nio.ByteBuffer, byte, short)} and {@link #PrtPosMetricV(com.sun.jna.Pointer, byte, short)} instead
	 */
	@Deprecated 
	short PrtPosMetricV(Pointer LPSTR1, byte char1, short s1);
	/**
	 * Original signature : <code>WORD PrtPosMetricV(LPSTR, char, short)</code><br>
	 * <i>native declaration : line 1006</i>
	 */
	short PrtPosMetricV(ByteBuffer LPSTR1, byte char1, short s1);
	/**
	 * Original signature : <code>WORD PrtPosMetricH(LPSTR, char, short)</code><br>
	 * <i>native declaration : line 1007</i><br>
	 * @deprecated use the safer methods {@link #PrtPosMetricH(java.nio.ByteBuffer, byte, short)} and {@link #PrtPosMetricH(com.sun.jna.Pointer, byte, short)} instead
	 */
	@Deprecated 
	short PrtPosMetricH(Pointer LPSTR1, byte char1, short s1);
	/**
	 * Original signature : <code>WORD PrtPosMetricH(LPSTR, char, short)</code><br>
	 * <i>native declaration : line 1007</i>
	 */
	short PrtPosMetricH(ByteBuffer LPSTR1, byte char1, short s1);
	/**
	 * Original signature : <code>WORD PrtTestDoc(LPSTR, LPWORD)</code><br>
	 * <i>native declaration : line 1008</i><br>
	 * @deprecated use the safer methods {@link #PrtTestDoc(java.nio.ByteBuffer, java.nio.ShortBuffer)} and {@link #PrtTestDoc(com.sun.jna.Pointer, com.sun.jna.ptr.ShortByReference)} instead
	 */
	@Deprecated 
	short PrtTestDoc(Pointer LPSTR1, ShortByReference LPWORD1);
	/**
	 * Original signature : <code>WORD PrtTestDoc(LPSTR, LPWORD)</code><br>
	 * <i>native declaration : line 1008</i>
	 */
	short PrtTestDoc(ByteBuffer LPSTR1, ShortBuffer LPWORD1);
	/**
	 * Original signature : <code>WORD CleanRxBuffer(LPSTR)</code><br>
	 * <i>native declaration : line 1010</i><br>
	 * @deprecated use the safer methods {@link #CleanRxBuffer(java.nio.ByteBuffer)} and {@link #CleanRxBuffer(com.sun.jna.Pointer)} instead
	 */
	@Deprecated 
	short CleanRxBuffer(Pointer LPSTR1);
	/**
	 * Original signature : <code>WORD CleanRxBuffer(LPSTR)</code><br>
	 * <i>native declaration : line 1010</i>
	 */
	short CleanRxBuffer(ByteBuffer LPSTR1);
	/**
	 * Original signature : <code>WORD DrvOpenSilent(LPSTR, PSETUPPRT, PDAT_CONF)</code><br>
	 * <i>native declaration : line 1012</i><br>
	 * @deprecated use the safer methods {@link #DrvOpenSilent(java.nio.ByteBuffer, mb2.SETUPPRT, mb2.DAT_CONF)} and {@link #DrvOpenSilent(com.sun.jna.Pointer, mb2.SETUPPRT, mb2.DAT_CONF)} instead
	 */
	@Deprecated 
	short DrvOpenSilent(Pointer LPSTR1, SETUPPRT PSETUPPRT1, DAT_CONF PDAT_CONF1);
	/**
	 * Original signature : <code>WORD DrvOpenSilent(LPSTR, PSETUPPRT, PDAT_CONF)</code><br>
	 * <i>native declaration : line 1012</i>
	 */
	short DrvOpenSilent(ByteBuffer LPSTR1, SETUPPRT PSETUPPRT1, DAT_CONF PDAT_CONF1);
	/**
	 * Original signature : <code>WORD DrvCloseAndRestoreMode(LPSTR)</code><br>
	 * <i>native declaration : line 1013</i><br>
	 * @deprecated use the safer methods {@link #DrvCloseAndRestoreMode(java.nio.ByteBuffer)} and {@link #DrvCloseAndRestoreMode(com.sun.jna.Pointer)} instead
	 */
	@Deprecated 
	short DrvCloseAndRestoreMode(Pointer LPSTR1);
	/**
	 * Original signature : <code>WORD DrvCloseAndRestoreMode(LPSTR)</code><br>
	 * <i>native declaration : line 1013</i>
	 */
	short DrvCloseAndRestoreMode(ByteBuffer LPSTR1);
	/**
	 * Original signature : <code>BOOLEAN DrvIsUSBopened()</code><br>
	 * <i>native declaration : line 1014</i>
	 */
	byte DrvIsUSBopened();
	/**
	 * Original signature : <code>WORD PrtSetSpecialDoc(LPSTR, int, int, int)</code><br>
	 * <i>native declaration : line 1015</i><br>
	 * @deprecated use the safer methods {@link #PrtSetSpecialDoc(java.nio.ByteBuffer, int, int, int)} and {@link #PrtSetSpecialDoc(com.sun.jna.Pointer, int, int, int)} instead
	 */
	@Deprecated 
	short PrtSetSpecialDoc(Pointer LPSTR1, int int1, int int2, int int3);
	/**
	 * Original signature : <code>WORD PrtSetSpecialDoc(LPSTR, int, int, int)</code><br>
	 * <i>native declaration : line 1015</i>
	 */
	short PrtSetSpecialDoc(ByteBuffer LPSTR1, int int1, int int2, int int3);
	/**
	 * Original signature : <code>WORD ScanSetOverscan_Plus(LPSTR, int, int)</code><br>
	 * <i>native declaration : line 1016</i><br>
	 * @deprecated use the safer methods {@link #ScanSetOverscan_Plus(java.nio.ByteBuffer, int, int)} and {@link #ScanSetOverscan_Plus(com.sun.jna.Pointer, int, int)} instead
	 */
	@Deprecated 
	short ScanSetOverscan_Plus(Pointer LPSTR1, int int1, int int2);
	/**
	 * Original signature : <code>WORD ScanSetOverscan_Plus(LPSTR, int, int)</code><br>
	 * <i>native declaration : line 1016</i>
	 */
	short ScanSetOverscan_Plus(ByteBuffer LPSTR1, int int1, int int2);
	/**
	 * Original signature : <code>WORD MntReadCounter(LPSTR, WORD, LPDWORD, WORD)</code><br>
	 * <i>native declaration : line 1036</i><br>
	 * @deprecated use the safer methods {@link #MntReadCounter(java.nio.ByteBuffer, short, java.nio.IntBuffer, short)} and {@link #MntReadCounter(com.sun.jna.Pointer, short, com.sun.jna.ptr.IntByReference, short)} instead
	 */
	@Deprecated 
	short MntReadCounter(Pointer LPSTR1, short WORD1, IntByReference LPDWORD1, short WORD2);
	/**
	 * Original signature : <code>WORD MntReadCounter(LPSTR, WORD, LPDWORD, WORD)</code><br>
	 * <i>native declaration : line 1036</i>
	 */
	short MntReadCounter(ByteBuffer LPSTR1, short WORD1, IntBuffer LPDWORD1, short WORD2);
	/**
	 * Original signature : <code>WORD MntResetCounter(LPSTR, WORD, WORD)</code><br>
	 * <i>native declaration : line 1037</i><br>
	 * @deprecated use the safer methods {@link #MntResetCounter(java.nio.ByteBuffer, short, short)} and {@link #MntResetCounter(com.sun.jna.Pointer, short, short)} instead
	 */
	@Deprecated 
	short MntResetCounter(Pointer LPSTR1, short WORD1, short WORD2);
	/**
	 * Original signature : <code>WORD MntResetCounter(LPSTR, WORD, WORD)</code><br>
	 * <i>native declaration : line 1037</i>
	 */
	short MntResetCounter(ByteBuffer LPSTR1, short WORD1, short WORD2);
	/**
	 * Original signature : <code>WORD MntReadID(LPSTR, LPSTR, LPSTR)</code><br>
	 * <i>native declaration : line 1038</i><br>
	 * @deprecated use the safer methods {@link #MntReadID(java.nio.ByteBuffer, java.nio.ByteBuffer, java.nio.ByteBuffer)} and {@link #MntReadID(com.sun.jna.Pointer, com.sun.jna.Pointer, com.sun.jna.Pointer)} instead
	 */
	@Deprecated 
	short MntReadID(Pointer LPSTR1, Pointer LPSTR2, Pointer LPSTR3);
	/**
	 * Original signature : <code>WORD MntReadID(LPSTR, LPSTR, LPSTR)</code><br>
	 * <i>native declaration : line 1038</i>
	 */
	short MntReadID(ByteBuffer LPSTR1, ByteBuffer LPSTR2, ByteBuffer LPSTR3);
	/**
	 * Original signature : <code>WORD MntWriteID(LPSTR, LPSTR)</code><br>
	 * <i>native declaration : line 1039</i><br>
	 * @deprecated use the safer methods {@link #MntWriteID(java.nio.ByteBuffer, java.nio.ByteBuffer)} and {@link #MntWriteID(com.sun.jna.Pointer, com.sun.jna.Pointer)} instead
	 */
	@Deprecated 
	short MntWriteID(Pointer LPSTR1, Pointer LPSTR2);
	/**
	 * Original signature : <code>WORD MntWriteID(LPSTR, LPSTR)</code><br>
	 * <i>native declaration : line 1039</i>
	 */
	short MntWriteID(ByteBuffer LPSTR1, ByteBuffer LPSTR2);
	/**
	 * enable-disable ADF<br>
	 * Original signature : <code>WORD PrtADF(LPSTR, int)</code><br>
	 * @param int1 enable-disable ADF<br>
	 * <i>native declaration : line 1047</i><br>
	 * @deprecated use the safer methods {@link #PrtADF(java.nio.ByteBuffer, int)} and {@link #PrtADF(com.sun.jna.Pointer, int)} instead
	 */
	@Deprecated 
	short PrtADF(Pointer LPSTR1, int int1);
	/**
	 * enable-disable ADF<br>
	 * Original signature : <code>WORD PrtADF(LPSTR, int)</code><br>
	 * @param int1 enable-disable ADF<br>
	 * <i>native declaration : line 1047</i>
	 */
	short PrtADF(ByteBuffer LPSTR1, int int1);
	/**
	 * get adf status<br>
	 * Original signature : <code>WORD PrtGetADFStatus(LPSTR, LPINT)</code><br>
	 * @param LPINT1 get adf status<br>
	 * <i>native declaration : line 1048</i><br>
	 * @deprecated use the safer methods {@link #PrtGetADFStatus(java.nio.ByteBuffer, java.nio.IntBuffer)} and {@link #PrtGetADFStatus(com.sun.jna.Pointer, com.sun.jna.ptr.IntByReference)} instead
	 */
	@Deprecated 
	short PrtGetADFStatus(Pointer LPSTR1, IntByReference LPINT1);
	/**
	 * get adf status<br>
	 * Original signature : <code>WORD PrtGetADFStatus(LPSTR, LPINT)</code><br>
	 * @param LPINT1 get adf status<br>
	 * <i>native declaration : line 1048</i>
	 */
	short PrtGetADFStatus(ByteBuffer LPSTR1, IntBuffer LPINT1);
	/**
	 * sorter pre-selection<br>
	 * Original signature : <code>WORD PrtSetSorter(LPSTR, int)</code><br>
	 * @param int1 sorter pre-selection<br>
	 * <i>native declaration : line 1049</i><br>
	 * @deprecated use the safer methods {@link #PrtSetSorter(java.nio.ByteBuffer, int)} and {@link #PrtSetSorter(com.sun.jna.Pointer, int)} instead
	 */
	@Deprecated 
	short PrtSetSorter(Pointer LPSTR1, int int1);
	/**
	 * sorter pre-selection<br>
	 * Original signature : <code>WORD PrtSetSorter(LPSTR, int)</code><br>
	 * @param int1 sorter pre-selection<br>
	 * <i>native declaration : line 1049</i>
	 */
	short PrtSetSorter(ByteBuffer LPSTR1, int int1);
	/**
	 * double feecd setup<br>
	 * Original signature : <code>WORD PrtSetupDoubleFeed(LPSTR, BYTE, BYTE, BYTE, BYTE)</code><br>
	 * @param BYTE4 double feecd setup<br>
	 * <i>native declaration : line 1050</i><br>
	 * @deprecated use the safer methods {@link #PrtSetupDoubleFeed(java.nio.ByteBuffer, byte, byte, byte, byte)} and {@link #PrtSetupDoubleFeed(com.sun.jna.Pointer, byte, byte, byte, byte)} instead
	 */
	@Deprecated 
	short PrtSetupDoubleFeed(Pointer LPSTR1, byte BYTE1, byte BYTE2, byte BYTE3, byte BYTE4);
	/**
	 * double feecd setup<br>
	 * Original signature : <code>WORD PrtSetupDoubleFeed(LPSTR, BYTE, BYTE, BYTE, BYTE)</code><br>
	 * @param BYTE4 double feecd setup<br>
	 * <i>native declaration : line 1050</i>
	 */
	short PrtSetupDoubleFeed(ByteBuffer LPSTR1, byte BYTE1, byte BYTE2, byte BYTE3, byte BYTE4);
	/**
	 * set the image quality for JPEG/PDF scanning<br>
	 * Original signature : <code>WORD ScanSetJpegQuality_Plus(LPSTR, int)</code><br>
	 * @param int1 set the image quality for JPEG/PDF scanning<br>
	 * <i>native declaration : line 1051</i><br>
	 * @deprecated use the safer methods {@link #ScanSetJpegQuality_Plus(java.nio.ByteBuffer, int)} and {@link #ScanSetJpegQuality_Plus(com.sun.jna.Pointer, int)} instead
	 */
	@Deprecated 
	short ScanSetJpegQuality_Plus(Pointer LPSTR1, int int1);
	/**
	 * set the image quality for JPEG/PDF scanning<br>
	 * Original signature : <code>WORD ScanSetJpegQuality_Plus(LPSTR, int)</code><br>
	 * @param int1 set the image quality for JPEG/PDF scanning<br>
	 * <i>native declaration : line 1051</i>
	 */
	short ScanSetJpegQuality_Plus(ByteBuffer LPSTR1, int int1);
}
