package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class SCANRECTFR extends Structure {
	public int startx;
	public int starty;
	public int endx;
	public int endy;
	/** C type : char[512] */
	public byte[] BitmapNameF = new byte[512];
	/** C type : char[512] */
	public byte[] BitmapNameR = new byte[512];
	public SCANRECTFR() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("startx", "starty", "endx", "endy", "BitmapNameF", "BitmapNameR");
	}
	/**
	 * @param BitmapNameF C type : char[512]<br>
	 * @param BitmapNameR C type : char[512]
	 */
	public SCANRECTFR(int startx, int starty, int endx, int endy, byte BitmapNameF[], byte BitmapNameR[]) {
		super();
		this.startx = startx;
		this.starty = starty;
		this.endx = endx;
		this.endy = endy;
		if ((BitmapNameF.length != this.BitmapNameF.length)) 
			throw new IllegalArgumentException("Wrong array size !");
		this.BitmapNameF = BitmapNameF;
		if ((BitmapNameR.length != this.BitmapNameR.length)) 
			throw new IllegalArgumentException("Wrong array size !");
		this.BitmapNameR = BitmapNameR;
	}
	public SCANRECTFR(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends SCANRECTFR implements Structure.ByReference {
		
	};
	public static class ByValue extends SCANRECTFR implements Structure.ByValue {
		
	};
}

