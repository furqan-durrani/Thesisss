package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class SETUPPRT extends Structure {
	public short Baud;
	/** 'N', 'O', 'E' */
	public byte Parity;
	/** 7, 8 */
	public byte Data;
	/** 1, 2 */
	public byte Stop;
	/** OLIMODE, IBMMODE */
	public byte Devmode;
	public SETUPPRT() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("Baud", "Parity", "Data", "Stop", "Devmode");
	}
	/**
	 * @param Parity 'N', 'O', 'E'<br>
	 * @param Data 7, 8<br>
	 * @param Stop 1, 2<br>
	 * @param Devmode OLIMODE, IBMMODE
	 */
	public SETUPPRT(short Baud, byte Parity, byte Data, byte Stop, byte Devmode) {
		super();
		this.Baud = Baud;
		this.Parity = Parity;
		this.Data = Data;
		this.Stop = Stop;
		this.Devmode = Devmode;
	}
	public SETUPPRT(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends SETUPPRT implements Structure.ByReference {
		
	};
	public static class ByValue extends SETUPPRT implements Structure.ByValue {
		
	};
}
