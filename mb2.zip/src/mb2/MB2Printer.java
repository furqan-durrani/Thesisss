package mb2;


import java.util.StringTokenizer;
import java.util.Arrays;
import java.util.List;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

//
// UTILITY & HELPER FUNCTIONS
//

public class MB2Printer {
	
    public Boolean IsOpened=false;

    public String GetErrorString(short ErrorCode)
    {
      switch (ErrorCode)
      {
        case MB2Library.PR_OK: return "PR_OK";
        case MB2Library.PR_NO_OPEN: return "PR_NO_OPEN";
        case MB2Library.PR_ALR_OPEN: return "PR_ALR_OPEN";
        case MB2Library.PR_ABORTED: return "PR_ABORTED";
        case MB2Library.PR_NO_MEMORY: return "PR_NO_MEMORY";
        case MB2Library.PR_NOT_OWNED: return "PR_NOT_OWNED";
        case MB2Library.PR_BIM: return "PR_BIM";
        case MB2Library.PR_BUSY: return "PR_BUSY";
        case MB2Library.PR_NOT_SET: return "PR_NOT_SET";
        case MB2Library.PR_SWITCHED_OFF: return "PR_SWITCHED_OFF";
        case MB2Library.PR_NOT_SUPPORTED: return "PR_NOT_SUPPORTED";
        case MB2Library.PR_ERR_COMMAPI: return "PR_ERR_COMMAPI";
        case MB2Library.PR_BAD_RESPONSE: return "PR_BAD_RESPONSE";
        case MB2Library.PR_BAD_PARAMETER: return "PR_BAD_PARAMETER";
        case MB2Library.PR_BADBUF: return "PR_BADBUF";
        case MB2Library.PR_PORT_BUSY: return "PR_PORT_BUSY";
        /* serial-interface errors */
        case MB2Library.PR_RX_OVERRUN: return "PR_RX_OVERRUN";
        case MB2Library.PR_PARITY_ERR: return "PR_PARITY_ERR";
        case MB2Library.PR_FRAMING_ERR: return "PR_FRAMING_ERR";
        case MB2Library.PR_TX_OVERRUN: return "PR_TX_OVERRUN";
        case MB2Library.PR_RX_BREAK: return "PR_RX_BREAK";
        case MB2Library.PR_HUNG: return "PR_HUNG";
        case MB2Library.PR_DISCONNECTED: return "PR_DISCONNECTED";
        /* physical errors */
        case MB2Library.PR_PAPJAM: return "PR_PAPJAM";
        case MB2Library.PR_NULLEN: return "PR_NULLEN";
        case MB2Library.PR_NOMAGN: return "PR_NOMAGN";
        case MB2Library.PR_ERR_STRIPE: return "PR_ERR_STRIPE";
        case MB2Library.PR_NOSCANNER: return "PR_NOSCANNER";
        case MB2Library.PR_NOSCANNER_REAR: return "PR_NOSCANNER_REAR";
        case MB2Library.PR_NOSCANNER_FRONT: return "PR_NOSCANNER_FRONT";
        case MB2Library.PR_NOMICR: return "PR_NOMICR";
        case MB2Library.PR_LOCAL: return "PR_LOCAL";
        case MB2Library.PR_ERR_LINE: return "PR_ERR_LINE";
        case MB2Library.PR_CARTER: return "PR_CARTER";
        case MB2Library.PR_STRIPE_NODATA: return "PR_STRIPE_NODATA";
        case MB2Library.PR_WRN_EOP: return "PR_WRN_EOP";
        case MB2Library.PR_NO_DOC: return "PR_NO_DOC";
        case MB2Library.PR_BAD_COMMAND: return "PR_BAD_COMMAND";
        case MB2Library.PR_HWERR: return "PR_HWERR";
        case MB2Library.PR_TXTIMEOUT: return "PR_TXTIMEOUT";
        case MB2Library.PR_RXTIMEOUT: return "PR_RXTIMEOUT";
        case MB2Library.PR_ERRTYPE: return "PR_ERRTYPE";
        case MB2Library.PR_BADSTRIP: return "PR_BADSTRIP";
        case MB2Library.PR_WRN_LOCCART: return "PR_WRN_LOCCART";
        case MB2Library.PR_WRN_SOF: return "PR_WRN_SOF";
        case MB2Library.PR_WRN_DOC: return "PR_WRN_DOC";
        case MB2Library.PR_DOC_NOT_ALIGNED: return "PR_DOC_NOT_ALIGNED";
        default: return "UNKNOWN_ERROR";
      }
    }

    private Boolean BitIsSet(long Value, int Bit) {
    	if (Bit <= 0) return false;
    	return java.math.BigInteger.valueOf(Value).testBit(Bit);
    }

    public Boolean Close()
    {
        short w_rc;           
        gPort.Global = "USB01";
        w_rc = MB2Library.INSTANCE.DrvClose(ByteBuffer.wrap(Native.toByteArray(gPort.Global)));

        if (w_rc != 0)
            return false;
        
        IsOpened = false;
        return true;
    }

    public Boolean Eject ()
    {
		//eject paper
		MB2Library.INSTANCE.PrtOutput (ByteBuffer.wrap(Native.toByteArray(gPort.Global)), MB2Library.FRONTSLOT);
		return true;
    }
    
    public short Eject(int where)
    {
      return MB2Library.INSTANCE.PrtOutput(ByteBuffer.wrap(Native.toByteArray(gPort.Global)), (int)where);
    }

    public short OpenPort(String Port, Boolean Reset) {

        short w_rc;

        SETUPPRT PrinterPortConf = new SETUPPRT();
        DAT_CONF OpenDataConf = new DAT_CONF();
        DAT_FORM PrinterSettingConf = new DAT_FORM();
        String PrinterType;

        if (Port.equalsIgnoreCase("USB"))
            gPort.Global = "USB01";
        else
            gPort.Global = Port;

        //To open port we must initialize OpenDataConfig structure
        OpenDataConf.align_type = 0;
        OpenDataConf.cheque_devs = new NativeLong(0);
        OpenDataConf.devmode = 0;
        OpenDataConf.ext_opts = new NativeLong(0);
        OpenDataConf.int_opts = new NativeLong(0);
        OpenDataConf.primarydev = 0;
        OpenDataConf.prtype = 0;
        OpenDataConf.strip_type = 0;

        //Initialize PrinterPortConf structure
        PrinterPortConf.Baud = 9600;
        PrinterPortConf.Parity = (byte)
        'N';
        PrinterPortConf.Data = 8;
        PrinterPortConf.Stop = 1;
        PrinterPortConf.Devmode = MB2Library.OLIMODE;

        //open Printer
        if (Reset)
            w_rc = MB2Library.INSTANCE.DrvOpen(ByteBuffer.wrap(Native.toByteArray(gPort.Global)), PrinterPortConf, OpenDataConf);
        else
            w_rc = MB2Library.INSTANCE.DrvOpenSilent(ByteBuffer.wrap(Native.toByteArray(gPort.Global)), PrinterPortConf, OpenDataConf);

        if (w_rc != (short) MB2Library.PR_OK)
            return w_rc;

        gPort.HasMagneticH = false;
        gPort.HasMagneticV80 = false;
        gPort.HasMagneticV160 = false;
        gPort.ScanToMem = false;

        if (OpenDataConf.prtype == MB2Library.PR2E_PLUS_TYPE)
            PrinterType = "Pr2 Plus";
        else if (OpenDataConf.prtype == MB2Library.PR2TYPE)
            PrinterType = "Pr2";
        else
            PrinterType = "none";

        gPort.PrType = PrinterType;

        if (BitIsSet(OpenDataConf.int_opts.longValue(), MB2Library.HAS_MICR))
            gPort.HasMicr = true;
        if (BitIsSet(OpenDataConf.int_opts.longValue(), MB2Library.HAS_SCANNER))
            gPort.HasScanner = true;
        if (BitIsSet(OpenDataConf.int_opts.longValue(), MB2Library.HAS_ADF))
            gPort.HasADF = true;

        if (BitIsSet(OpenDataConf.int_opts.longValue(), MB2Library.HAS_MAGN))
            if (OpenDataConf.strip_type == MB2Library.HORIZONTAL)
                gPort.HasMagneticH = true;
        if (OpenDataConf.strip_type == MB2Library.VERT080BPI)
            gPort.HasMagneticV80 = true;
        if (OpenDataConf.strip_type == MB2Library.VERT160BPI)
            gPort.HasMagneticV160 = true;

        //On all print we must PrtSet
        PrinterSettingConf.cutter_pos = 0;
        PrinterSettingConf.doctype = (byte)MB2Library.SINGLEDOC;
        PrinterSettingConf.cpi = (byte)MB2Library.CPI10;
        PrinterSettingConf.quality = MB2Library.PRT_DRAFT0;
        PrinterSettingConf.lpi = 0;
        PrinterSettingConf.lineno = 140;
        PrinterSettingConf.step_offset = 43;
        PrinterSettingConf.Left_margin = 0;
        PrinterSettingConf.input_dev = 1;
        PrinterSettingConf.output_dev = 1;

        /*
        Pointer pointer;
        byte[] data = Native.toByteArray("USB01");
        pointer = new com.sun.jna.Memory(data.length + 1);
        pointer.write(0, data, 0, data.length);
        pointer.setByte(data.length, (byte)0);

        */
        
        w_rc = MB2Library.INSTANCE.PrtSet(ByteBuffer.wrap(Native.toByteArray(gPort.Global)), PrinterSettingConf);
        if (w_rc == (short) MB2Library.PR_OK)
            IsOpened = true;

        return w_rc;
    }
    
    public Boolean PrintTextLine(String BuffLine, short Ncol, short Nline, byte Cpi, short Qlty, short CharSet) {

    	short w_rc;

        if (CharSet >= 0) {
            w_rc = MB2Library.INSTANCE.PrtSetChar(ByteBuffer.wrap(Native.toByteArray(gPort.Global)), CharSet);
        }

        if (Cpi >= 0) {
            w_rc = MB2Library.INSTANCE.PrtCPI(ByteBuffer.wrap(Native.toByteArray(gPort.Global)), Cpi);
        }

        if (Qlty >= 0) {
            w_rc = MB2Library.INSTANCE.PrtQuality(ByteBuffer.wrap(Native.toByteArray(gPort.Global)), Qlty);
        }

        w_rc = MB2Library.INSTANCE.PrtInput(ByteBuffer.wrap(Native.toByteArray(gPort.Global)), 1);

        if (w_rc != (short) MB2Library.PR_OK)
            return false;

        //print from n-col and n-line
        if (Nline >= 0) {
            w_rc = MB2Library.INSTANCE.PrtPositionV(ByteBuffer.wrap(Native.toByteArray(gPort.Global)), (byte)'L', Nline);
            if (w_rc != (short) MB2Library.PR_OK)
                return false;
        }
        if (Ncol >= 0) {
            w_rc = MB2Library.INSTANCE.PrtPositionH(ByteBuffer.wrap(Native.toByteArray(gPort.Global)), (byte)'L', Ncol);
            if (w_rc != (short) MB2Library.PR_OK)
                return false;
        }

        w_rc = MB2Library.INSTANCE.PrtWrite(ByteBuffer.wrap(Native.toByteArray(gPort.Global)), ByteBuffer.wrap(BuffLine.getBytes()), (short) BuffLine.length());
        
        if (w_rc != (short) MB2Library.PR_OK)
            return false;

        return true;
    }

    public void PrintText(String Buff) {
    	
    	if (Buff==null || Buff.isEmpty()) return;
    	
    	Boolean b_rc=true;
    	Buff = Buff.replace("\r", "");
    	String[] BuffList = Buff.split("\n");

	    try {
	        short rc = OpenPort("USB", true);
	        if (((rc != (short) MB2Library.PR_OK)) && (rc != (short) MB2Library.PR_ALR_OPEN)) {
	            System.out.println("Open Port Error");
	            System.out.println(GetErrorString(rc));
	            return;
	        }

	        int rowNumbers = 1;
        	for (String s: BuffList) {
        	    System.out.println(s);
                b_rc = PrintTextLine(s, (short)1, (short)++rowNumbers, (byte)MB2Library.CPIDFLT, (short)MB2Library.PRT_DRAFT0, (short)700 /*PC_437_International*/ );
                if (!b_rc) {
    	            System.out.println("Print error!");
                    rc = Eject(MB2Library.FRONTSLOT);
                    return;
                }
        	}
        	
            rc = Eject(MB2Library.FRONTSLOT);

	    } catch (UnsatisfiedLinkError e) {
	        System.err.println("Native code library failed to load.\n" + e);
	        System.exit(1);
	    }

        System.out.println("test completed");
    }
    
    public Boolean ReadMicr(StringBuilder MicrDataOut)
    {
        short w_rc;

        MICRFORM MicrSetParameter = new MICRFORM();

        MicrSetParameter.autom = 0;
        MicrSetParameter.font = (byte)MB2Library.MICR_E13B;
        MicrSetParameter.retries = 3;
        MicrSetParameter.space_detect = 0;

        w_rc = MB2Library.INSTANCE.MicrSet(ByteBuffer.wrap(Native.toByteArray(gPort.Global)), MicrSetParameter);

        if (w_rc != 0)
        {
            if (w_rc == 797)    //No micr
            {
                MicrDataOut.append("Micr is not present");
                return false;
            }
            else
            {
                MicrDataOut.append("Micr set Failure");
                return false;
            }
        }
        
        ByteBuffer byteBuffer = ByteBuffer.wrap(Native.toByteArray(String.format("%-101s", new String("\00x20")))); // 101 spaces to byte array
        w_rc = MB2Library.INSTANCE.MicrRead(ByteBuffer.wrap(Native.toByteArray(gPort.Global)), byteBuffer, ShortBuffer.wrap(new short[] {100}));
        
        if (w_rc != 0)
        {
          if( (w_rc == MB2Library.PR_NO_DOC) 
        		  || (w_rc == MB2Library.PR_ERR_COMMAPI) 
        		  || (w_rc == MB2Library.PR_LOCAL) 
        		  || (w_rc == MB2Library.PR_PAPJAM))
            MicrDataOut.append("UNRECOVERABLE ERROR");
          else
            MicrDataOut.append("Micr read Failed");
          return false;
        }

        MicrDataOut.append(new String(byteBuffer.array()));

        return true;
    }

    
    
    
    

    
    
    public short Scan(String fileName
    		, short ScanMode                        //    SCAN_FRONT = 0, SCAN_REAR = 1, SCAN_FRONT_REAR = 2
    		, short ImageBPP                        //    BITS_PER_PIXEL_1 = 1, BITS_PER_PIXEL_4 = 4, BITS_PER_PIXEL_8 = 8, BITS_PER_PIXEL_24 = 24
    		, short DPI                             //    SC_RESOLUTION_203 = 1, SC_RESOLUTION_200 =	2, SC_RESOLUTION_300	= 3, SC_RESOLUTION_600	= 4
    		, short AcqType                         //    SC_REAR_FORWARD_FRONT_FORWARD = 1, SC_REAR_FORWARD_FRONT_REVERSE = 2, SC_REAR_REVERSE_FRONT_FORWARD = 3, SC_REAR_REVERSE_FRONT_REVERSE = 4
    		, Boolean AutomaticEject
    		, Float StartX
    		, Float StartY
    		, Float EndX
    		, Float EndY
    		, short OutputFomat                     //    SCAN_OUTPUT_FORMAT_MEM_BMP = 0, SCAN_OUTPUT_FORMAT_FILE_BMP = 1, SCAN_OUTPUT_FORMAT_MEM_JPEG = 2, SCAN_OUTPUT_FORMAT_FILE_JPEG = 3, SCAN_OUTPUT_FORMAT_MEM_PDF = 4, SCAN_OUTPUT_FORMAT_FILE_PDF = 5
    		, int ExtImgType)
    {
      short w_rc;
      
      StringBuilder BitmapNameF = new StringBuilder();
      StringBuilder BitmapNameR = new StringBuilder();
      StringBuilder BitmapNameF_IR = new StringBuilder();
      StringBuilder BitmapNameR_IR = new StringBuilder();
      StringBuilder BitmapNameF_UV = new StringBuilder();
      StringBuilder BitmapNameR_UV = new StringBuilder();

      int MaxH, MaxW, Resolution;

      SCAN_SET_PLUS_EX ScanSetPlusEx = new SCAN_SET_PLUS_EX();
      SCANNER_PLUS_EX m_ScanPlusEx = new SCANNER_PLUS_EX();

      ScanSetPlusEx.Version = 1;
      if (AutomaticEject)
        ScanSetPlusEx.EjectType = MB2Library.SC_AUTOMATIC;
      else
        ScanSetPlusEx.EjectType = MB2Library.SC_BY_COMMAND;

      ScanSetPlusEx.AcquisitionType = (byte)AcqType;
      ScanSetPlusEx.ResolutionType = (byte)DPI;

      if ((ImageBPP) == MB2Library.BITS_PER_PIXEL_24)
      { // COLOR         
        if(ExtImgType == 0)
          ScanSetPlusEx.CisType = MB2Library.SC_EX_COLOR_RGB;
        else
          if(ExtImgType == 1)
            ScanSetPlusEx.CisType = MB2Library.SC_EX_COLOR_RGB_INFRARED;
          else
            ScanSetPlusEx.CisType = MB2Library.SC_EX_COLOR_RGB_UV;
      }
      else     
        { // gray
          if (ExtImgType == 0)
            ScanSetPlusEx.CisType = MB2Library.SC_EX_GREY_RGB;
          else
            if (ExtImgType == 1)
              ScanSetPlusEx.CisType = MB2Library.SC_EX_GREY_RGB_INFRARED;
            else
              ScanSetPlusEx.CisType = MB2Library.SC_EX_GREY_RGB_UV;
        }
      
      w_rc = MB2Library.INSTANCE.ScanSet_PlusEx(ByteBuffer.wrap(Native.toByteArray(gPort.Global)), ScanSetPlusEx);
      if (w_rc != (short)MB2Library.PR_OK)
        return w_rc;

      m_ScanPlusEx.BrightnessFront = m_ScanPlusEx.BrightnessRear = 100;
      m_ScanPlusEx.ThresholdFront = m_ScanPlusEx.ThresholdRear = 128;
      m_ScanPlusEx.ScanMode = (int)ScanMode;
      m_ScanPlusEx.BitsPerPixel = (int)ImageBPP;
      
      gPort.ScanToMem = false;

      if (OutputFomat == MB2Library.SCAN_OUTPUT_FORMAT_FILE_BMP)
      {
        BitmapNameF.append(fileName + "F.bmp");
        BitmapNameR.append(fileName + "R.bmp");
        BitmapNameF_IR.append(fileName + "F_IR.bmp");
        BitmapNameR_IR.append(fileName + "R_IR.bmp");
        BitmapNameF_UV.append(fileName + "F_UV.bmp");
        BitmapNameR_UV.append(fileName + "R_UV.bmp");
      }
      else
        if (OutputFomat == MB2Library.SCAN_OUTPUT_FORMAT_FILE_BMP)
        {
          BitmapNameF.append(fileName + "F.jpg");
          BitmapNameR.append(fileName + "R.jpg");
          BitmapNameF_IR.append(fileName + "F_IR.jpg");
          BitmapNameR_IR.append(fileName + "R_IR.jpg");
          BitmapNameF_UV.append(fileName + "F_UV.jpg");
          BitmapNameR_UV.append(fileName + "R_UV.jpg");
        }
        else
          if (OutputFomat == MB2Library.SCAN_OUTPUT_FORMAT_FILE_PDF)
          {
            BitmapNameF.append(fileName + "F.pdf");
            BitmapNameR.append(fileName + "R.pdf");
            BitmapNameF_IR.append(fileName + "F_IR.pdf");
            BitmapNameR_IR.append(fileName + "R_IR.pdf");
            BitmapNameF_UV.append(fileName + "F_UV.pdf");
            BitmapNameR_UV.append(fileName + "R_UV.pdf");
          }

      m_ScanPlusEx.ImageNameFront = Native.toByteArray(BitmapNameF.toString());
      m_ScanPlusEx.ImageNameRear = Native.toByteArray(BitmapNameR.toString());
      m_ScanPlusEx.IR_ImageNameFront = Native.toByteArray(BitmapNameF_IR.toString());
      m_ScanPlusEx.IR_ImageNameRear = Native.toByteArray(BitmapNameR_IR.toString());
      m_ScanPlusEx.UV_ImageNameFront = Native.toByteArray(BitmapNameF_UV.toString());
      m_ScanPlusEx.UV_ImageNameRear = Native.toByteArray(BitmapNameR_UV.toString());

      // default value
      Resolution = MB2Library.SCAN_RESOLUTION_200;
      MaxH = MB2Library.MAX_PAGE_HEIGH_200;
      MaxW = MB2Library.MAX_PAGE_WIDTH_200;

      switch (DPI)
      {
        case MB2Library.SC_RESOLUTION_200:
          Resolution = MB2Library.SCAN_RESOLUTION_200;
          MaxH = MB2Library.MAX_PAGE_HEIGH_200;
          MaxW = MB2Library.MAX_PAGE_WIDTH_200;
          break;
        case MB2Library.SC_RESOLUTION_300:
          Resolution = MB2Library.SCAN_RESOLUTION_300;
          MaxH = MB2Library.MAX_PAGE_HEIGH_300;
          MaxW = MB2Library.MAX_PAGE_WIDTH_300;
          break;
        case MB2Library.SC_RESOLUTION_600:
          Resolution = MB2Library.SCAN_RESOLUTION_600;
          MaxH = MB2Library.MAX_PAGE_HEIGH_600;
          MaxW = MB2Library.MAX_PAGE_WIDTH_600;
          break;
        default:
          Resolution = MB2Library.SCAN_RESOLUTION_200;
          MaxH = MB2Library.MAX_PAGE_HEIGH_200;
          MaxW = MB2Library.MAX_PAGE_WIDTH_200;
          break;
      }

      m_ScanPlusEx.dwStartX = (int)(((StartX * 10) / 25.4) * Resolution);
      m_ScanPlusEx.dwStartY = (int)(((StartY * 10) / 25.4) * Resolution);
      m_ScanPlusEx.dwEndX = (int)(((EndX * 10) / 25.4) * Resolution);
      m_ScanPlusEx.dwEndY = (int)(((EndY * 10) / 25.4) * Resolution);

      if (m_ScanPlusEx.dwEndY > MaxH)
        m_ScanPlusEx.dwEndY = MaxH;
      if (m_ScanPlusEx.dwEndX > MaxW)
        m_ScanPlusEx.dwEndX = MaxW;

      w_rc = MB2Library.INSTANCE.ScanRead_PlusEx(ByteBuffer.wrap(Native.toByteArray(gPort.Global)), m_ScanPlusEx, OutputFomat);

      //m_ScanPlusEx.dwImageSizeFront or m_ScanPlusEx.dwImageSizeRear, etc

      return w_rc;

    }
    
    public short Scan(String fileName) {
    	
    	if (fileName.isEmpty()) return 9999;

        short w_rc;
        short OutputFomat = MB2Library.SCAN_OUTPUT_FORMAT_FILE_JPEG;

        StringBuilder BitmapNameF = new StringBuilder();
        StringBuilder BitmapNameR = new StringBuilder();
        StringBuilder BitmapNameF_IR = new StringBuilder();
        StringBuilder BitmapNameR_IR = new StringBuilder();
        StringBuilder BitmapNameF_UV = new StringBuilder();
        StringBuilder BitmapNameR_UV = new StringBuilder();

        SCAN_SET_PLUS_EX ScanSetPlusEx = new SCAN_SET_PLUS_EX();
    	SCANNER_FULL_PLUS_EX m_ScanFullPlusEx = new SCANNER_FULL_PLUS_EX();

        ScanSetPlusEx.Version = 0;

        Boolean AutomaticEject = true;
        if (AutomaticEject)
          ScanSetPlusEx.EjectType = MB2Library.SC_AUTOMATIC;
        else
          ScanSetPlusEx.EjectType = MB2Library.SC_BY_COMMAND;

        ScanSetPlusEx.AcquisitionType = MB2Library.SC_REAR_FORWARD_FRONT_FORWARD;
        ScanSetPlusEx.CisType = MB2Library.SC_EX_GREY_RGB_UV;
        ScanSetPlusEx.ResolutionType = MB2Library.SC_RESOLUTION_300;
        
        w_rc = MB2Library.INSTANCE.ScanSet_PlusEx(ByteBuffer.wrap(Native.toByteArray(gPort.Global)), ScanSetPlusEx);
        if (w_rc != (short)MB2Library.PR_OK)
          return w_rc;
    	
        m_ScanFullPlusEx.BitsPerPixel = 8;
        m_ScanFullPlusEx.BrightnessFront = 100;
        m_ScanFullPlusEx.BrightnessRear = 100;
        // m_ScanFullPlusEx.IR_ImageNameFront = Native.toByteArray("~");
        // m_ScanFullPlusEx.IR_ImageNameRear = Native.toByteArray("~");
        // m_ScanFullPlusEx.ImageNameFront = Native.toByteArray("~");
        // m_ScanFullPlusEx.ImageNameRear = Native.toByteArray("~");
        m_ScanFullPlusEx.ScanMode = 2;
        m_ScanFullPlusEx.ScanModeIR = 0;
        m_ScanFullPlusEx.ScanModeUV = 0;
        m_ScanFullPlusEx.ThresholdFront = 100;
        m_ScanFullPlusEx.ThresholdRear = 100;
        // m_ScanFullPlusEx.UV_ImageNameFront = Native.toByteArray("~");
        // m_ScanFullPlusEx.UV_ImageNameRear = Native.toByteArray("~");
        m_ScanFullPlusEx.Version = 0;
        m_ScanFullPlusEx.dwIR_ImageSizeFront = 0;
        m_ScanFullPlusEx.dwIR_ImageSizeRear = 0;
        m_ScanFullPlusEx.dwImageHeight = 0;
        m_ScanFullPlusEx.dwImageSizeFront = 0;
        m_ScanFullPlusEx.dwImageSizeRear = 0;
        m_ScanFullPlusEx.dwImageWidth = 0;
        m_ScanFullPlusEx.dwUV_ImageSizeFront = 0;
        m_ScanFullPlusEx.dwUV_ImageSizeRear = 0;

        m_ScanFullPlusEx.pIR_ImageFront = new NativeLong(0);
        m_ScanFullPlusEx.pIR_ImageRear = new NativeLong(0);
        m_ScanFullPlusEx.pImageFront = new NativeLong(0);
        m_ScanFullPlusEx.pImageRear = new NativeLong(0);
        m_ScanFullPlusEx.pUV_ImageFront = new NativeLong(0);
        m_ScanFullPlusEx.pUV_ImageRear = new NativeLong(0);

        if (OutputFomat == MB2Library.SCAN_OUTPUT_FORMAT_FILE_BMP)
        {
          BitmapNameF.append(fileName + "F.bmp");
          BitmapNameR.append(fileName + "R.bmp");
          BitmapNameF_IR.append(fileName + "F_IR.bmp");
          BitmapNameR_IR.append(fileName + "R_IR.bmp");
          BitmapNameF_UV.append(fileName + "F_UV.bmp");
          BitmapNameR_UV.append(fileName + "R_UV.bmp");
        }
        else
          if (OutputFomat == MB2Library.SCAN_OUTPUT_FORMAT_FILE_JPEG)
          {
            BitmapNameF.append(fileName + "F.jpg");
            BitmapNameR.append(fileName + "R.jpg");
            BitmapNameF_IR.append(fileName + "F_IR.jpg");
            BitmapNameR_IR.append(fileName + "R_IR.jpg");
            BitmapNameF_UV.append(fileName + "F_UV.jpg");
            BitmapNameR_UV.append(fileName + "R_UV.jpg");
          }
          else
            if (OutputFomat == MB2Library.SCAN_OUTPUT_FORMAT_FILE_PDF)
            {
              BitmapNameF.append(fileName + "F.pdf");
              BitmapNameR.append(fileName + "R.pdf");
              BitmapNameF_IR.append(fileName + "F_IR.pdf");
              BitmapNameR_IR.append(fileName + "R_IR.pdf");
              BitmapNameF_UV.append(fileName + "F_UV.pdf");
              BitmapNameR_UV.append(fileName + "R_UV.pdf");
            }

        m_ScanFullPlusEx.ImageNameRear = Native.toByteArray(BitmapNameR.toString());
        m_ScanFullPlusEx.ImageNameFront = Native.toByteArray(BitmapNameF.toString());
        m_ScanFullPlusEx.IR_ImageNameFront = Native.toByteArray(BitmapNameF_IR.toString());
        m_ScanFullPlusEx.IR_ImageNameRear = Native.toByteArray(BitmapNameR_IR.toString());
        m_ScanFullPlusEx.UV_ImageNameFront = Native.toByteArray(BitmapNameF_UV.toString());
        m_ScanFullPlusEx.UV_ImageNameRear = Native.toByteArray(BitmapNameR_UV.toString());
        
        System.out.println(BitmapNameF.toString());
        System.out.println(BitmapNameR.toString());
        System.out.println(m_ScanFullPlusEx.ImageNameFront);
        System.out.println(m_ScanFullPlusEx.ImageNameRear);
        
        
        w_rc = MB2Library.INSTANCE.ScanReadFull_PlusEx(ByteBuffer.wrap(Native.toByteArray(gPort.Global)), m_ScanFullPlusEx, OutputFomat);
        if (w_rc != (short)MB2Library.PR_OK)
          return w_rc;
    	
    	return w_rc;
    }
}
