package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class SCANNERFR_FULL extends Structure {
	public int grayscaleF;
	public int LuminF;
	public int SogliaF;
	public int grayscaleR;
	public int LuminR;
	public int SogliaR;
	public int ScanMode;
	public int Width;
	public int Height;
	public int Reserved;
	/** C type : HANDLE */
	public NativeLong pImageF;
	public NativeLong llImageF;
	/** C type : HANDLE */
	public NativeLong pImageR;
	public NativeLong llImageR;
	/** C type : char[512] */
	public byte[] BitmapNameF = new byte[512];
	/** C type : char[512] */
	public byte[] BitmapNameR = new byte[512];
	public SCANNERFR_FULL() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("grayscaleF", "LuminF", "SogliaF", "grayscaleR", "LuminR", "SogliaR", "ScanMode", "Width", "Height", "Reserved", "pImageF", "llImageF", "pImageR", "llImageR", "BitmapNameF", "BitmapNameR");
	}
	public SCANNERFR_FULL(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends SCANNERFR_FULL implements Structure.ByReference {
		
	};
	public static class ByValue extends SCANNERFR_FULL implements Structure.ByValue {
		
	};
}

