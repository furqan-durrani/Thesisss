package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class SCANNER_PLUS extends Structure {
	public int BitsPerPixelF;
	public int LuminF;
	public int SogliaF;
	public int BitsPerPixelR;
	public int LuminR;
	public int SogliaR;
	public int ScanMode;
	public int startx;
	public int starty;
	public int endx;
	public int endy;
	/** C type : HANDLE */
	public NativeLong pImageF;
	public NativeLong llImageF;
	/** C type : HANDLE */
	public NativeLong pImageR;
	public NativeLong llImageR;
	/** C type : char[512] */
	public byte[] BitmapNameF = new byte[512];
	/** C type : char[512] */
	public byte[] BitmapNameR = new byte[512];
	public NativeLong NumLinesRead;
	public NativeLong ReplayCode;
	public SCANNER_PLUS() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("BitsPerPixelF", "LuminF", "SogliaF", "BitsPerPixelR", "LuminR", "SogliaR", "ScanMode", "startx", "starty", "endx", "endy", "pImageF", "llImageF", "pImageR", "llImageR", "BitmapNameF", "BitmapNameR", "NumLinesRead", "ReplayCode");
	}
	public SCANNER_PLUS(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends SCANNER_PLUS implements Structure.ByReference {
		
	};
	public static class ByValue extends SCANNER_PLUS implements Structure.ByValue {
		
	};
}

