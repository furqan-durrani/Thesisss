package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class PR2_USB_INFO extends Structure {
	/** C type : char[6] */
	public byte[] szUsbPortName = new byte[6];
	public PR2_USB_INFO() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("szUsbPortName");
	}
	/** @param szUsbPortName C type : char[6] */
	public PR2_USB_INFO(byte szUsbPortName[]) {
		super();
		if ((szUsbPortName.length != this.szUsbPortName.length)) 
			throw new IllegalArgumentException("Wrong array size !");
		this.szUsbPortName = szUsbPortName;
	}
	public PR2_USB_INFO(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends PR2_USB_INFO implements Structure.ByReference {
		
	};
	public static class ByValue extends PR2_USB_INFO implements Structure.ByValue {
		
	};
}

