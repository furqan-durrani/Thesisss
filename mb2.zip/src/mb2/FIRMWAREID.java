package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class FIRMWAREID extends Structure {
	/** C type : char[8] */
	public byte[] FwRelease = new byte[8];
	/** C type : char[8] */
	public byte[] FwVersion = new byte[8];
	/** C type : char[8] */
	public byte[] CharGenVer = new byte[8];
	public FIRMWAREID() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("FwRelease", "FwVersion", "CharGenVer");
	}
	/**
	 * @param FwRelease C type : char[8]<br>
	 * @param FwVersion C type : char[8]<br>
	 * @param CharGenVer C type : char[8]
	 */
	public FIRMWAREID(byte FwRelease[], byte FwVersion[], byte CharGenVer[]) {
		super();
		if ((FwRelease.length != this.FwRelease.length)) 
			throw new IllegalArgumentException("Wrong array size !");
		this.FwRelease = FwRelease;
		if ((FwVersion.length != this.FwVersion.length)) 
			throw new IllegalArgumentException("Wrong array size !");
		this.FwVersion = FwVersion;
		if ((CharGenVer.length != this.CharGenVer.length)) 
			throw new IllegalArgumentException("Wrong array size !");
		this.CharGenVer = CharGenVer;
	}
	public FIRMWAREID(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends FIRMWAREID implements Structure.ByReference {
		
	};
	public static class ByValue extends FIRMWAREID implements Structure.ByValue {
		
	};
}

