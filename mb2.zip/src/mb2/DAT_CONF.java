package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class DAT_CONF extends Structure {
	public int prtype;
	/** OLIMODE or IBMMODE */
	public int devmode;
	/** internal devices attached */
	public NativeLong int_opts = new NativeLong(0);
	/** external devices attached */
	public NativeLong ext_opts = new NativeLong(0);
	public NativeLong cheque_devs = new NativeLong(0);
	public int primarydev;
	public int strip_type;
	public int align_type;
	public DAT_CONF() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("prtype", "devmode", "int_opts", "ext_opts", "cheque_devs", "primarydev", "strip_type", "align_type");
	}
	/**
	 * @param devmode OLIMODE or IBMMODE<br>
	 * @param int_opts internal devices attached<br>
	 * @param ext_opts external devices attached
	 */
	public DAT_CONF(int prtype, int devmode, NativeLong int_opts, NativeLong ext_opts, NativeLong cheque_devs, int primarydev, int strip_type, int align_type) {
		super();
		this.prtype = prtype;
		this.devmode = devmode;
		this.int_opts = int_opts;
		this.ext_opts = ext_opts;
		this.cheque_devs = cheque_devs;
		this.primarydev = primarydev;
		this.strip_type = strip_type;
		this.align_type = align_type;
	}
	public DAT_CONF(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends DAT_CONF implements Structure.ByReference {
		
	};
	public static class ByValue extends DAT_CONF implements Structure.ByValue {
		
	};
}
