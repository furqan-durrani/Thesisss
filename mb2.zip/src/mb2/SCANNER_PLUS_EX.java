package mb2;

import java.util.StringTokenizer;

import java.util.Arrays;
import java.util.List;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.ptr.ShortByReference;

public class SCANNER_PLUS_EX extends Structure {
	public int Version;
	public int BrightnessFront;
	public int ThresholdFront;
	public int BrightnessRear;
	public int ThresholdRear;
	public int BitsPerPixel;
	/** Front/Rear/Front-Rear */
	public int ScanMode;
	/** ( not yet implemented ) IR Front/Rear/Front-Rear */
	public int ScanModeIR;
	/** ( not yet implemented ) UV Front/Rear/Front-Rear */
	public int ScanModeUV;
	/** The X coordinate of the upper-left corner of the scanning window */
	public int dwStartX;
	/** The Y coordinate of the upper-left corner of the scanning window */
	public int dwStartY;
	/** The X coordinate of the bottom-right corner of the scanning window */
	public int dwEndX;
	/** The Y coordinate of the bottom-right corner of the scanning window */
	public int dwEndY;
	/**
	 * Front CIS Image<br>
	 * C type : HANDLE
	 */
	public NativeLong pImageFront;
	public int dwImageSizeFront;
	/**
	 * Rear CIS Image<br>
	 * C type : HANDLE
	 */
	public NativeLong pImageRear;
	public int dwImageSizeRear;
	/**
	 * Front IR Image<br>
	 * C type : HANDLE
	 */
	public NativeLong pIR_ImageFront;
	public int dwIR_ImageSizeFront;
	/**
	 * Rear IR Image<br>
	 * C type : HANDLE
	 */
	public NativeLong pIR_ImageRear;
	public int dwIR_ImageSizeRear;
	/**
	 * Front UV Image<br>
	 * C type : HANDLE
	 */
	public NativeLong pUV_ImageFront;
	public int dwUV_ImageSizeFront;
	/**
	 * Rear UV Image<br>
	 * C type : HANDLE
	 */
	public NativeLong pUV_ImageRear;
	public int dwUV_ImageSizeRear;
	/**
	 * images path<br>
	 * C type : TCHAR[512]
	 */
	public byte[] ImageNameFront = new byte[512];
	/** C type : TCHAR[512] */
	public byte[] ImageNameRear = new byte[512];
	/** C type : TCHAR[512] */
	public byte[] IR_ImageNameFront = new byte[512];
	/** C type : TCHAR[512] */
	public byte[] IR_ImageNameRear = new byte[512];
	/** C type : TCHAR[512] */
	public byte[] UV_ImageNameFront = new byte[512];
	/** C type : TCHAR[512] */
	public byte[] UV_ImageNameRear = new byte[512];
	public SCANNER_PLUS_EX() {
		super();
	}
	protected List<String> getFieldOrder() {
		return Arrays.asList("Version", "BrightnessFront", "ThresholdFront", "BrightnessRear", "ThresholdRear", "BitsPerPixel", "ScanMode", "ScanModeIR", "ScanModeUV", "dwStartX", "dwStartY", "dwEndX", "dwEndY", "pImageFront", "dwImageSizeFront", "pImageRear", "dwImageSizeRear", "pIR_ImageFront", "dwIR_ImageSizeFront", "pIR_ImageRear", "dwIR_ImageSizeRear", "pUV_ImageFront", "dwUV_ImageSizeFront", "pUV_ImageRear", "dwUV_ImageSizeRear", "ImageNameFront", "ImageNameRear", "IR_ImageNameFront", "IR_ImageNameRear", "UV_ImageNameFront", "UV_ImageNameRear");
	}
	public SCANNER_PLUS_EX(Pointer peer) {
		super(peer);
	}
	public static class ByReference extends SCANNER_PLUS_EX implements Structure.ByReference {
		
	};
	public static class ByValue extends SCANNER_PLUS_EX implements Structure.ByValue {
		
	};
}

