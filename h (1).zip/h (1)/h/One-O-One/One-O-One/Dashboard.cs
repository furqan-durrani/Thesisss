﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace One_O_One
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
            //this.WindowState = FormWindowState.Maximized;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Dashboard_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            AddStock ad = new AddStock();
            ad.Show(); this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MeasurementsOrder mo = new MeasurementsOrder();
            mo.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            TrackSale TS = new TrackSale();
            TS.Show(); this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Sale s = new Sale();
            s.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            PromotionMessage pm = new PromotionMessage();
            pm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PendingOrders po = new PendingOrders();
            po.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            SearchCustomer uc = new SearchCustomer();
            uc.Show();
            this.Hide();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            UpdateCustomer uc = new UpdateCustomer();
            uc.Show(); this.Hide();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            OrderForStich OFS = new OrderForStich();
            OFS.Show();
            this.Hide();
        }
    }
}
