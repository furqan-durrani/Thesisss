﻿namespace One_O_One
{
    partial class MeasurementsOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MeasurementsOrder));
            this.label17 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label18 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label41 = new System.Windows.Forms.Label();
            this.txtOtherDetails = new System.Windows.Forms.RichTextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label40 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtMobile = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.cmbKaffStyle = new System.Windows.Forms.ComboBox();
            this.cmbKaffSize = new System.Windows.Forms.ComboBox();
            this.cmbKanta = new System.Windows.Forms.ComboBox();
            this.cmbKaff = new System.Windows.Forms.ComboBox();
            this.cmbShalwarPocket = new System.Windows.Forms.ComboBox();
            this.cmbSidePocket = new System.Windows.Forms.ComboBox();
            this.cmbFrontPocket = new System.Windows.Forms.ComboBox();
            this.cmbGhaira = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtOrderId = new System.Windows.Forms.TextBox();
            this.txtLength = new System.Windows.Forms.TextBox();
            this.txtArms = new System.Windows.Forms.TextBox();
            this.txtShoulder = new System.Windows.Forms.TextBox();
            this.txtNeck = new System.Windows.Forms.TextBox();
            this.txtGhaira = new System.Windows.Forms.TextBox();
            this.txtKamar = new System.Windows.Forms.TextBox();
            this.txtUnderShoulder = new System.Windows.Forms.TextBox();
            this.txtBill = new System.Windows.Forms.TextBox();
            this.txtShalwaarLength = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.txtCoatShoulder = new System.Windows.Forms.TextBox();
            this.txtChest = new System.Windows.Forms.TextBox();
            this.txtBack = new System.Windows.Forms.TextBox();
            this.txtBalley = new System.Windows.Forms.TextBox();
            this.txtHip = new System.Windows.Forms.TextBox();
            this.txtPentLength = new System.Windows.Forms.TextBox();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.txtPooocha = new System.Windows.Forms.TextBox();
            this.txtCoatLength = new System.Windows.Forms.TextBox();
            this.txtCoatArms = new System.Windows.Forms.TextBox();
            this.cmbColarBan = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label17.Location = new System.Drawing.Point(3, 5);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(50, 16);
            this.label17.TabIndex = 28;
            this.label17.Text = "OrderId";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(88, 476);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Furqan Durrani";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 6.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(88, 459);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "Developed By:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(24, 268);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Store for Men";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(32, 229);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "One O One";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(-3, 194);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(194, 25);
            this.label2.TabIndex = 0;
            this.label2.Text = "Welcome To The";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(188, 622);
            this.panel1.TabIndex = 9;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(29, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(120, 120);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label18.Location = new System.Drawing.Point(3, 248);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(92, 16);
            this.label18.TabIndex = 8;
            this.label18.Text = "Shalwar Length";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel2.Controls.Add(this.tableLayoutPanel3);
            this.panel2.Controls.Add(this.tableLayoutPanel2);
            this.panel2.Controls.Add(this.tableLayoutPanel1);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.button15);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(868, 622);
            this.panel2.TabIndex = 10;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.38902F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 76.61098F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 93F));
            this.tableLayoutPanel3.Controls.Add(this.label41, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.txtOtherDetails, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.btnSave, 2, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(279, 530);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(507, 87);
            this.tableLayoutPanel3.TabIndex = 22;
            // 
            // label41
            // 
            this.label41.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label41.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label41.Location = new System.Drawing.Point(3, 35);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(77, 16);
            this.label41.TabIndex = 72;
            this.label41.Text = "Other Details";
            // 
            // txtOtherDetails
            // 
            this.txtOtherDetails.Location = new System.Drawing.Point(99, 3);
            this.txtOtherDetails.Name = "txtOtherDetails";
            this.txtOtherDetails.Size = new System.Drawing.Size(311, 81);
            this.txtOtherDetails.TabIndex = 73;
            this.txtOtherDetails.Text = "";
            // 
            // btnSave
            // 
            this.btnSave.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.btnSave.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSave.Location = new System.Drawing.Point(416, 9);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(88, 69);
            this.btnSave.TabIndex = 74;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.39159F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 68.60841F));
            this.tableLayoutPanel2.Controls.Add(this.label40, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label32, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtName, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtMobile, 1, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(380, 49);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(257, 53);
            this.tableLayoutPanel2.TabIndex = 21;
            // 
            // label40
            // 
            this.label40.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label40.Location = new System.Drawing.Point(3, 31);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(66, 16);
            this.label40.TabIndex = 30;
            this.label40.Text = "Mobile No.";
            // 
            // label32
            // 
            this.label32.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label32.Location = new System.Drawing.Point(3, 5);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(41, 16);
            this.label32.TabIndex = 29;
            this.label32.Text = "Name";
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(83, 3);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(171, 21);
            this.txtName.TabIndex = 32;
            // 
            // txtMobile
            // 
            this.txtMobile.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMobile.Location = new System.Drawing.Point(83, 29);
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.Size = new System.Drawing.Size(171, 21);
            this.txtMobile.TabIndex = 33;
            this.txtMobile.TextChanged += new System.EventHandler(this.txtMobile_TextChanged);
            this.txtMobile.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMobile_KeyPress);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.cmbKaffStyle, 1, 14);
            this.tableLayoutPanel1.Controls.Add(this.cmbKaffSize, 3, 13);
            this.tableLayoutPanel1.Controls.Add(this.cmbKanta, 1, 13);
            this.tableLayoutPanel1.Controls.Add(this.cmbKaff, 3, 12);
            this.tableLayoutPanel1.Controls.Add(this.cmbShalwarPocket, 3, 11);
            this.tableLayoutPanel1.Controls.Add(this.cmbSidePocket, 3, 10);
            this.tableLayoutPanel1.Controls.Add(this.cmbFrontPocket, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.cmbGhaira, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.label17, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label18, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.label15, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.label14, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.label11, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label12, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label19, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label16, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label13, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtOrderId, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtLength, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtArms, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtShoulder, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtNeck, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtGhaira, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtKamar, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.txtUnderShoulder, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.txtBill, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.txtShalwaarLength, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.label21, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.label22, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.label20, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label23, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label24, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.label25, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.label26, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.label27, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.label28, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.label29, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.label30, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.label31, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.label33, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.label34, 2, 11);
            this.tableLayoutPanel1.Controls.Add(this.txtCoatShoulder, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtChest, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtBack, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtBalley, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtHip, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtPentLength, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.txtDescription, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.label35, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.label36, 2, 12);
            this.tableLayoutPanel1.Controls.Add(this.label39, 0, 14);
            this.tableLayoutPanel1.Controls.Add(this.label37, 2, 13);
            this.tableLayoutPanel1.Controls.Add(this.label38, 0, 13);
            this.tableLayoutPanel1.Controls.Add(this.txtPooocha, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.txtCoatLength, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.txtCoatArms, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.cmbColarBan, 3, 7);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Noto Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(279, 119);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 15;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(507, 405);
            this.tableLayoutPanel1.TabIndex = 20;
            // 
            // cmbKaffStyle
            // 
            this.cmbKaffStyle.FormattingEnabled = true;
            this.cmbKaffStyle.Location = new System.Drawing.Point(101, 381);
            this.cmbKaffStyle.Name = "cmbKaffStyle";
            this.cmbKaffStyle.Size = new System.Drawing.Size(138, 23);
            this.cmbKaffStyle.TabIndex = 83;
            // 
            // cmbKaffSize
            // 
            this.cmbKaffSize.FormattingEnabled = true;
            this.cmbKaffSize.Location = new System.Drawing.Point(364, 354);
            this.cmbKaffSize.Name = "cmbKaffSize";
            this.cmbKaffSize.Size = new System.Drawing.Size(138, 23);
            this.cmbKaffSize.TabIndex = 82;
            // 
            // cmbKanta
            // 
            this.cmbKanta.FormattingEnabled = true;
            this.cmbKanta.Location = new System.Drawing.Point(101, 354);
            this.cmbKanta.Name = "cmbKanta";
            this.cmbKanta.Size = new System.Drawing.Size(138, 23);
            this.cmbKanta.TabIndex = 81;
            // 
            // cmbKaff
            // 
            this.cmbKaff.FormattingEnabled = true;
            this.cmbKaff.Location = new System.Drawing.Point(364, 327);
            this.cmbKaff.Name = "cmbKaff";
            this.cmbKaff.Size = new System.Drawing.Size(138, 23);
            this.cmbKaff.TabIndex = 80;
            // 
            // cmbShalwarPocket
            // 
            this.cmbShalwarPocket.FormattingEnabled = true;
            this.cmbShalwarPocket.Location = new System.Drawing.Point(364, 300);
            this.cmbShalwarPocket.Name = "cmbShalwarPocket";
            this.cmbShalwarPocket.Size = new System.Drawing.Size(138, 23);
            this.cmbShalwarPocket.TabIndex = 79;
            // 
            // cmbSidePocket
            // 
            this.cmbSidePocket.FormattingEnabled = true;
            this.cmbSidePocket.Location = new System.Drawing.Point(364, 273);
            this.cmbSidePocket.Name = "cmbSidePocket";
            this.cmbSidePocket.Size = new System.Drawing.Size(138, 23);
            this.cmbSidePocket.TabIndex = 78;
            // 
            // cmbFrontPocket
            // 
            this.cmbFrontPocket.FormattingEnabled = true;
            this.cmbFrontPocket.Location = new System.Drawing.Point(364, 246);
            this.cmbFrontPocket.Name = "cmbFrontPocket";
            this.cmbFrontPocket.Size = new System.Drawing.Size(138, 23);
            this.cmbFrontPocket.TabIndex = 77;
            // 
            // cmbGhaira
            // 
            this.cmbGhaira.FormattingEnabled = true;
            this.cmbGhaira.Location = new System.Drawing.Point(364, 219);
            this.cmbGhaira.Name = "cmbGhaira";
            this.cmbGhaira.Size = new System.Drawing.Size(138, 23);
            this.cmbGhaira.TabIndex = 76;
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label15.Location = new System.Drawing.Point(3, 221);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 16);
            this.label15.TabIndex = 5;
            this.label15.Text = "Total Bill";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label14.Location = new System.Drawing.Point(3, 194);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(91, 16);
            this.label14.TabIndex = 17;
            this.label14.Text = "Under Shoulder";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label11.Location = new System.Drawing.Point(3, 167);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(69, 16);
            this.label11.TabIndex = 16;
            this.label11.Text = "Ghaira Size";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label12.Location = new System.Drawing.Point(3, 140);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(44, 16);
            this.label12.TabIndex = 21;
            this.label12.Text = "Kamar";
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label19.Location = new System.Drawing.Point(3, 113);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 16);
            this.label19.TabIndex = 9;
            this.label19.Text = "Neck";
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label16.Location = new System.Drawing.Point(3, 86);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(55, 16);
            this.label16.TabIndex = 6;
            this.label16.Text = "Shoulder";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label13.Location = new System.Drawing.Point(3, 59);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(32, 16);
            this.label13.TabIndex = 3;
            this.label13.Text = "Arms";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label7.Location = new System.Drawing.Point(3, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "Length";
            // 
            // txtOrderId
            // 
            this.txtOrderId.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOrderId.Location = new System.Drawing.Point(101, 3);
            this.txtOrderId.Name = "txtOrderId";
            this.txtOrderId.ReadOnly = true;
            this.txtOrderId.Size = new System.Drawing.Size(138, 21);
            this.txtOrderId.TabIndex = 31;
            // 
            // txtLength
            // 
            this.txtLength.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLength.Location = new System.Drawing.Point(101, 30);
            this.txtLength.Name = "txtLength";
            this.txtLength.Size = new System.Drawing.Size(138, 21);
            this.txtLength.TabIndex = 35;
            this.txtLength.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLength_KeyPress);
            // 
            // txtArms
            // 
            this.txtArms.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtArms.Location = new System.Drawing.Point(101, 57);
            this.txtArms.Name = "txtArms";
            this.txtArms.Size = new System.Drawing.Size(138, 21);
            this.txtArms.TabIndex = 34;
            this.txtArms.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtArms_KeyPress);
            // 
            // txtShoulder
            // 
            this.txtShoulder.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShoulder.Location = new System.Drawing.Point(101, 84);
            this.txtShoulder.Name = "txtShoulder";
            this.txtShoulder.Size = new System.Drawing.Size(138, 21);
            this.txtShoulder.TabIndex = 33;
            this.txtShoulder.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtShoulder_KeyPress);
            // 
            // txtNeck
            // 
            this.txtNeck.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNeck.Location = new System.Drawing.Point(101, 111);
            this.txtNeck.Name = "txtNeck";
            this.txtNeck.Size = new System.Drawing.Size(138, 21);
            this.txtNeck.TabIndex = 30;
            this.txtNeck.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNeck_KeyPress);
            // 
            // txtGhaira
            // 
            this.txtGhaira.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGhaira.Location = new System.Drawing.Point(101, 165);
            this.txtGhaira.Name = "txtGhaira";
            this.txtGhaira.Size = new System.Drawing.Size(138, 21);
            this.txtGhaira.TabIndex = 32;
            this.txtGhaira.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGhaira_KeyPress);
            // 
            // txtKamar
            // 
            this.txtKamar.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKamar.Location = new System.Drawing.Point(101, 138);
            this.txtKamar.Name = "txtKamar";
            this.txtKamar.Size = new System.Drawing.Size(138, 21);
            this.txtKamar.TabIndex = 37;
            this.txtKamar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtKamar_KeyPress);
            // 
            // txtUnderShoulder
            // 
            this.txtUnderShoulder.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUnderShoulder.Location = new System.Drawing.Point(101, 192);
            this.txtUnderShoulder.Name = "txtUnderShoulder";
            this.txtUnderShoulder.Size = new System.Drawing.Size(138, 21);
            this.txtUnderShoulder.TabIndex = 36;
            this.txtUnderShoulder.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUnderShoullder_KeyPress);
            // 
            // txtBill
            // 
            this.txtBill.Enabled = false;
            this.txtBill.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBill.Location = new System.Drawing.Point(101, 219);
            this.txtBill.Name = "txtBill";
            this.txtBill.ReadOnly = true;
            this.txtBill.Size = new System.Drawing.Size(138, 21);
            this.txtBill.TabIndex = 38;
            // 
            // txtShalwaarLength
            // 
            this.txtShalwaarLength.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShalwaarLength.Location = new System.Drawing.Point(101, 246);
            this.txtShalwaarLength.Name = "txtShalwaarLength";
            this.txtShalwaarLength.Size = new System.Drawing.Size(138, 21);
            this.txtShalwaarLength.TabIndex = 39;
            this.txtShalwaarLength.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ShalwarLength_KeyPress);
            // 
            // label21
            // 
            this.label21.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label21.Location = new System.Drawing.Point(3, 275);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(51, 16);
            this.label21.TabIndex = 40;
            this.label21.Text = "Poocha";
            // 
            // label22
            // 
            this.label22.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label22.Location = new System.Drawing.Point(3, 302);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(76, 16);
            this.label22.TabIndex = 42;
            this.label22.Text = "Coat Length";
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label20.Location = new System.Drawing.Point(245, 5);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(86, 16);
            this.label20.TabIndex = 41;
            this.label20.Text = "Coat Shoulder";
            // 
            // label23
            // 
            this.label23.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label23.Location = new System.Drawing.Point(245, 32);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(39, 16);
            this.label23.TabIndex = 43;
            this.label23.Text = "Chest";
            // 
            // label24
            // 
            this.label24.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label24.Location = new System.Drawing.Point(245, 59);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(34, 16);
            this.label24.TabIndex = 44;
            this.label24.Text = "Back";
            // 
            // label25
            // 
            this.label25.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label25.Location = new System.Drawing.Point(245, 86);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(39, 16);
            this.label25.TabIndex = 45;
            this.label25.Text = "Balley";
            // 
            // label26
            // 
            this.label26.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label26.Location = new System.Drawing.Point(245, 113);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(26, 16);
            this.label26.TabIndex = 46;
            this.label26.Text = "Hip";
            // 
            // label27
            // 
            this.label27.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label27.Location = new System.Drawing.Point(245, 140);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(73, 16);
            this.label27.TabIndex = 47;
            this.label27.Text = "Pent Length";
            // 
            // label28
            // 
            this.label28.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label28.Location = new System.Drawing.Point(245, 167);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(113, 16);
            this.label28.TabIndex = 48;
            this.label28.Text = "Product Description";
            // 
            // label29
            // 
            this.label29.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label29.Location = new System.Drawing.Point(245, 194);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(65, 16);
            this.label29.TabIndex = 49;
            this.label29.Text = "Collar/Ban";
            // 
            // label30
            // 
            this.label30.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label30.Location = new System.Drawing.Point(245, 221);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(74, 16);
            this.label30.TabIndex = 50;
            this.label30.Text = "Ghaira Style";
            // 
            // label31
            // 
            this.label31.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label31.Location = new System.Drawing.Point(245, 248);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(74, 16);
            this.label31.TabIndex = 51;
            this.label31.Text = "Front Pocket";
            // 
            // label33
            // 
            this.label33.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label33.Location = new System.Drawing.Point(245, 275);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(71, 16);
            this.label33.TabIndex = 53;
            this.label33.Text = "Side Pocket";
            // 
            // label34
            // 
            this.label34.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label34.Location = new System.Drawing.Point(245, 302);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(92, 16);
            this.label34.TabIndex = 54;
            this.label34.Text = "Shalwar Pocket";
            // 
            // txtCoatShoulder
            // 
            this.txtCoatShoulder.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.txtCoatShoulder.Location = new System.Drawing.Point(364, 3);
            this.txtCoatShoulder.Name = "txtCoatShoulder";
            this.txtCoatShoulder.Size = new System.Drawing.Size(138, 21);
            this.txtCoatShoulder.TabIndex = 55;
            this.txtCoatShoulder.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CoatShoulder_KeyPress);
            // 
            // txtChest
            // 
            this.txtChest.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.txtChest.Location = new System.Drawing.Point(364, 30);
            this.txtChest.Name = "txtChest";
            this.txtChest.Size = new System.Drawing.Size(138, 21);
            this.txtChest.TabIndex = 56;
            this.txtChest.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Chest_KeyPress);
            // 
            // txtBack
            // 
            this.txtBack.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.txtBack.Location = new System.Drawing.Point(364, 57);
            this.txtBack.Name = "txtBack";
            this.txtBack.Size = new System.Drawing.Size(138, 21);
            this.txtBack.TabIndex = 57;
            this.txtBack.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Back_KeyPress);
            // 
            // txtBalley
            // 
            this.txtBalley.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.txtBalley.Location = new System.Drawing.Point(364, 84);
            this.txtBalley.Name = "txtBalley";
            this.txtBalley.Size = new System.Drawing.Size(138, 21);
            this.txtBalley.TabIndex = 59;
            this.txtBalley.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Balley_KeyPress);
            // 
            // txtHip
            // 
            this.txtHip.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.txtHip.Location = new System.Drawing.Point(364, 111);
            this.txtHip.Name = "txtHip";
            this.txtHip.Size = new System.Drawing.Size(138, 21);
            this.txtHip.TabIndex = 58;
            this.txtHip.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Hip_KeyPress);
            // 
            // txtPentLength
            // 
            this.txtPentLength.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.txtPentLength.Location = new System.Drawing.Point(364, 138);
            this.txtPentLength.Name = "txtPentLength";
            this.txtPentLength.Size = new System.Drawing.Size(138, 21);
            this.txtPentLength.TabIndex = 60;
            this.txtPentLength.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PentLength_KeyPress);
            // 
            // txtDescription
            // 
            this.txtDescription.Enabled = false;
            this.txtDescription.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.txtDescription.Location = new System.Drawing.Point(364, 165);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.ReadOnly = true;
            this.txtDescription.Size = new System.Drawing.Size(138, 21);
            this.txtDescription.TabIndex = 61;
            // 
            // label35
            // 
            this.label35.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label35.Location = new System.Drawing.Point(3, 329);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(63, 16);
            this.label35.TabIndex = 67;
            this.label35.Text = "Coat Arms";
            // 
            // label36
            // 
            this.label36.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label36.Location = new System.Drawing.Point(245, 329);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(29, 16);
            this.label36.TabIndex = 68;
            this.label36.Text = "Kaff";
            this.label36.Click += new System.EventHandler(this.label36_Click);
            // 
            // label39
            // 
            this.label39.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label39.Location = new System.Drawing.Point(3, 383);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(57, 16);
            this.label39.TabIndex = 71;
            this.label39.Text = "Kaff Style";
            // 
            // label37
            // 
            this.label37.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label37.Location = new System.Drawing.Point(245, 356);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(52, 16);
            this.label37.TabIndex = 69;
            this.label37.Text = "Kaff Size";
            // 
            // label38
            // 
            this.label38.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label38.Location = new System.Drawing.Point(3, 356);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(42, 16);
            this.label38.TabIndex = 70;
            this.label38.Text = "Kanta";
            // 
            // txtPooocha
            // 
            this.txtPooocha.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPooocha.Location = new System.Drawing.Point(101, 273);
            this.txtPooocha.Name = "txtPooocha";
            this.txtPooocha.Size = new System.Drawing.Size(138, 21);
            this.txtPooocha.TabIndex = 74;
            this.txtPooocha.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Poocha_KeyPress);
            // 
            // txtCoatLength
            // 
            this.txtCoatLength.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCoatLength.Location = new System.Drawing.Point(101, 300);
            this.txtCoatLength.Name = "txtCoatLength";
            this.txtCoatLength.Size = new System.Drawing.Size(138, 21);
            this.txtCoatLength.TabIndex = 73;
            this.txtCoatLength.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CoatLength_KeyPress);
            // 
            // txtCoatArms
            // 
            this.txtCoatArms.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCoatArms.Location = new System.Drawing.Point(101, 327);
            this.txtCoatArms.Name = "txtCoatArms";
            this.txtCoatArms.Size = new System.Drawing.Size(138, 21);
            this.txtCoatArms.TabIndex = 72;
            this.txtCoatArms.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CoatArms_KeyPress);
            // 
            // cmbColarBan
            // 
            this.cmbColarBan.FormattingEnabled = true;
            this.cmbColarBan.Location = new System.Drawing.Point(364, 192);
            this.cmbColarBan.Name = "cmbColarBan";
            this.cmbColarBan.Size = new System.Drawing.Size(138, 23);
            this.cmbColarBan.TabIndex = 75;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label10.Location = new System.Drawing.Point(194, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(159, 25);
            this.label10.TabIndex = 19;
            this.label10.Text = "Add Customer";
            // 
            // button15
            // 
            this.button15.FlatAppearance.BorderSize = 0;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold);
            this.button15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.button15.Location = new System.Drawing.Point(726, 3);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(140, 30);
            this.button15.TabIndex = 18;
            this.button15.Text = "DashBoard";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label6.Location = new System.Drawing.Point(6, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 25);
            this.label6.TabIndex = 15;
            this.label6.Text = "Dashboard";
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // MeasurementsOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(868, 622);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "MeasurementsOrder";
            this.Text = "MeasurementsOrder";
            this.Load += new System.EventHandler(this.MeasurementsOrder_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtOrderId;
        private System.Windows.Forms.TextBox txtLength;
        private System.Windows.Forms.TextBox txtArms;
        private System.Windows.Forms.TextBox txtShoulder;
        private System.Windows.Forms.TextBox txtNeck;
        private System.Windows.Forms.TextBox txtGhaira;
        private System.Windows.Forms.TextBox txtKamar;
        private System.Windows.Forms.TextBox txtUnderShoulder;
        private System.Windows.Forms.TextBox txtBill;
        private System.Windows.Forms.TextBox txtShalwaarLength;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtCoatShoulder;
        private System.Windows.Forms.TextBox txtChest;
        private System.Windows.Forms.TextBox txtBack;
        private System.Windows.Forms.TextBox txtBalley;
        private System.Windows.Forms.TextBox txtHip;
        private System.Windows.Forms.TextBox txtPentLength;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtPooocha;
        private System.Windows.Forms.TextBox txtCoatLength;
        private System.Windows.Forms.TextBox txtCoatArms;
        private System.Windows.Forms.ComboBox cmbKaffStyle;
        private System.Windows.Forms.ComboBox cmbKaffSize;
        private System.Windows.Forms.ComboBox cmbKanta;
        private System.Windows.Forms.ComboBox cmbKaff;
        private System.Windows.Forms.ComboBox cmbShalwarPocket;
        private System.Windows.Forms.ComboBox cmbSidePocket;
        private System.Windows.Forms.ComboBox cmbFrontPocket;
        private System.Windows.Forms.ComboBox cmbGhaira;
        private System.Windows.Forms.ComboBox cmbColarBan;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.RichTextBox txtOtherDetails;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtMobile;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
    }
}