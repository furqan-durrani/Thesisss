﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace One_O_One
{
    public partial class OrderForStich : Form
    {
        public OrderForStich()
        {
            InitializeComponent();
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            MeasurementsOrder Order = new MeasurementsOrder(txtMobileNumber.Text, "M");
            Order.Show();
            this.Hide();
        }
    }
}
