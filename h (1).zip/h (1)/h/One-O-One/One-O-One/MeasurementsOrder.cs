﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace One_O_One
{
    public partial class MeasurementsOrder : Form
    {
        Logger log = new Logger();
        public MeasurementsOrder()
        {
            InitializeComponent();
            //PrintSlip();
            cmbColarBanFill();
            cmbFrontPocketFill();
            cmbGhairaFill();
            cmbKaffFill();
            cmbKaffSizeFill();
            cmbKaffStyleFill();
            cmbKantaFill();
            cmbShalwarPocketFill();
            cmbSidePocketFill();
            //GetMeasurementOrderId();
        }
        public MeasurementsOrder(string CustomerId,string updateFlag)
        {
            InitializeComponent();
            cmbColarBanFill();
            cmbFrontPocketFill();
            cmbGhairaFill();
            cmbKaffFill();
            cmbKaffSizeFill();
            cmbKaffStyleFill();
            cmbKantaFill();
            cmbShalwarPocketFill();
            cmbSidePocketFill();
            load_CustomerData(CustomerId);
            if(updateFlag == "U")
            {
                btnSave.Text = "Update";
            }else if(updateFlag == "S")
            {
                btnSave.Enabled = false;
            }
            else if (updateFlag == "M")
            {
                btnSave.Text = "Confirm";
                GetMeasurementOrderId();
            }
        }

        private void load_CustomerData(string CustomerId)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
            String query = "select * from Measurement where MobileNo = '" + CustomerId + "'";// where Id='" + txtId.Text + "'";

            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    txtLength.Text = reader["Length"].ToString();
                    txtArms.Text = reader["Arms"].ToString();
                    txtShoulder.Text = reader["Shoulder"].ToString();
                    txtNeck.Text = reader["Neck"].ToString();
                    txtKamar.Text = reader["Kamar"].ToString();
                    txtGhaira.Text = reader["GhairaStyle"].ToString();
                    txtUnderShoulder.Text = reader["UnderShoulderr"].ToString();
                    txtShalwaarLength.Text = reader["ShalwarLength"].ToString();
                    txtPooocha.Text = reader["Poocha"].ToString();
                    txtCoatLength.Text = reader["CoatLength"].ToString();
                    txtCoatArms.Text = reader["CoatArms"].ToString();
                    //string sss = reader["Kanta"].ToString();
                    //int ssss = cmbKanta.Items.IndexOf(reader["Kanta"].ToString());
                    cmbKanta.SelectedIndex = cmbKanta.Items.IndexOf(reader["Kanta"].ToString());
                    cmbKaffStyle.SelectedIndex = cmbKaffStyle.Items.IndexOf(reader["KaffStyle"].ToString()); ;
                    txtCoatShoulder.Text = reader["CoatShoulder"].ToString();
                    txtChest.Text = reader["Chest"].ToString();
                    txtBack.Text = reader["Back"].ToString();
                    txtBalley.Text = reader["Balley"].ToString();
                    txtHip.Text = reader["Hip"].ToString();
                    txtPentLength.Text = reader["PentLength"].ToString();
                    cmbColarBan.SelectedIndex = cmbColarBan.Items.IndexOf(reader["SelectType"].ToString());
                    cmbGhaira.SelectedIndex = cmbGhaira.Items.IndexOf(reader["Ghaira"].ToString());
                    cmbFrontPocket.SelectedIndex = cmbFrontPocket.Items.IndexOf(reader["FrontPocket"].ToString());
                    cmbSidePocket.SelectedIndex = cmbSidePocket.Items.IndexOf(reader["SidePocket"].ToString());
                    cmbShalwarPocket.SelectedIndex = cmbShalwarPocket.Items.IndexOf(reader["ShalwarPocket"].ToString());
                    cmbKaff.SelectedIndex = cmbKaff.Items.IndexOf(reader["Kaff"].ToString());
                    cmbKaffSize.SelectedIndex = cmbKaffSize.Items.IndexOf(reader["KaffSize"].ToString());
                    txtOtherDetails.Text = reader["OtherDetails"].ToString();
                    txtName.Text = reader["Name"].ToString();
                    txtMobile.Text = reader["MobileNo"].ToString();
                    //Int64 OrdId = Convert.ToInt64(reader["MeasurementId"].ToString()) + 1;
                    //txtOrderId.Text = Convert.ToString(OrdId);
                }

            }
            con.Close();
        }

        private void cmbSidePocketFill()
        {
            cmbSidePocket.Items.Add("Yes");
            cmbSidePocket.Items.Add("No");
        }

        private void cmbShalwarPocketFill()
        {
            cmbShalwarPocket.Items.Add("Yes");
            cmbShalwarPocket.Items.Add("No");
        }

        private void cmbKantaFill()
        {
            cmbKanta.Items.Add("Yes");
            cmbKanta.Items.Add("No");
        }

        private void cmbKaffStyleFill()
        {
            cmbKaffStyle.Items.Add("Single");
            cmbKaffStyle.Items.Add("Double");
        }

        private void cmbKaffSizeFill()
        {
            cmbKaffSize.Items.Add("2.0");
            cmbKaffSize.Items.Add("3.0");
        }

        private void cmbKaffFill()
        {
            cmbKaff.Items.Add("Round");
            cmbKaff.Items.Add("Straight");
        }

        private void cmbGhairaFill()
        {
            cmbGhaira.Items.Add("Goal");
            cmbGhaira.Items.Add("Choras");
        }

        private void cmbFrontPocketFill()
        {
            cmbFrontPocket.Items.Add("Yes");
            cmbFrontPocket.Items.Add("No");
        }

        private void cmbColarBanFill()
        {
            cmbColarBan.Items.Add("Collar");
            cmbColarBan.Items.Add("Ban");
        }

        private void label36_Click(object sender, EventArgs e)
        {

        }

        private void MeasurementsOrder_Load(object sender, EventArgs e)
        {

        }

        private void txtMobile_TextChanged(object sender, EventArgs e)
        {
          

        }
        private void txtLength_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void txtArms_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void txtShoulder_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void txtNeck_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void txtKamar_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void txtGhaira_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void txtUnderShoullder_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void ShalwarLength_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void Poocha_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void CoatLength_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void CoatArms_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void CoatShoulder_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void Chest_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void txtMobile_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void Back_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void Balley_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void Hip_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void PentLength_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private string GetMeasurementOrderId()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
            String query = "select MeasurementId from MeasurementOrderId";// where Id='" + txtId.Text + "'";

            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    Int64 OrdId = Convert.ToInt64(reader["MeasurementId"].ToString()) + 1;
                    txtOrderId.Text = Convert.ToString(OrdId);
                }
                else
                {
                }
            }
            con.Close();

            return "";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(btnSave.Text == "Update")
            {
                if (txtMobile.Text == "" || txtName.Text == "")
                {
                    MessageBox.Show("Please enter Name and Mobile No.");
                }
                else
                {
                    log.info("Going to Delete Customer");
                    if (DeleteCustomer(txtMobile.Text))
                    {
                        log.info("Customer " + txtMobile.Text + " record has been deleted successfully, and now going to add new record");
                        //log.info(txtId.Text + ":" + txtPrice.Text + ":" + txtTotalStock.Text + ":" + txtUnitPrice.Text + ":" + cmbMeasuringUnit.SelectedItem + ":" + cmbProdDescription.SelectedItem + ":" + cmbProductType.SelectedItem);
                        //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
                        string mobilenoo = txtMobile.Text.Trim();
                        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");

                        String query = "INSERT INTO Measurement (OrderId,Length,Arms,Shoulder,Neck,Kamar,GhairaStyle,UnderShoulderr,ShalwarLength,Poocha,CoatLength,CoatArms,Kanta,KaffStyle,CoatShoulder,Chest,Back,Balley,Hip,PentLength,SelectType,Ghaira,FrontPocket,SidePocket,ShalwarPocket,Kaff,KaffSize,OtherDetails,CompleteFlag,Name,MobileNo) " +
                            "VALUES ('" + txtOrderId.Text + "','" + txtLength.Text + "','" + txtArms.Text + "','" + txtShoulder.Text + "','" + txtNeck.Text + "','" + txtKamar.Text + "','" + txtGhaira.Text + "','" + txtUnderShoulder.Text + "','" + txtShalwaarLength.Text + "','" + txtPooocha.Text + "','" + txtCoatLength.Text + "','" + txtCoatArms.Text + "'," +
                            "'" + cmbKanta.SelectedItem + "','" + cmbKaffStyle.SelectedItem + "','" + txtCoatShoulder.Text + "','" + txtChest.Text + "','" + txtBack.Text + "','" + txtBalley.Text + "','" + txtHip.Text + "','" + txtPentLength.Text + "','" + cmbColarBan.SelectedItem + "','" + cmbGhaira.SelectedItem + "','" + cmbFrontPocket.SelectedItem + "','" + cmbSidePocket.SelectedItem + "','" + cmbShalwarPocket.SelectedItem + "','" + cmbKaff.SelectedItem + "','" + cmbKaffSize.SelectedItem + "','" + txtOtherDetails.Text + "','P','" + txtName.Text + "','" + mobilenoo + "')";
                        SqlCommand cmd = new SqlCommand(query, con);
                        log.info(query);
                        con.Open();
                        //con.Open();
                        int i = cmd.ExecuteNonQuery();
                        con.Close();
                        if (i != 0)
                        {
                            MessageBox.Show("Successfuly Saved");
                            log.info("Record save ---  "+ query);
                            //MessageBox1 msg1 = new MessageBox1(txtMobile.Text + "|Mr. " + txtName.Text + ", Your order " + txtOrderId.Text + " is created. Please receive within 15days. Thank you.", Convert.ToInt32(txtOrderId.Text), 0);
                            //updateMeasurementOrderId();
                            //PrintSlip();
                            ClearForm();
                            //GetMeasurementOrderId();
                        }
                    }
                }
            }
            if(btnSave.Text == "Save")
            {
                if (txtMobile.Text == "" || txtName.Text == "")
                {
                    MessageBox.Show("Please enter Name and Mobile No.");
                }
                else
                {
                    log.info("Going to Write Data:");
                    //log.info(txtId.Text + ":" + txtPrice.Text + ":" + txtTotalStock.Text + ":" + txtUnitPrice.Text + ":" + cmbMeasuringUnit.SelectedItem + ":" + cmbProdDescription.SelectedItem + ":" + cmbProductType.SelectedItem);
                    //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
                    string mobilenoo = txtMobile.Text.Trim();
                    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
                    String query = "INSERT INTO Measurement (OrderId,Length,Arms,Shoulder,Neck,Kamar,GhairaStyle,UnderShoulderr,ShalwarLength,Poocha,CoatLength,CoatArms,Kanta,KaffStyle,CoatShoulder,Chest,Back,Balley,Hip,PentLength,SelectType,Ghaira,FrontPocket,SidePocket,ShalwarPocket,Kaff,KaffSize,OtherDetails,CompleteFlag,Name,MobileNo) " +
                        "VALUES ('" + txtOrderId.Text + "','" + txtLength.Text + "','" + txtArms.Text + "','" + txtShoulder.Text + "','" + txtNeck.Text + "','" + txtKamar.Text + "','" + txtGhaira.Text + "','" + txtUnderShoulder.Text + "','" + txtShalwaarLength.Text + "','" + txtPooocha.Text + "','" + txtCoatLength.Text + "','" + txtCoatArms.Text + "'," +
                        "'" + cmbKanta.SelectedItem + "','" + cmbKaffStyle.SelectedItem + "','" + txtCoatShoulder.Text + "','" + txtChest.Text + "','" + txtBack.Text + "','" + txtBalley.Text + "','" + txtHip.Text + "','" + txtPentLength.Text + "','" + cmbColarBan.SelectedItem + "','" + cmbGhaira.SelectedItem + "','" + cmbFrontPocket.SelectedItem + "','" + cmbSidePocket.SelectedItem + "','" + cmbShalwarPocket.SelectedItem + "','" + cmbKaff.SelectedItem + "','" + cmbKaffSize.SelectedItem + "','" + txtOtherDetails.Text + "','P','" + txtName.Text + "','" + mobilenoo + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    log.info(query);
                    con.Open();
                    //con.Open();
                    int i = cmd.ExecuteNonQuery();
                    con.Close();
                    if (i != 0)
                    {
                        MessageBox.Show("Successfuly Saved");
                        //MessageBox1 msg1 = new MessageBox1(txtMobile.Text + "|Mr. " + txtName.Text + ", Your order " + txtOrderId.Text + " is created. Please receive within 15days. Thank you.", Convert.ToInt32(txtOrderId.Text), 0);
                        //updateMeasurementOrderId();
                        //PrintSlip();
                        ClearForm();
                        //GetMeasurementOrderId();
                    }
                }
            }
            if (btnSave.Text == "Confirm")
            {
                Billing b = new Billing(txtOrderId.Text, txtName.Text, txtMobile.Text);
                b.Show();
                this.Hide();
            }
        }
        private bool DeleteCustomer(string id)
        {
            //log.info(txtId.Text + ":" + txtPrice.Text + ":" + txtTotalStock.Text + ":" + txtUnitPrice.Text + ":" + cmbMeasuringUnit.SelectedItem + ":" + cmbProdDescription.SelectedItem + ":" + cmbProductType.SelectedItem);
            //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
            string mobilenoo = txtMobile.Text.Trim();
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");

            String query = "delete from Measurement where MobileNo='" + id + "' ";
            SqlCommand cmd = new SqlCommand(query, con);
            log.info(query);
            con.Open();
            //con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();
            if (i != 0)
            {
                //MessageBox.Show("Successfuly Delete");
                return true;
            }
            return false;
        }

        private void PrintSlip()
        {
            printPreviewDialog1.Document = printDocument1;
            printDocument1.DefaultPageSettings.PaperSize = new System.Drawing.Printing.PaperSize("pprnm", 280, 600);
            printPreviewDialog1.ShowDialog();
        }
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("One-O-One Men's Wear", new Font("Arial Black", 12, FontStyle.Bold), Brushes.Black, new Point(35,10));
            e.Graphics.DrawString("Baldia Road Bahawalnagar", new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(72, 40));
            e.Graphics.DrawString("+923-336-699-101", new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(85, 60));
            e.Graphics.DrawString("Order # " + txtOrderId.Text, new Font("Arial", 8, FontStyle.Bold), Brushes.Black, new Point(109, 75));
            e.Graphics.DrawString("!....Stichting Order....!", new Font("Arial", 9, FontStyle.Bold), Brushes.Black, new Point(75, 90));
            e.Graphics.DrawString("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -", new Font("Arial", 5, FontStyle.Regular), Brushes.Black, new Point(10, 105));
            e.Graphics.DrawString("Customer Info", new Font("Arial Black", 9, FontStyle.Bold), Brushes.Black, new Point(07, 110));
            e.Graphics.DrawString("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -", new Font("Arial", 5, FontStyle.Regular), Brushes.Black, new Point(10, 122));
            e.Graphics.DrawString("Name:       " + txtName.Text, new Font("Arial", 10, FontStyle.Regular), Brushes.Black, new Point(10, 130));
            e.Graphics.DrawString("Mobile #:   " + txtMobile.Text, new Font("Arial", 10, FontStyle.Regular), Brushes.Black, new Point(10, 150));
            e.Graphics.DrawString("Date:       " + DateTime.Now, new Font("Arial", 10, FontStyle.Regular), Brushes.Black, new Point(10, 170));

        }


        private void ClearForm()
        {
            txtBill.Text = "";
            txtDescription.Text = "";
            //txtOrderId.Text = "";
            txtLength.Text = "";
            txtArms.Text = "";
            txtShoulder.Text = "";
            txtNeck.Text = "";
            txtKamar.Text = "";
            txtGhaira.Text = "";
            txtUnderShoulder.Text = "";
            txtShalwaarLength.Text = "";
            txtPooocha.Text = "";
            txtCoatLength.Text = "";
            txtCoatArms.Text = "";
            cmbKanta.SelectedIndex = -1;
            cmbKaffStyle.SelectedIndex = -1;
            txtCoatShoulder.Text = "";
            txtChest.Text = "";
            txtBack.Text = "";
            txtBalley.Text = "";
            txtHip.Text = "";
            txtPentLength.Text = "";
            cmbColarBan.SelectedIndex = -1;
            cmbGhaira.SelectedIndex = -1;
            cmbFrontPocket.SelectedIndex = -1;
            cmbSidePocket.SelectedIndex = -1;
            cmbShalwarPocket.SelectedIndex = -1;
            cmbKaff.SelectedIndex = -1;
            cmbKaffSize.SelectedIndex = -1;
            txtOtherDetails.Text = "";
            txtName.Text = "";
            txtMobile.Text = "";
        }

        private void updateMeasurementOrderId()
        {
            try
            {
                
                    log.info("Updating OrderId:");
                    log.info("Setting OrderId: " + txtOrderId.Text);
                    //log.info(txtOrderId.Text + ":" + txtId.Text + ":" + txtProdType.Text + ":" + txtProdDesc.Text + ":" + txtTotalStock.Text + ":" + txtMeasuringnUnit.Text + ":" + txtUnitPrice.Text + ":" + txtPQuantity.Text + ":" + txtBill.Text + ":" + txtMobile.Text);
                    //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
                    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
                    String query = "update MeasurementOrderId set MeasurementId='" + txtOrderId.Text + "'";
                    SqlCommand cmd = new SqlCommand(query, con);
                    con.Open();
                    //con.Open();
                    int i = cmd.ExecuteNonQuery();

                    con.Close();

                    if (i != 0)
                    {

                        MessageBox.Show("Order Id updated.");
                        //GetMeasurementOrderId();
                        //MessageBox1 msg1 = new MessageBox1(txtMobile.Text + "|Mr. " + txtName.Text + ", Your order " + txtOrderId.Text + " is created. Please receive within 15days. Thank you.", Convert.ToInt32(txtOrderId.Text));

                        //ClearForm();
                    }
                
                
            }
            catch (Exception ex)
            {
                log.info(ex.ToString());
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Dashboard DB = new Dashboard();
            DB.Show();
            this.Hide();
        }
    }
}
