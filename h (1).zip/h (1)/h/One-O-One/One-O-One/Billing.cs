﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace One_O_One
{
    public partial class Billing : Form
    {
        Logger log = new Logger();
       
        public Billing()
        {
            InitializeComponent();
        }
        public Billing(string oId, string Name, string mNo)
        {

            InitializeComponent();
            txtMobile.Text =  mNo;
            txtNamee.Text = Name;
            txtOrderId.Text = oId;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            log.info("Going to Write Bill Data:");
            //log.info(txtId.Text + ":" + txtPrice.Text + ":" + txtTotalStock.Text + ":" + txtUnitPrice.Text + ":" + cmbMeasuringUnit.SelectedItem + ":" + cmbProdDescription.SelectedItem + ":" + cmbProductType.SelectedItem);
            //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
            string mobilenoo = txtMobile.Text.Trim();
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
            String query = "INSERT INTO tblOrders (MobileNo,Name,OrderId,DateTime,TotalBill,Quantity,Advance,DueAmount,Flag)" +
                "VALUES ('" + txtMobile.Text + "','" + txtNamee.Text + "','" + txtOrderId.Text + "','" + DateTime.Now + "','" + txtTotalBill.Text + "','" + txtQuantity.Text + "','" + txtAdvance.Text + "','" + txtDueAmmount.Text + "', 'P')";
            SqlCommand cmd = new SqlCommand(query, con);
            log.info(query);
            con.Open();
            //con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();
            if (i != 0)
            {
                MessageBox.Show("Successfuly Saved");
                string messagee = txtMobile.Text + "|Mr. " + txtNamee.Text + ", Your order " + txtOrderId.Text + " is created. Please receive within 15days. Total Bill: " + txtTotalBill.Text + ", Adv: " + txtAdvance.Text + ", Due: " + txtDueAmmount.Text+ ". Thank you.";
                log.info("Message send to customer: " + messagee);
                MessageBox1 msg1 = new MessageBox1(messagee, Convert.ToInt32(txtOrderId.Text), 0);
                updateMeasurementOrderId();
                PrintSlip();
                ClearForm();
                Dashboard d = new Dashboard();
                d.Show();
                this.Hide();
                //GetMeasurementOrderId();
            }
        }
        private void updateMeasurementOrderId()
        {
            try
            {

                log.info("Updating OrderId:");
                log.info("Setting OrderId: " + txtOrderId.Text);
                //log.info(txtOrderId.Text + ":" + txtId.Text + ":" + txtProdType.Text + ":" + txtProdDesc.Text + ":" + txtTotalStock.Text + ":" + txtMeasuringnUnit.Text + ":" + txtUnitPrice.Text + ":" + txtPQuantity.Text + ":" + txtBill.Text + ":" + txtMobile.Text);
                //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
                String query = "update MeasurementOrderId set MeasurementId='" + txtOrderId.Text + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                //con.Open();
                int i = cmd.ExecuteNonQuery();

                con.Close();

                if (i != 0)
                {

                    MessageBox.Show("Order Id updated.");
                    //GetMeasurementOrderId();
                    //MessageBox1 msg1 = new MessageBox1(txtMobile.Text + "|Mr. " + txtName.Text + ", Your order " + txtOrderId.Text + " is created. Please receive within 15days. Thank you.", Convert.ToInt32(txtOrderId.Text));

                    //ClearForm();
                }


            }
            catch (Exception ex)
            {
                log.info(ex.ToString());
            }
        }

        private void ClearForm()
        {
            txtOrderId.Text = "";
            txtNamee.Text = "";
            txtMobile.Text = "";
            txtQuantity.Text = "";
            txtUnitExpense.Text = "";
            txtTotalBill.Text = "";
            txtAdvance.Text = "";
            txtDueAmmount.Text = "";
            textBox5.Text = "";
        }

        private void PrintSlip()
        {
            printPreviewDialog1.Document = printDocument1;
            printDocument1.DefaultPageSettings.PaperSize = new System.Drawing.Printing.PaperSize("pprnm", 280, 600);
            printPreviewDialog1.ShowDialog();
        }
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("One-O-One Men's Wear", new Font("Arial Black", 12, FontStyle.Bold), Brushes.Black, new Point(35, 10));
            e.Graphics.DrawString("Baldia Road Bahawalnagar", new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(72, 40));
            e.Graphics.DrawString("+923-336-699-101", new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(85, 60));
            e.Graphics.DrawString("Order # " + txtOrderId.Text, new Font("Arial", 8, FontStyle.Bold), Brushes.Black, new Point(109, 75));
            e.Graphics.DrawString("!....Stichting Order....!", new Font("Arial", 9, FontStyle.Bold), Brushes.Black, new Point(75, 90));
            e.Graphics.DrawString("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -", new Font("Arial", 5, FontStyle.Regular), Brushes.Black, new Point(10, 105));
            e.Graphics.DrawString("Customer Info", new Font("Arial Black", 9, FontStyle.Bold), Brushes.Black, new Point(07, 110));
            e.Graphics.DrawString("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -", new Font("Arial", 5, FontStyle.Regular), Brushes.Black, new Point(10, 122));
            e.Graphics.DrawString("Name:       " + txtNamee.Text, new Font("Arial", 10, FontStyle.Regular), Brushes.Black, new Point(10, 130));
            e.Graphics.DrawString("Mobile #:   " + txtMobile.Text, new Font("Arial", 10, FontStyle.Regular), Brushes.Black, new Point(10, 150));
            e.Graphics.DrawString("Date:        " + DateTime.Now, new Font("Arial", 10, FontStyle.Regular), Brushes.Black, new Point(10, 170));

            e.Graphics.DrawString("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -", new Font("Arial", 5, FontStyle.Regular), Brushes.Black, new Point(10, 187));
            e.Graphics.DrawString("Billing Info", new Font("Arial Black", 9, FontStyle.Bold), Brushes.Black, new Point(07, 192));
            e.Graphics.DrawString("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -", new Font("Arial", 5, FontStyle.Regular), Brushes.Black, new Point(10, 204));
            e.Graphics.DrawString("Total Bill:                          RS. " + txtTotalBill.Text, new Font("Arial", 10, FontStyle.Regular), Brushes.Black, new Point(10, 214));
            e.Graphics.DrawString("Advance Payment:          Rs. " + txtAdvance.Text, new Font("Arial", 10, FontStyle.Regular), Brushes.Black, new Point(10, 234));
            e.Graphics.DrawString("Due Payment:                  Rs. " + txtDueAmmount.Text, new Font("Arial", 10, FontStyle.Regular), Brushes.Black, new Point(10, 254));
        }
        private void  txtQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void txtUnitPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void txtTotalprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void PentLength_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            if (txtUnitExpense.Text != "" && txtQuantity.Text != "")
            {
                Double unitPrice = Convert.ToDouble(txtUnitExpense.Text);
                Double stock = Convert.ToDouble(txtQuantity.Text);
                txtTotalBill.Text = Convert.ToString(stock * unitPrice);
            }
            else
                txtTotalBill.Text = "";
        }

        private void txtUnitExpense_TextChanged(object sender, EventArgs e)
        {
            if (txtUnitExpense.Text != "" && txtQuantity.Text != "")
            {
                Double unitPrice = Convert.ToDouble(txtUnitExpense.Text);
                Double stock = Convert.ToDouble(txtQuantity.Text);
                txtTotalBill.Text = Convert.ToString(stock * unitPrice);
            }
            else
                txtTotalBill.Text = "";
        }

        private void txtAdvance_TextChanged(object sender, EventArgs e)
        {
            if (txtTotalBill.Text != "" && txtAdvance.Text != "")
            {
                Double TotalBill = Convert.ToDouble(txtTotalBill.Text);
                Double Advance = Convert.ToDouble(txtAdvance.Text);
                txtDueAmmount.Text = Convert.ToString(TotalBill - Advance);
            }
            else
                txtDueAmmount.Text = "";
        }

        

        //private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        //{

        //}
    }
}
