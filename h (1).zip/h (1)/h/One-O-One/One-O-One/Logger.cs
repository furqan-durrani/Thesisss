﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace One_O_One
{
    class Logger
    {


        public void info(string s)
        {
            string tempDir = Path.GetTempPath();
            Console.WriteLine(tempDir);
            string fileName = "logs.dat"; 
            string fullPath = tempDir + fileName;
            try
            {
                StreamWriter sw = new StreamWriter(fullPath, true);
                sw.WriteLine(DateTime.Now+"|"+s);
                sw.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
            finally
            {
                Console.WriteLine("Executing finally block.");
            }
        }

    }
    
}
