﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace One_O_One
{
    public partial class PromotionMessage : Form
    {
        Logger log = new Logger();
        public PromotionMessage()
        {
            InitializeComponent();
        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {
            lblMsgSize.Text =Convert.ToString(lblMsgSize.Text.Length);
        }

        private void lblRefreshContact_Click(object sender, EventArgs e)
        {
            try
            {
                string tempDir = Path.GetTempPath();
                Console.WriteLine(tempDir);
                string fileName = "Contacts.dat";
                string fullPath = tempDir + fileName;
                //FileStream stream = new FileStream(fullPath, FileMode.CreateNew);
                // Create a StreamWriter from FileStream  
                //StreamWriter sw = new StreamWriter(stream);
                StreamWriter sw = new StreamWriter(fullPath);
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");

                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT MobileNo FROM Measurement", con);
                //con.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    
                    
                    while (reader.Read())
                    {
                        
                        string num = reader["MobileNo"].ToString();
                        RefreshContact(num, fullPath, sw);
                        
                    }
                    MessageBox.Show("Contact Fetched Successfully ..!");
                    sw.Close();
                }
                con.Close();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void RefreshContact(string s, string fullPath, StreamWriter sw)
        {
            
            
            try
            {
                sw.WriteLine(s);
            }
         
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
            finally
            {
                Console.WriteLine("Executing finally block.");
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            string tempDir = Path.GetTempPath();
            Console.WriteLine(tempDir);
            string fileName = "Contacts.dat";
            string fullPath = tempDir + fileName;
            try
            {
                // Create a StreamReader  
                using (StreamReader reader = new StreamReader(fullPath))
                {
                    string line;
                    // Read line by line  
                    //int totalContacts = reader.ReadLine().Length;
                    int i = 0;
                    timer1.Enabled = true;

                    while ((line = reader.ReadLine()) != null)
                    {
                        MsgSend(line);
                        i++;
                    }
                    timer1.Enabled = false;
                    MessageBox.Show("Messages sent successfully");
                }
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
            }
            
        }

        public void MsgSend(string s)
        {


            try
            {
                string mssg = txtMsg.Text.Replace("\n", " ");
                string message = "https://alliedbusinesstech.com/api/sms/index.php?mask=One-O-One&cell=" + s + "&msg=" + mssg;
                WebRequest request = HttpWebRequest.Create(message);
                WebResponse response = request.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string urlText = reader.ReadToEnd(); // it takes the response from your url. now you can use as your need  
                string res = urlText.ToString();
                //txtMsg.Text = "";
                if (res.Contains("Success"))
                {
                    txtMsg.Text = "";
                    //MessageBox.Show("Message sent to Mr. " + "" + " successfully on mobile number: " + "" + " and order Number: " + " ");
                    log.info("Promotion message sent successfully on mobile number: " + s);
                    //return 1;
                }
                else
                {
                    MessageBox.Show("Promotion Message-Number " + s + " is invalid");
                    log.info("Promotion Message-Number " + s + " is invalid");
                    //return 0;
                }
            }
            catch (Exception ex)
            {
                if(ex.ToString().Contains("The remote name could not be resolved"))
                {
                    MessageBox.Show("Please check internet connection");
                }
                log.info("Wifi/Network Error while sending message" + ex);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            progBar.Increment(1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Dashboard DB = new Dashboard();
            DB.Show();
            this.Hide();
        }
    }
}
