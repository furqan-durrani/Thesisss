﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace One_O_One
{
    public partial class BillingForSale : Form
    {
        Logger log = new Logger();
        SaleOrder[] so = new SaleOrder[11];
        double BillingAmount = 0;
        public BillingForSale()
        {
            InitializeComponent();
            //PrintSlip();
        }
        public BillingForSale(string orderId, string name, string mobile, double BillingAmount, SaleOrder[] s)
        {
            InitializeComponent();
            this.so = s;
            txtOrderId.Text = orderId;
            txtNamee.Text = name;
            this.BillingAmount = BillingAmount;
            txtMobile.Text = mobile;
            txtTotalBill.Text = BillingAmount.ToString();
        }
        //SaleOrder[] ss = new SaleOrder[11];
       

        private void BillingForSale_Load(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            double ammountTotal = 0;
            try
            {
                log.info("Saving Sale Record");
                
                for (int k = 1; k <= 10; k++)
                {
                    if (so[k].Name != "" && so[k].amountwithDiscount != "")
                    {
                        //flagForMsgaAndUpdateOrder = 1;
                        log.info("Saving Order:");
                        //log.info(txtOrderId.Text + ":" + cmbItemName.SelectedItem.ToString() + ":" + txtProdType.Text + ":" + txtProdDesc.Text + ":" + txtTotalStock.Text + ":" + txtMeasuringnUnit.Text + ":" + txtUnitPrice.Text + ":" + txtPQuantity.Text + ":" + txtBill.Text + ":" + txtMobile.Text);
                        //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
                        SqlConnection con1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
                        String query1 = "INSERT INTO Sale (ProdId,ProductType,ProductDescription,MeasuringUnit,UnitPrice,Quantity, TotalPrice,DateTime, Param1,Param2, MobileNumber,OrdId) " +
                        "VALUES ('" + so[k].Name + "','" + so[k].prodType + "','" + so[k].prodDesc + "','" + so[k].measuringUnit + "','" + so[k].unitPrice + "','" + so[k].quantity + "','" + so[k].amountwithDiscount + "','" + DateTime.Now + "','" + so[k].discount + "','" + so[k].amountwithDiscount + "','" + so[k].mobile + "', '" + so[k].OrderId + "')";
                        SqlCommand cmd1 = new SqlCommand(query1, con1);
                        log.info("Query to save data in sale table"+query1);
                        con1.Open();
                        int i1 = cmd1.ExecuteNonQuery();

                        con1.Close();

                        if (i1 != 0)
                        {
                            //MessageBox.Show("Successfuly Saved");
                            double remStock = (Convert.ToDouble(so[k].availableStock)) - (Convert.ToDouble(so[k].quantity));
                            double remBal = remStock * (Convert.ToDouble(so[k].amountWithoutDiscount));
                            UpdateStock(Convert.ToString((Convert.ToDouble(so[k].availableStock) - (Convert.ToDouble(so[k].quantity)))), remBal.ToString(), so[k].Name);
                            BillingAmount = BillingAmount + Convert.ToDouble(so[k].amountwithDiscount);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                log.info("Exception while saving sale: " + ex);
                MessageBox.Show("Sale not saved successfully");
            }


            try
            {
                log.info("Going to Write Bill Data:");
                //log.info(txtId.Text + ":" + txtPrice.Text + ":" + txtTotalStock.Text + ":" + txtUnitPrice.Text + ":" + cmbMeasuringUnit.SelectedItem + ":" + cmbProdDescription.SelectedItem + ":" + cmbProductType.SelectedItem);
                //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
                string mobilenoo = txtMobile.Text.Trim();
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
                String query = "INSERT INTO tblSaleOrder (MobileNo,Name,OrderId,DateTime,TotalBill,Quantity,Advance,DueAmount,Flag)" +
                    "VALUES ('" + txtMobile.Text + "','" + txtNamee.Text + "','" + txtOrderId.Text + "','" + DateTime.Now + "','" + txtTotalBill.Text + "','" + txtQuantity.Text + "','" + txtAdvance.Text + "','" + txtDueAmmount.Text + "', 'P')";
                SqlCommand cmd = new SqlCommand(query, con);
                log.info(query);
                con.Open();
                int i = cmd.ExecuteNonQuery();
                con.Close();
                if (i != 0)
                {

                    string messagee = txtMobile.Text + "|Your have purchased Items for Rs." + BillingAmount + " with OrderId" + txtOrderId.Text + ". Total Bill: " + txtTotalBill.Text + ", Adv: " + txtAdvance.Text + ", Due: " + txtDueAmmount.Text + ". Thank you.";
                    //string messagee = txtMobile.Text + "|Mr. " + txtNamee.Text + ", Your order " + txtOrderId.Text + " is created. Please receive within 15days. Total Bill: " + txtTotalBill.Text + ", Adv: " + txtAdvance.Text + ", Due: " + txtDueAmmount.Text + ". Thank you.";
                    log.info("Message send to customer: " + messagee);
                    MessageBox1 msg1 = new MessageBox1(messagee, Convert.ToInt32(txtOrderId.Text), 0);
                    updateOrderId();
                    PrintSlip();
                    ClearForm();
                    Dashboard d = new Dashboard();
                    d.Show();
                    this.Hide();
                }

            }
            catch(Exception ex)
            {
                log.info("Exception while saving sale order: " + ex);
                MessageBox.Show("Sale order not saved successfully");
            }

            
            
        }
        public void UpdateStock(string str, string rembal, string itemName)
        {
            try
            {
                log.info("Updating Stock:");
                //log.info("Previous Stock: " + txtTotalStock.Text + "---new stock: " + str + " after saling quantity: " + txtPQuantity);
                //log.info(txtOrderId.Text + ":" + txtId.Text + ":" + txtProdType.Text + ":" + txtProdDesc.Text + ":" + txtTotalStock.Text + ":" + txtMeasuringnUnit.Text + ":" + txtUnitPrice.Text + ":" + txtPQuantity.Text + ":" + txtBill.Text + ":" + txtMobile.Text);
                //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
                String query = "update stock set TotalStock='" + str + "', TotalPrice='" + rembal + "' where id='" + itemName + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                log.info("Going to updated stock" + query);
                con.Open();
                //con.Open();
                int i = cmd.ExecuteNonQuery();
                con.Close();
                if (i != 0)
                {

                    //MessageBox.Show("Successfuly updated stock");
                    log.info("Stock updated successfully");
                    //ClearForm();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Update stock operation is not successful.");
                log.info("Exception while updating stock in sale method" + ex.ToString());
            }

        }
        private void ClearForm()
        {
            txtOrderId.Text = "";
            txtNamee.Text = "";
            txtMobile.Text = "";
            txtQuantity.Text = "";
            txtUnitExpense.Text = "";
            txtTotalBill.Text = "";
            txtAdvance.Text = "";
            txtDueAmmount.Text = "";
            textBox5.Text = "";
        }
        private void PrintSlip()
        {
            printPreviewDialog1.Document = printDocument1;
            //printPreviewDialog1.Document = printDocument1;
            printDocument1.DefaultPageSettings.PaperSize = new System.Drawing.Printing.PaperSize("pprnm", 280, 700);
            printPreviewDialog1.ShowDialog();
        }
        //private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        //{
        //    int margin = 10;
        //     e.Graphics.DrawString("Due Payment:                  Rs. ", new Font("Arial", 10, FontStyle.Regular), Brushes.Black, new Point(10, margin +10));
        //}
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            //int margin = 10;
            e.Graphics.DrawString("One-O-One Men's Wear", new Font("Arial Black", 12, FontStyle.Bold), Brushes.Black, new Point(35, 10));
            e.Graphics.DrawString("Baldia Road Bahawalnagar", new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(72, 40));
            e.Graphics.DrawString("+923-336-699-101", new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(85, 60));
            e.Graphics.DrawString("Order # " + txtOrderId.Text, new Font("Arial", 8, FontStyle.Bold), Brushes.Black, new Point(109, 75));
            e.Graphics.DrawString("!....Stichting Order....!", new Font("Arial", 9, FontStyle.Bold), Brushes.Black, new Point(75, 90));
            e.Graphics.DrawString("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -", new Font("Arial", 5, FontStyle.Regular), Brushes.Black, new Point(10, 105));
            e.Graphics.DrawString("Customer Info", new Font("Arial Black", 9, FontStyle.Bold), Brushes.Black, new Point(07, 110));
            e.Graphics.DrawString("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -", new Font("Arial", 5, FontStyle.Regular), Brushes.Black, new Point(10, 122));
            e.Graphics.DrawString("Name:       " + txtNamee.Text, new Font("Arial", 10, FontStyle.Regular), Brushes.Black, new Point(10, 130));
            e.Graphics.DrawString("Mobile #:   " + txtMobile.Text, new Font("Arial", 10, FontStyle.Regular), Brushes.Black, new Point(10, 150));
            e.Graphics.DrawString("Date:        " + DateTime.Now, new Font("Arial", 10, FontStyle.Regular), Brushes.Black, new Point(10, 170));

            e.Graphics.DrawString("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -", new Font("Arial", 5, FontStyle.Regular), Brushes.Black, new Point(10, 187));
            e.Graphics.DrawString("Billing Info", new Font("Arial Black", 9, FontStyle.Bold), Brushes.Black, new Point(07, 192));
            e.Graphics.DrawString("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -", new Font("Arial", 5, FontStyle.Regular), Brushes.Black, new Point(10, 204));
            int margin = 204;

            for (int l = 1; l <= 10; l++)
            {
                
                if (so[l].Name != "" && so[l].amountwithDiscount != "")
                {
                    margin = margin + 15;
                    //e.Graphics.DrawString("Billing Info", new Font("Arial Black", 9, FontStyle.Bold), Brushes.Black, new Point(07, margin));
                    e.Graphics.DrawString(so[l].Name + "         RS. " + so[l].amountwithDiscount, new Font("Arial", 10, FontStyle.Regular), Brushes.Black, new Point(10, margin));
                }
            }

            e.Graphics.DrawString("Total Bill:                          RS. " + this.BillingAmount, new Font("Arial", 10, FontStyle.Regular), Brushes.Black, new Point(10, margin + 20));
            e.Graphics.DrawString("Advance Payment:          Rs. " + txtAdvance.Text, new Font("Arial", 10, FontStyle.Regular), Brushes.Black, new Point(10, margin + 40));
            e.Graphics.DrawString("Due Payment:                  Rs. " + txtDueAmmount.Text, new Font("Arial", 10, FontStyle.Regular), Brushes.Black, new Point(10, margin + 60));
        }

        private void updateOrderId()
        {
            try
            {
                log.info("Updating OrderId:");
                log.info("Setting OrderId: " + txtOrderId.Text);
                //log.info(txtOrderId.Text + ":" + txtId.Text + ":" + txtProdType.Text + ":" + txtProdDesc.Text + ":" + txtTotalStock.Text + ":" + txtMeasuringnUnit.Text + ":" + txtUnitPrice.Text + ":" + txtPQuantity.Text + ":" + txtBill.Text + ":" + txtMobile.Text);
                //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
                String query = "update OrderId set OrderId='" + txtOrderId.Text + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                //con.Open();
                int i = cmd.ExecuteNonQuery();

                con.Close();

                if (i != 0)
                {

                    MessageBox.Show("Successfuly Saved");
                    //ClearForm();
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void txtAdvance_TextChanged(object sender, EventArgs e)
        {
            if (txtTotalBill.Text != "" && txtAdvance.Text != "")
            {
                Double TotalBill = Convert.ToDouble(txtTotalBill.Text);
                Double Advance = Convert.ToDouble(txtAdvance.Text);
                txtDueAmmount.Text = Convert.ToString(TotalBill - Advance);
            }
            else
                txtDueAmmount.Text = "";
        }

        private void printDocument1_PrintPage_1(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

        }
    }
}
