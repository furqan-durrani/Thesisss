﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace One_O_One
{
    public class SaleOrder
    {

        public string orderNumberinQue = "";
        public string OrderId = "";
        public string Name = "";
        public string prodType = "";
        public string prodDesc = "";
        public string measuringUnit = "";
        public string availableStock = "";
        public string unitPrice = "";
        public string quantity = "";
        public string discount = "";
        public string mobile = "";
        public string amountWithoutDiscount = "";
        public string amountwithDiscount = "";

        public SaleOrder()
        {

        }

        public SaleOrder(string orderNumberinCart, string Orderidd, string Name, string prodType, string prodDesc, string measuringUnit, string availableStock, string unitPrice, string quantity, string discount, string mobile, string amountWithoutDiscount, string amountwithDiscount)
        {
            this.orderNumberinQue = orderNumberinCart;
            this.OrderId = Orderidd;
            this.Name = Name;
            this.prodType = prodType;
            this.prodDesc = prodDesc;
            this.measuringUnit = measuringUnit;
            this.availableStock = availableStock;
            this.unitPrice = unitPrice;
            this.quantity = quantity;
            this.discount = discount;
            this.mobile = mobile;
            this.amountwithDiscount = amountwithDiscount;
            this.amountWithoutDiscount = amountWithoutDiscount;
        }
        
    }
}