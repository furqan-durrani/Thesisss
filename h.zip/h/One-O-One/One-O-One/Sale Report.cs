﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace One_O_One
{
    public partial class Sale_Report : Form
    {
        public Sale_Report()
        {
            InitializeComponent();
        }

        private void Sale_Report_Load(object sender, EventArgs e)
        {
            fillYear();
            fillMonth();
        }

        private void fillYear()
        {
            cmbYear.Items.Add("2018");
            cmbYear.Items.Add("2019");
            cmbYear.Items.Add("2020");
            cmbYear.Items.Add("2021");
            cmbYear.Items.Add("2022");
            cmbYear.Items.Add("2023");
            cmbYear.Items.Add("2024");
            cmbYear.Items.Add("2025");
            cmbYear.Items.Add("2026");
            cmbYear.Items.Add("2027");
            cmbYear.Items.Add("2028");
            cmbYear.Items.Add("2029");
            cmbYear.Items.Add("2030");
            cmbYear.Items.Add("2031");
            cmbYear.Items.Add("2032");
            cmbYear.Items.Add("2033");
            cmbYear.Items.Add("2034");
            cmbYear.Items.Add("2035");
            cmbYear.Items.Add("2036");

        }

        private void fillMonth()
        {
            cmbMonth.Items.Add("1");
            cmbMonth.Items.Add("2");
            cmbMonth.Items.Add("3");
            cmbMonth.Items.Add("4");
            cmbMonth.Items.Add("5");
            cmbMonth.Items.Add("6");
            cmbMonth.Items.Add("7");
            cmbMonth.Items.Add("8");
            cmbMonth.Items.Add("9");
            cmbMonth.Items.Add("10");
            cmbMonth.Items.Add("11");
            cmbMonth.Items.Add("12");

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM tblSaleOrder", con);
            DataSet ds = new DataSet();
            da.Fill(ds, "tblOrders");
            dataGridView1.DataSource = ds.Tables["tblOrders"].DefaultView;
        }
    }
}
