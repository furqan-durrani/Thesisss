﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace One_O_One
{
    public partial class Sale_Report : Form
    {
        public Sale_Report()
        {
            InitializeComponent();
            btnSave.Text = "Check";
            //selectrecord();

        }
        public void selectrecord()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM tblSaleOrder where Datetime like in ('%07-2021','%06-2021')", con);
            DataSet ds = new DataSet();
            da.Fill(ds, "tblOrders");
            dataGridView1.DataSource = ds.Tables["tblOrders"].DefaultView;
        }
        private void Sale_Report_Load(object sender, EventArgs e)
        {
            fillYear();
            fillMonth();
            filltoYear();
            filltoMonth();
        }

        private void fillMonth()
        {
            cmbPending.Items.Add("Yes");
            cmbPending.Items.Add("No");
            cmbtomonth.Items.Add("1");
            cmbtomonth.Items.Add("2");
            cmbtomonth.Items.Add("3");
            cmbtomonth.Items.Add("4");
            cmbtomonth.Items.Add("5");
            cmbtomonth.Items.Add("6");
            cmbtomonth.Items.Add("7");
            cmbtomonth.Items.Add("8");
            cmbtomonth.Items.Add("9");
            cmbtomonth.Items.Add("10");
            cmbtomonth.Items.Add("11");
            cmbtomonth.Items.Add("12");
        }

        private void filltoYear()
        {
            cmbtoyear.Items.Add("2018");
            cmbtoyear.Items.Add("2019");
            cmbtoyear.Items.Add("2020");
            cmbtoyear.Items.Add("2021");
            cmbtoyear.Items.Add("2022");
            cmbtoyear.Items.Add("2023");
            cmbtoyear.Items.Add("2024");
            cmbtoyear.Items.Add("2025");
            cmbtoyear.Items.Add("2026");
            cmbtoyear.Items.Add("2027");
            cmbtoyear.Items.Add("2028");
            cmbtoyear.Items.Add("2029");
            cmbtoyear.Items.Add("2030");
            cmbtoyear.Items.Add("2031");
            cmbtoyear.Items.Add("2032");
            cmbtoyear.Items.Add("2033");
            cmbtoyear.Items.Add("2034");
            cmbtoyear.Items.Add("2035");
            cmbtoyear.Items.Add("2036");
        }

        private void fillYear()
        {
            cmbYear.Items.Add("2018");
            cmbYear.Items.Add("2019");
            cmbYear.Items.Add("2020");
            cmbYear.Items.Add("2021");
            cmbYear.Items.Add("2022");
            cmbYear.Items.Add("2023");
            cmbYear.Items.Add("2024");
            cmbYear.Items.Add("2025");
            cmbYear.Items.Add("2026");
            cmbYear.Items.Add("2027");
            cmbYear.Items.Add("2028");
            cmbYear.Items.Add("2029");
            cmbYear.Items.Add("2030");
            cmbYear.Items.Add("2031");
            cmbYear.Items.Add("2032");
            cmbYear.Items.Add("2033");
            cmbYear.Items.Add("2034");
            cmbYear.Items.Add("2035");
            cmbYear.Items.Add("2036");

        }

        private void filltoMonth()
        {
            cmbMonth.Items.Add("1");
            cmbMonth.Items.Add("2");
            cmbMonth.Items.Add("3");
            cmbMonth.Items.Add("4");
            cmbMonth.Items.Add("5");
            cmbMonth.Items.Add("6");
            cmbMonth.Items.Add("7");
            cmbMonth.Items.Add("8");
            cmbMonth.Items.Add("9");
            cmbMonth.Items.Add("10");
            cmbMonth.Items.Add("11");
            cmbMonth.Items.Add("12");

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
            SqlDataAdapter da = new SqlDataAdapter("SELECT Id, MobileNo,Name,OrderId,DateTime,TotalBill,Advance,DueAmount FROM tblSaleOrder where DueAmount != '0'", con);
            DataSet ds = new DataSet();
            da.Fill(ds, "tblOrders");
            dataGridView1.DataSource = ds.Tables["tblOrders"].DefaultView;
        }

        private void cmbPending_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cmbPending.SelectedItem.ToString() == "Yes")
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
                SqlDataAdapter da = new SqlDataAdapter("SELECT Id, MobileNo,Name,OrderId,DateTime,TotalBill,Advance,DueAmount FROM tblSaleOrder where DueAmount != '0'", con);
                DataSet ds = new DataSet();
                da.Fill(ds, "tblOrders");
                dataGridView1.DataSource = ds.Tables["tblOrders"].DefaultView;

                SqlConnection con1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
                String query = "select * from Measurement where MobileNo = '" + CustomerId + "' or CustomerNo='" + CustomerId + "'";// where Id='" + txtId.Text + "'";

                SqlCommand cmd = new SqlCommand(query, con1);
                con.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                    }
                }
            }
            else
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
                SqlDataAdapter da = new SqlDataAdapter("SELECT Id, MobileNo,Name,OrderId,DateTime,TotalBill,Advance,DueAmount FROM tblSaleOrder where DueAmount = '0'", con);
                DataSet ds = new DataSet();
                da.Fill(ds, "tblOrders");
                dataGridView1.DataSource = ds.Tables["tblOrders"].DefaultView;
            }
        }
    }
}
