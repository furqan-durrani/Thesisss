﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using System.Data.SqlClient;

namespace One_O_One
{
    public partial class MessageBox1 : Form
    {
        string MobileNum1 = "";
        string Name1 = "";
        string OrderNum1 = "";
        Logger log = new Logger();
        public MessageBox1()
        {
            InitializeComponent();
        }
        public MessageBox1(string CustomerDetails)
        {
            InitializeComponent();
            try
            {
                string[] detailsArray = CustomerDetails.Split('|');
                MobileNum1 = detailsArray[0];
                Name1 = detailsArray[1];
                OrderNum1 = detailsArray[2];
                txtMsgBox.Text = "Hey Mr. ";
            }
            catch(Exception ex)
            {
                log.info("Exception occurs while splitting customer details" + ex);
                MessageBox.Show("Customer record is not complete !");
            }
        }
        public MessageBox1(string CustomerDetails, int orderIdd, int ConfFlag)
        {
            InitializeComponent();
            try
            {
                string[] detailsArray = CustomerDetails.Split('|');
                MobileNum1 = detailsArray[0];
                string message = detailsArray[1];
                int flag = MessageSend(MobileNum1, message);
                if(flag == 1 && ConfFlag == 1)
                {
                    try
                    {
                        log.info("Updating Flag:");
                        log.info("Setting flag to done for orderid: " + orderIdd);
                        //log.info(txtOrderId.Text + ":" + txtId.Text + ":" + txtProdType.Text + ":" + txtProdDesc.Text + ":" + txtTotalStock.Text + ":" + txtMeasuringnUnit.Text + ":" + txtUnitPrice.Text + ":" + txtPQuantity.Text + ":" + txtBill.Text + ":" + txtMobile.Text);
                        //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
                        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
                        String query = "update tblOrders set Flag='D' where OrderId='"+orderIdd+"'";
                        SqlCommand cmd = new SqlCommand(query, con);
                        con.Open();
                        //con.Open();
                        int i = cmd.ExecuteNonQuery();

                        con.Close();

                        if (i != 0)
                        {

                            MessageBox.Show("Message Send Successfuly");
                            //ClearForm();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Unsuccessfuly updated customer order status status");
                        log.info("Exception occurs while updating customer order status of order Id. " + orderIdd);
                    }
                }
                
            }
            catch (Exception ex)
            {
                log.info("Exception occurs while splitting customer details" + ex);
                MessageBox.Show("Customer record is not complete !");
            }
        }
        
        private void MessageBox_Load(object sender, EventArgs e)
        {

        }

        private void btnSendMessage_Click(object sender, EventArgs e)
        {
            MessageSend("","");

        }
        public int MessageSend(string number, string msg)
        {
            try
            {

                string message = "https://alliedbusinesstech.com/api/sms/index.php?mask=One-O-One&cell=" + number + "&msg=" + msg;
                log.info("Message send as: " + message);
                WebRequest request = HttpWebRequest.Create(message);
                WebResponse response = request.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string urlText = reader.ReadToEnd(); // it takes the response from your url. now you can use as your need  
                string res = urlText.ToString();
                txtMsgBox.Text = "";
                if (res.Contains("Success"))
                {
                    txtMsgBox.Text = "";
                    MessageBox.Show("Message sent to Mr. " + "" + " successfully on mobile number: " + "" + " and order Number: " + " ");
                    log.info("Message sent to Mr. " + "" + " successfully on mobile number: " + "number" + " and order Number: " + " ");
                    return 1;
                }
                else
                {
                    MessageBox.Show("Message not sent successfully !");
                    log.info("Message not sent to Mr. " + "" + " successfully on mobile number: " + "" + " and order Number: " + " ");
                    return 0;
                }
            } catch (Exception ex)
            {
                log.info("Error while sending message" + ex);
            }
            return 0;
        }
    }
}
