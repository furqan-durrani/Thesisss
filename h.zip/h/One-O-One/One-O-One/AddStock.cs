﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace One_O_One
{
    public partial class AddStock : Form
    {
        Logger log = new Logger();
        public AddStock()
        {
            InitializeComponent();
            fillProductType();
            txtId.Select();
            fillMeasuringUnit();
            //lblUpdateLabel.Visible = false;
            //cmbItemForUpdate.Visible = false;
            //SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
            //SqlCommand cmd = new SqlCommand("sp_insert", con);
            //con.Open();
        }
        public AddStock(string updateStock)
        {
            InitializeComponent();
            fillProductType();
            txtId.Select();
            fillMeasuringUnit();
            lblUpdateLabel.Visible = true;
            cmbItemForUpdate.Visible = true;
            btnSave.Text = "Update";
            //fillForm();
            fillcmbItemDetails();
            //SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
            //SqlCommand cmd = new SqlCommand("sp_insert", con);
            //con.Open();
        }

        private void fillForm()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
            String query = "select * from Measurement where MobileNo = '" + txtId.Text + "'";// where Id='" + txtId.Text + "'";

            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                }
            }
        }

        private void AddStock_Load(object sender, EventArgs e)
        {
            //txtId.Focus();//.Focus(txtId);
        }
        public void fillMeasuringUnit()
        {

            cmbMeasuringUnit.Items.Add("Count");
            cmbMeasuringUnit.Items.Add("Yardstick");
            //cmbProductType.Items.Add("Unstich");
        }
        public void fillProductType()
        {

            cmbProductType.Items.Add("Unstich");
            cmbProductType.Items.Add("Ready Made");
            //cmbProductType.Items.Add("Unstich");

        }
        public void fillProductDescriptionForReadyMade()
        {

            cmbProdDescription.Items.Add("Sweater");
            cmbProdDescription.Items.Add("Shirt");
            cmbProdDescription.Items.Add("Jeans");
            cmbProdDescription.Items.Add("Gloves");
            cmbProdDescription.Items.Add("Cap");
            cmbProdDescription.Items.Add("Suit");
            cmbProdDescription.Items.Add("Singlet");
            cmbProdDescription.Items.Add("Shoes");
            cmbProdDescription.Items.Add("Flip flops");
            cmbProdDescription.Items.Add("Shorts");
            cmbProdDescription.Items.Add("Cardigan");
            cmbProdDescription.Items.Add("Jacket");
            cmbProdDescription.Items.Add("Bow tie");
            cmbProdDescription.Items.Add("Shirt");
            cmbProdDescription.Items.Add("Vest");
            cmbProdDescription.Items.Add("Jumper");
            cmbProdDescription.Items.Add("Trench coat");
            cmbProdDescription.Items.Add("Bathrobe");
            cmbProdDescription.Items.Add("Cargo pants");
            cmbProdDescription.Items.Add("Swimsuit");
            cmbProdDescription.Items.Add("Blazer");
            cmbProdDescription.Items.Add("T-shirt");
            cmbProdDescription.Items.Add("Belt");
            cmbProdDescription.Items.Add("Underpants");
            cmbProdDescription.Items.Add("Waistcoat");
            cmbProdDescription.Items.Add("Socks");
            cmbProdDescription.Items.Add("Tie");
            cmbProdDescription.Items.Add("Sunglasses");
            cmbProdDescription.Items.Add("Glasses");
            cmbProdDescription.Items.Add("Boots");
            cmbProdDescription.Items.Add("Wallet");
            cmbProdDescription.Items.Add("Handbag");
            cmbProdDescription.Items.Add("Watch");
            //cmbProductType.Items.Add("Unstich");

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(btnSave.Text == "Update")
            {
                log.info("Going to update stock Data:");
                log.info(txtId.Text + ":" + txtPrice.Text + ":" + txtTotalStock.Text + ":" + txtUnitPrice.Text + ":" + cmbMeasuringUnit.SelectedItem + ":" + cmbProdDescription.SelectedItem + ":" + cmbProductType.SelectedItem);
                //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
                String query = "update Stock set Id = '" + txtId.Text + "', ProductType='" + cmbProductType.SelectedItem + "',ProductDescription='" + cmbProdDescription.SelectedItem + "',MeasuringUnit='" + cmbMeasuringUnit.SelectedItem + "', UnitPrice='" + txtUnitPrice.Text + "',TotalStock='" + txtTotalStock.Text + "',TotalPrice='" + txtPrice.Text + "',AddParam1='" + txtRetailPrice.Text + "',AddParam2='" + txttotalRetailPrice.Text + "',AddParam3='" + txtProfit.Text + "'  where Id='"+txtId.Text+"'";
                SqlCommand cmd = new SqlCommand(query, con);
                log.info("Add stock data:" + query);
                con.Open();
                //con.Open();
                int i = cmd.ExecuteNonQuery();

                con.Close();

                if (i != 0)
                {

                    MessageBox.Show("Successfuly Updated");
                    ClearForm();
                }
            }
            else
            {
                log.info("Going to add stock Data:");
                log.info(txtId.Text + ":" + txtPrice.Text + ":" + txtTotalStock.Text + ":" + txtUnitPrice.Text + ":" + cmbMeasuringUnit.SelectedItem + ":" + cmbProdDescription.SelectedItem + ":" + cmbProductType.SelectedItem);
                //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
                String query = "INSERT INTO Stock (Id, ProductType,ProductDescription,MeasuringUnit,UnitPrice,TotalStock,TotalPrice,AddParam1,AddParam2,AddParam3) " +
                    "VALUES ('" + txtId.Text + "','" + cmbProductType.SelectedItem + "','" + cmbProdDescription.SelectedItem + "','" + cmbMeasuringUnit.SelectedItem + "','" + txtUnitPrice.Text + "','" + txtTotalStock.Text + "','" + txtPrice.Text + "','" + txtRetailPrice.Text + "','" + txttotalRetailPrice.Text + "','" + txtProfit.Text + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                log.info("Add stock data:" + query);
                con.Open();
                //con.Open();
                int i = cmd.ExecuteNonQuery();

                con.Close();

                if (i != 0)
                {

                    MessageBox.Show("Successfuly Saved");
                    ClearForm();
                }
            }
        }
        public void ClearForm()
        {
            txtId.Text = "";
            txtProfit.Text = "";
            txtPrice.Text = "";
            txtTotalStock.Text = "";
            txtUnitPrice.Text = "";
            cmbMeasuringUnit.SelectedIndex = -1;
            cmbProdDescription.SelectedIndex = -1;
            cmbProductType.SelectedIndex = -1;
            txtRetailPrice.Text = "";
        }

        private void cmbProductType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if((string)cmbProductType.SelectedItem == "Ready Made")
            {
                cmbProdDescription.Items.Clear();
                fillProductDescriptionForReadyMade();
            }
            else if((string)cmbProductType.SelectedItem == "Unstich")
            {
                cmbProdDescription.Items.Clear();
                cmbProdDescription.Items.Add("Clothes");
            }
        }
        private void txtTotalStock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void txtTotalStock_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txtUnitPrice.Text != "" && txtTotalStock.Text != "")
                {
                    Double unitPrice = Convert.ToDouble(txtUnitPrice.Text);
                    Double stock = Convert.ToDouble(txtTotalStock.Text);
                    txtPrice.Text = Convert.ToString(stock * unitPrice);

                }
                else
                    txtPrice.Text = "";

                if (txtRetailPrice.Text != "" && txtTotalStock.Text != "")
                {
                    Double unitPrice = Convert.ToDouble(txtRetailPrice.Text);
                    Double stock = Convert.ToDouble(txtTotalStock.Text);
                    txttotalRetailPrice.Text = Convert.ToString(stock * unitPrice);
                }
                else
                    txttotalRetailPrice.Text = "";
            }
            catch (Exception ex)
            {
                log.info("exception in txtTotalStock_TextChanged");
            }
            
        }
        private void txtUnitPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                                (e.KeyChar != '.'))
                {
                    e.Handled = true;
                }

                // only allow one decimal point
                if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                log.info("exception in txtTotalStock_TextChanged");
            }

            
        }

        private void txtUnitPrice_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txtUnitPrice.Text != "" && txtTotalStock.Text != "")
                {
                    Double unitPrice = Convert.ToDouble(txtUnitPrice.Text);
                    Double stock = Convert.ToDouble(txtTotalStock.Text);
                    txtPrice.Text = Convert.ToString(stock * unitPrice);
                }
                else
                    txtPrice.Text = "";
            }
            catch (Exception ex)
            {
                log.info("exception in txtprice_textchanged");
            }
            
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            Dashboard DB = new Dashboard();
            DB.Show();
            this.Hide();
        }

        private void button14_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
        private void fillcmbItemDetails()
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
                String query = "select Id from Stock";// where Id='" + txtId.Text + "'";

                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        cmbItemForUpdate.Items.Add(reader["Id"].ToString());
                        //txtOrderId.Text = Convert.ToString(OrdId);
                    }
                }
                con.Close();

            }
            catch (Exception ex)
            {

            }
            
        }

        private void txtId_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void cmbProdDescription_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbMeasuringUnit_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void txtPrice_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txtRetailPrice.Text != "" && txtPrice.Text != "")
                {
                    Double unitPrice = Convert.ToDouble(txttotalRetailPrice.Text);
                    Double stock = Convert.ToDouble(txtPrice.Text);
                    txtProfit.Text = Convert.ToString(unitPrice - stock);
                }
                else
                    txtProfit.Text = "";
            }
            catch(Exception ex)
            {
                log.info("exception in txtprice_textchanged");
            }
            
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txtRetailPrice.Text != "" && txtTotalStock.Text != "")
                {
                    Double unitPrice = Convert.ToDouble(txtRetailPrice.Text);
                    Double stock = Convert.ToDouble(txtTotalStock.Text);
                    txttotalRetailPrice.Text = Convert.ToString(stock * unitPrice);
                }
                else
                    txttotalRetailPrice.Text = "";
            }
            catch (Exception ex)
            {
                log.info("exception in txtprice_textchanged");
            }
            
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void txttotalRetailPrice_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txtRetailPrice.Text != "" && txtPrice.Text != "")
                {
                    Double unitPrice = Convert.ToDouble(txttotalRetailPrice.Text);
                    Double stock = Convert.ToDouble(txtPrice.Text);
                    txtProfit.Text = Convert.ToString(unitPrice - stock);
                }
                else
                    txtProfit.Text = "";
            }
            catch (Exception ex)
            {
                log.info("exception in txtprice_textchanged");
            }
            
        }

        private void cmbItemForUpdate_SelectedIndexChanged(object sender, EventArgs e)
        {
            //log.info("Going to Write Data:");
            //log.info(txtId.Text + ":" + txtPrice.Text + ":" + txtTotalStock.Text + ":" + txtUnitPrice.Text + ":" + cmbMeasuringUnit.SelectedItem + ":" + cmbProdDescription.SelectedItem + ":" + cmbProductType.SelectedItem);
            //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
            String query = "select * from Stock where Id='" + cmbItemForUpdate.SelectedItem.ToString() + "'";

            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    //cmbGhaira.SelectedIndex = cmbGhaira.Items.IndexOf(reader["Ghaira"].ToString());
                    txtId.Text = reader["Id"].ToString();
                    cmbProductType.SelectedIndex = cmbProductType.Items.IndexOf(reader["ProductType"].ToString());
                    cmbProdDescription.SelectedIndex = cmbProdDescription.Items.IndexOf(reader["ProductDescription"].ToString());
                    cmbMeasuringUnit.SelectedIndex = cmbMeasuringUnit.Items.IndexOf(reader["MeasuringUnit"].ToString());
                    txtUnitPrice.Text = reader["UnitPrice"].ToString();
                    txtTotalStock.Text = reader["TotalStock"].ToString();
                    //txtPrice.Text = reader["UnitPrice"].ToString();
                    txtRetailPrice.Text = reader["AddParam1"].ToString();

                }
                else
                {

                    cmbProductType.SelectedIndex = -1;//reader["ProductType"].ToString();
                    cmbProdDescription.SelectedIndex = -1;// reader["ProductDescription"].ToString();
                    cmbMeasuringUnit.SelectedIndex = -1;// reader["MeasuringUnit"].ToString();
                    txtUnitPrice.Text = "";/// reader["UnitPrice"].ToString();
                    txtRetailPrice.Text = "";// reader["TotalStock"].ToString();
                    //txtActualPrice.Text = "";
                }
            }
            con.Close();
        }
    }
}
