﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace One_O_One
{
    public partial class Sale : Form
    {
        Logger log = new Logger();
        SaleOrder s = null;
        int i = 0;
        SaleOrder[] so = new SaleOrder[11];
        public Sale()
        {
            InitializeComponent();
            GetOrderId();
            fillcmbItemDetails();
            txtActualPrice.Hide();
            for (int j = 1; j <= 10; j++)
            {
                so[j] = new SaleOrder("", "", "", "", "", "", "", "", "", "", "", "", "");
            }
        }

        private string GetOrderId()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
            String query = "select OrderId from OrderId";// where Id='" + txtId.Text + "'";

            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    Int64 OrdId = Convert.ToInt64(reader["OrderId"].ToString()) + 1 ;
                    txtOrderId.Text = Convert.ToString(OrdId);
                }
                else
                {
                }
            }
            con.Close();

            return "";
        }
        private void fillcmbItemDetails()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
            String query = "select Id from Stock";// where Id='" + txtId.Text + "'";

            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    cmbItemName.Items.Add(reader["Id"].ToString());
                    //txtOrderId.Text = Convert.ToString(OrdId);
                }
                
            }
            con.Close();
            
        }

        private void txtUnitPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void txtQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void txtBill_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        //private void txtId_TextChanged(object sender, EventArgs e)
        //{
        //    //log.info("Going to Write Data:");
        //    //log.info(txtId.Text + ":" + txtPrice.Text + ":" + txtTotalStock.Text + ":" + txtUnitPrice.Text + ":" + cmbMeasuringUnit.SelectedItem + ":" + cmbProdDescription.SelectedItem + ":" + cmbProductType.SelectedItem);
        //    //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
        //    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
        //    String query = "select * from Stock where Id='"+txtId.Text+"'";

        //    SqlCommand cmd = new SqlCommand(query, con);
        //    con.Open();
        //    using (SqlDataReader reader = cmd.ExecuteReader())
        //    {
        //        if (reader.Read())
        //        {
        //            txtProdType.Text = reader["ProductType"].ToString();
        //            txtProdDesc.Text = reader["ProductDescription"].ToString();
        //            txtMeasuringnUnit.Text = reader["MeasuringUnit"].ToString();
        //            txtUnitPrice.Text = reader["UnitPrice"].ToString();
        //            txtTotalStock.Text = reader["TotalStock"].ToString();
        //        }
        //        else
        //        {
        //            txtProdType.Text = "";//reader["ProductType"].ToString();
        //            txtProdDesc.Text = "";// reader["ProductDescription"].ToString();
        //            txtTotalStock.Text = "";// reader["MeasuringUnit"].ToString();
        //            txtUnitPrice.Text = "";/// reader["UnitPrice"].ToString();
        //            txtMeasuringnUnit.Text = "";// reader["TotalStock"].ToString();
        //        }
        //    }
        //    con.Close();
            
        //}

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            for (int i = 1; i <= 10; i++)
            {
                if (so[i].Name == "" && so[i].OrderId == "")
                {

                    so[i] = new SaleOrder(i.ToString(), txtOrderId.Text, cmbItemName.SelectedItem.ToString(), txtProdType.Text, txtProdDesc.Text, txtMeasuringnUnit.Text, txtTotalStock.Text, txtUnitPrice.Text, txtPQuantity.Text, txtDiscount.Text, txtMobile.Text, txtBill.Text, txtafterdiscbill.Text);

                    switch (i)
                    {
                        case 1:
                            lblItem1.Text = cmbItemName.SelectedItem.ToString();
                            lblQty1.Text = txtPQuantity.Text;
                            lblPrice1.Text = txtafterdiscbill.Text;
                            lblItem1.Visible = true;
                            lblQty1.Visible = true;
                            lblPrice1.Visible = true;
                            btnDelete1.Visible = true;
                            btnUpdate1.Visible = true;
                            break;
                        case 2:
                            lblItem2.Text = cmbItemName.SelectedItem.ToString();
                            lblQty2.Text = txtPQuantity.Text;
                            lblPrice2.Text = txtafterdiscbill.Text;
                            lblItem2.Visible = true;
                            lblQty2.Visible = true;
                            lblPrice2.Visible = true;
                            btnDelete2.Visible = true;
                            break;
                        case 3:
                            lblItem3.Text = cmbItemName.SelectedItem.ToString();
                            lblQty3.Text = txtPQuantity.Text;
                            lblPrice3.Text = txtafterdiscbill.Text;
                            lblItem3.Visible = true;
                            lblQty3.Visible = true;
                            lblPrice3.Visible = true;
                            btnDelete3.Visible = true;
                            break;
                        case 4:
                            lblItem4.Text = cmbItemName.SelectedItem.ToString();
                            lblQty4.Text = txtPQuantity.Text;
                            lblPrice4.Text = txtafterdiscbill.Text;
                            lblItem4.Visible = true;
                            lblQty4.Visible = true;
                            lblPrice4.Visible = true;
                            btnDelete4.Visible = true;
                            break;
                        case 5:
                            lblItem5.Text = cmbItemName.SelectedItem.ToString();
                            lblQty5.Text = txtPQuantity.Text;
                            lblPrice5.Text = txtafterdiscbill.Text;
                            lblItem5.Visible = true;
                            lblQty5.Visible = true;
                            lblPrice5.Visible = true;
                            btnDelete5.Visible = true;
                            break;
                        case 6:
                            lblItem6.Text = cmbItemName.SelectedItem.ToString();
                            lblQty6.Text = txtPQuantity.Text;
                            lblPrice6.Text = txtafterdiscbill.Text;
                            lblItem6.Visible = true;
                            lblQty6.Visible = true;
                            lblPrice6.Visible = true;
                            btnDelete6.Visible = true;
                            break;
                        case 7:
                            lblItem7.Text = cmbItemName.SelectedItem.ToString();
                            lblQty7.Text = txtPQuantity.Text;
                            lblPrice7.Text = txtafterdiscbill.Text;
                            lblItem7.Visible = true;
                            lblQty7.Visible = true;
                            lblPrice7.Visible = true;
                            btnDelete7.Visible = true;
                            break;
                        case 8:
                            lblItem8.Text = cmbItemName.SelectedItem.ToString();
                            lblQty8.Text = txtPQuantity.Text;
                            lblPrice8.Text = txtafterdiscbill.Text;
                            lblItem8.Visible = true;
                            lblQty8.Visible = true;
                            lblPrice8.Visible = true;
                            btnDelete8.Visible = true;
                            break;
                        case 9:
                            lblItem9.Text = cmbItemName.SelectedItem.ToString();
                            lblQty9.Text = txtPQuantity.Text;
                            lblPrice9.Text = txtafterdiscbill.Text;
                            lblItem9.Visible = true;
                            lblQty9.Visible = true;
                            lblPrice9.Visible = true;
                            btnDelete9.Visible = true;
                            break;
                        case 10:
                            lblItem10.Text = cmbItemName.SelectedItem.ToString();
                            lblQty10.Text = txtPQuantity.Text;
                            lblPrice10.Text = txtafterdiscbill.Text;
                            lblItem10.Visible = true;
                            lblQty10.Visible = true;
                            lblPrice10.Visible = true;
                            btnDelete10.Visible = true;
                            break;
                    }
                    
                    break;
                    
                }
            }
            AddAmount();
            //txtPQuantity.Text = "";
            //txtDiscount.Text = "";
            
        }

        private void AddAmount()
        {
            double total = 0.0;
            for (int i = 1; i<=10; i++)
            {
                
                if (so[i].Name != "" && so[i].OrderId != "")
                {
                    total += Convert.ToDouble(so[i].amountwithDiscount);
                }
            }
            lblTotalBill.Text = total.ToString() ;
        }

        private void updateOrderId()
        {
            try
            {
                log.info("Updating OrderId:");
                log.info("Setting OrderId: " + txtOrderId.Text);
                //log.info(txtOrderId.Text + ":" + txtId.Text + ":" + txtProdType.Text + ":" + txtProdDesc.Text + ":" + txtTotalStock.Text + ":" + txtMeasuringnUnit.Text + ":" + txtUnitPrice.Text + ":" + txtPQuantity.Text + ":" + txtBill.Text + ":" + txtMobile.Text);
                //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
                String query = "update OrderId set OrderId='" + txtOrderId.Text + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                //con.Open();
                int i = cmd.ExecuteNonQuery();

                con.Close();

                if (i != 0)
                {

                    MessageBox.Show("Successfuly Saved");
                    //ClearForm();
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void ClearForm()
        {

            txtProdType.Text = "";//reader["ProductType"].ToString();
            txtProdDesc.Text = "";// reader["ProductDescription"].ToString();
            txtTotalStock.Text = "";// reader["MeasuringUnit"].ToString();
            txtUnitPrice.Text = "";/// reader["UnitPrice"].ToString();
            txtMeasuringnUnit.Text = "";// reader["TotalStock"].ToString();
            txtPQuantity.Text = "";
            txtBill.Text = "";
            //cmbItemName.Items.SelectedIndex = -1;
            //cmbItemName.SelectedIndex= -1;
            //txtMobile.Text = "";
            txtDiscount.Text = "";
            txtafterdiscbill.Text = "";
            txtActualPrice.Text = "";
        }

        //public void UpdateStock(string str, string rembal, string itemName)
        //{
        //    try
        //    {
        //        log.info("Updating Stock:");
        //        log.info("Previous Stock: " + txtTotalStock.Text + "---new stock: " + str + " after saling quantity: " + txtPQuantity);
        //        //log.info(txtOrderId.Text + ":" + txtId.Text + ":" + txtProdType.Text + ":" + txtProdDesc.Text + ":" + txtTotalStock.Text + ":" + txtMeasuringnUnit.Text + ":" + txtUnitPrice.Text + ":" + txtPQuantity.Text + ":" + txtBill.Text + ":" + txtMobile.Text);
        //        //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
        //        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
        //        String query = "update stock set TotalStock='" + str + "', TotalPrice='"+rembal+"' where id='" + itemName + "'";
        //        SqlCommand cmd = new SqlCommand(query, con);
        //        log.info("Going to updated stock"+ query);
        //        con.Open();
        //        //con.Open();
        //        int i = cmd.ExecuteNonQuery();
        //        con.Close();
        //        if (i != 0)
        //        {

        //            //MessageBox.Show("Successfuly updated stock");
        //            log.info("Stock updated successfully");
        //            //ClearForm();
        //        }
        //    }
        //    catch(Exception ex)
        //    {
        //        MessageBox.Show("Update stock operation is not successful.");
        //        log.info("Exception while updating stock in sale method" + ex.ToString());
        //    }

        //}
        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtPQuantity_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToInt16(txtTotalStock.Text) - Convert.ToInt16(txtPQuantity.Text) < 0)
                {
                    MessageBox.Show("Required stock is not available.");
                    txtPQuantity.Text = "";
                }
                if (txtPQuantity.Text != "" && txtUnitPrice.Text != "")
                {
                    Double unitPrice = Convert.ToDouble(txtUnitPrice.Text);
                    Double stock = Convert.ToDouble(txtPQuantity.Text);
                    txtBill.Text = Convert.ToString(stock * unitPrice);
                }
                else
                    txtBill.Text = "";

                if (txtUnitPrice.Text != "" && txtDiscount.Text != "" && txtPQuantity.Text != "")
                {
                    Double unitPrice = Convert.ToDouble(txtUnitPrice.Text);
                    Double disc = Convert.ToDouble(txtDiscount.Text);
                    double quan = Convert.ToDouble(txtPQuantity.Text);
                    double discPer = disc / 100;
                    double discAmount = discPer * unitPrice;
                    double totall = unitPrice - discAmount;
                    double totall2 = totall * quan;
                    txtafterdiscbill.Text = totall2.ToString();
                }
                else
                    txtafterdiscbill.Text = "";

            }
            catch (Exception ex)
            {

            }
            
        }

        private void txtUnitPrice_TextChanged(object sender, EventArgs e)
        {
            if (txtUnitPrice.Text != "" && txtPQuantity.Text != "")
            {
                Double unitPrice = Convert.ToDouble(txtUnitPrice.Text);
                Double stock = Convert.ToDouble(txtPQuantity.Text);
                txtBill.Text = Convert.ToString(stock * unitPrice);
            }
            else
                txtBill.Text = "";
        }

        private void Sale_Load(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void txtMobile_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBill_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTotalStock_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMeasuringnUnit_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtProdDesc_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtProdType_TextChanged(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void txtOrderId_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            Dashboard DB = new Dashboard();
            DB.Show();
            this.Hide();
        }

        private void button14_Click(object sender, EventArgs e)
        {

        }

        private void cmbItemName_SelectedIndexChanged(object sender, EventArgs e)
        {
            //log.info("Going to Write Data:");
            //log.info(txtId.Text + ":" + txtPrice.Text + ":" + txtTotalStock.Text + ":" + txtUnitPrice.Text + ":" + cmbMeasuringUnit.SelectedItem + ":" + cmbProdDescription.SelectedItem + ":" + cmbProductType.SelectedItem);
            //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
            String query = "select * from Stock where Id='" + cmbItemName.SelectedItem.ToString() + "'";

            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    txtProdType.Text = reader["ProductType"].ToString();
                    txtProdDesc.Text = reader["ProductDescription"].ToString();
                    txtMeasuringnUnit.Text = reader["MeasuringUnit"].ToString();
                    txtUnitPrice.Text = reader["AddParam1"].ToString();
                    txtTotalStock.Text = reader["TotalStock"].ToString();
                    txtActualPrice.Text = reader["UnitPrice"].ToString();
                   
                }
                else
                {
                    txtProdType.Text = "";//reader["ProductType"].ToString();
                    txtProdDesc.Text = "";// reader["ProductDescription"].ToString();
                    txtTotalStock.Text = "";// reader["MeasuringUnit"].ToString();
                    txtUnitPrice.Text = "";/// reader["UnitPrice"].ToString();
                    txtMeasuringnUnit.Text = "";// reader["TotalStock"].ToString();
                    txtActualPrice.Text = "";
                }
            }
            con.Close();
        }

        private void txtDiscount_TextChanged(object sender, EventArgs e)
        {
            if (txtUnitPrice.Text != "" && txtDiscount.Text != "" && txtPQuantity.Text != "")
            {
                Double unitPrice = Convert.ToDouble(txtUnitPrice.Text);
                Double disc = Convert.ToDouble(txtDiscount.Text);
                double quan = Convert.ToDouble(txtPQuantity.Text);
                double discPer = disc / 100;
                double discAmount = discPer * unitPrice;
                double totall = unitPrice - discAmount;
                double totall2 = totall * quan;
                txtafterdiscbill.Text = totall2.ToString();
            }
            else
                txtafterdiscbill.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete1_Click(object sender, EventArgs e)
        {
            so[1] = new SaleOrder("", "", "", "", "", "", "", "", "", "", "", "", "");
            lblItem1.Text = ""; //lblItem3.Text;
            lblQty1.Text = "";// lblQty3.Text;
            lblPrice1.Text = "";
            AddAmount();
        }

        private void btnDelete2_Click(object sender, EventArgs e)
        {
            so[2] = new SaleOrder("", "", "", "", "", "", "", "", "", "", "", "", "");
            lblItem2.Text = ""; //lblItem3.Text;
            lblQty2.Text = "";// lblQty3.Text;
            lblPrice2.Text = "";
            AddAmount();
        }
    

        private void btnDelete3_Click(object sender, EventArgs e)
        {
            so[3] = new SaleOrder("", "", "", "", "", "", "", "", "", "", "", "", "");
            lblItem3.Text = ""; //lblItem3.Text;
            lblQty3.Text = "";// lblQty3.Text;
            lblPrice3.Text = "";
            AddAmount();
        }

        private void btnDelete4_Click(object sender, EventArgs e)
        {
            so[4] = new SaleOrder("", "", "", "", "", "", "", "", "", "", "", "", "");
            lblItem4.Text = ""; //lblItem3.Text;
            lblQty4.Text = "";// lblQty3.Text;
            lblPrice4.Text = "";
            AddAmount();
        }

        private void btnDelete5_Click(object sender, EventArgs e)
        {
            so[5] = new SaleOrder("", "", "", "", "", "", "", "", "", "", "", "", "");
            lblItem5.Text = ""; //lblItem3.Text;
            lblQty5.Text = "";// lblQty3.Text;
            lblPrice5.Text = "";
            AddAmount();
        }

        private void btnDelete6_Click(object sender, EventArgs e)
        {
            so[6] = new SaleOrder("", "", "", "", "", "", "", "", "", "", "", "", "");
            lblItem6.Text = ""; //lblItem3.Text;
            lblQty6.Text = "";// lblQty3.Text;
            lblPrice6.Text = "";
            AddAmount();
        }

        private void btnDelete7_Click(object sender, EventArgs e)
        {
            so[7] = new SaleOrder("", "", "", "", "", "", "", "", "", "", "", "", "");
            lblItem7.Text = ""; //lblItem3.Text;
            lblQty7.Text = "";// lblQty3.Text;
            lblPrice7.Text = "";
            AddAmount();
        }

        private void btnDelete8_Click(object sender, EventArgs e)
        {
            so[8] = new SaleOrder("", "", "", "", "", "", "", "", "", "", "", "", "");
            lblItem8.Text = ""; //lblItem3.Text;
            lblQty8.Text = "";// lblQty3.Text;
            lblPrice8.Text = "";
            AddAmount();
        }


        private void btnDelete9_Click(object sender, EventArgs e)
        {
            so[9] = new SaleOrder("", "", "", "", "", "", "", "", "", "", "", "", "");
            lblItem9.Text = ""; //lblItem3.Text;
            lblQty9.Text = "";// lblQty3.Text;
            lblPrice9.Text = "";
            AddAmount();
        }

        private void btnDelete10_Click(object sender, EventArgs e)
        {
            so[10] = new SaleOrder("", "", "", "", "", "", "", "", "", "", "", "", "");
            lblItem10.Text = ""; //lblItem3.Text;
            lblQty10.Text = "";// lblQty3.Text;
            lblPrice10.Text = "";
            AddAmount();
        }

        public void btnConfirm_Click(object sender, EventArgs e)
        {
            int flagForMsgaAndUpdateOrder = 1;
            double ammountTotal = 0;
            //for (int k = 1; k <= 10; k++)
            //{
            //    if (so[k].Name != "" && so[k].amountwithDiscount != "")
            //    {
            //        flagForMsgaAndUpdateOrder = 1;
            //        log.info("Saving Order:");
            //        log.info(txtOrderId.Text + ":" + cmbItemName.SelectedItem.ToString()+ ":" + txtProdType.Text + ":" + txtProdDesc.Text + ":" + txtTotalStock.Text + ":" + txtMeasuringnUnit.Text + ":" + txtUnitPrice.Text + ":" + txtPQuantity.Text + ":" + txtBill.Text + ":" + txtMobile.Text);
            //        //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
            //        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
            //        String query = "INSERT INTO Sale (ProdId,ProductType,ProductDescription,MeasuringUnit,UnitPrice,Quantity, TotalPrice,DateTime, Param1,Param2, MobileNumber,OrdId) " +
            //        "VALUES ('" + so[k].Name + "','" + so[k].prodType + "','" + so[k].prodDesc + "','" + so[k].measuringUnit + "','" + so[k].unitPrice + "','" + so[k].quantity + "','" + so[k].amountwithDiscount + "','" + DateTime.Now + "','" + so[k].discount + "','" + so[k].amountwithDiscount + "','" + so[k].mobile + "', '" + so[k].OrderId + "')";
            //        SqlCommand cmd = new SqlCommand(query, con);
            //        con.Open();
            //        int i = cmd.ExecuteNonQuery();

            //        con.Close();

            //        if (i != 0)
            //        {
            //            //MessageBox.Show("Successfuly Saved");
            //            double remStock = (Convert.ToDouble(so[k].availableStock)) - (Convert.ToDouble(so[k].quantity));
            //            double remBal = remStock * (Convert.ToDouble(so[k].amountWithoutDiscount));
            //            UpdateStock(Convert.ToString((Convert.ToDouble(so[k].availableStock) - (Convert.ToDouble(so[k].quantity)))), remBal.ToString(), so[k].Name);
            //            ammountTotal = ammountTotal + Convert.ToDouble(so[k].amountwithDiscount);
            //        }
            //    }
            //}

            for (int k = 1; k <= 10; k++)
            {
                if (so[k].Name != "" && so[k].amountwithDiscount != "")
                {
                    ammountTotal = ammountTotal + Convert.ToDouble(so[k].amountwithDiscount);
                }
            }
            if (flagForMsgaAndUpdateOrder == 1)
            {
                BillingForSale b = new BillingForSale(txtOrderId.Text, "Guest", txtMobile.Text, ammountTotal, so);
                b.Show();
                this.Hide();
                ClearForm();
            }
        }
    }
}
