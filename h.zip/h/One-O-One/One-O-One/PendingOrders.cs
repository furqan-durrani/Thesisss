﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace One_O_One
{
    public partial class PendingOrders : Form
    {
        public PendingOrders()
        {
            InitializeComponent();
            load_data();

        }
        public void load_data()
        {
            
                try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");

                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT OrderId, Name, MobileNo FROM tblOrders where Flag='P'", con);
                //SqlCommand cmd = new SqlCommand("SELECT * FROM Measurement", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                PendingItems.DataSource = dt;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //MessageBox1 msg = new MessageBox1("");
            
                try
                {
                    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");

                    con.Open();
                    SqlCommand cmd = new SqlCommand("SELECT OrderId, MobileNo, Name, DueAmount FROM tblOrders where OrderId='"+textBox1.Text+"'", con);
                    //SqlCommand cmd = new SqlCommand(query, con);
                    //con.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        string mblNo = reader["MobileNo"].ToString();
                        string Name = reader["Name"].ToString();
                        string DueAmount = reader["DueAmount"].ToString();
                        con.Close();
                        MessageBox1 msg = new MessageBox1(mblNo+"|Mr. "+Name+", Your order " + textBox1.Text + " is ready. Your Due Amount  is "+ DueAmount + ". Please visit and collect. Thank you.", Convert.ToInt32(textBox1.Text),1);
                        //msg.Show();
                    }
                    else
                    {
                    }
                }
                con.Close();
                load_data();
            }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

        
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Dashboard DB = new Dashboard();
            DB.Show();
            this.Hide();
        }

        private void PendingOrders_Load(object sender, EventArgs e)
        {

        }
    }
}
