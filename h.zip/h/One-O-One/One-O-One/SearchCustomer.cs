﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace One_O_One
{
    public partial class SearchCustomer : Form
    {
        string UpdateId = "";
        public SearchCustomer()
        {
            InitializeComponent();
        }

        private void btnSearchCustomer_Click(object sender, EventArgs e)
        {
            MeasurementsOrder mo = new MeasurementsOrder(UpdateId, "S");
            mo.Show();
            this.Hide();
        }

        private void txtCustomerNo_TextChanged(object sender, EventArgs e)
        {
            if(txtMobileNumber.Text != "")
            {
                txtMobileNumber.Text = "";
            }
            //log.info("Going to Write Data:");
            //log.info(txtId.Text + ":" + txtPrice.Text + ":" + txtTotalStock.Text + ":" + txtUnitPrice.Text + ":" + cmbMeasuringUnit.SelectedItem + ":" + cmbProdDescription.SelectedItem + ":" + cmbProductType.SelectedItem);
            //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
            String query = "select * from Measurement where CustomerNo='" + txtCustomerNo.Text + "'";

            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    //txtMobileNumber.Text = reader["MobileNo"].ToString();
                    txtName.Text = reader["Name"].ToString();
                    btnSearchCustomer.Enabled = true;
                    UpdateId = txtCustomerNo.Text;

                }
                else
                {
                    //txtMobileNumber.Text = "";
                    txtName.Text = "";//reader["ProductType"].ToString();
                    btnSearchCustomer.Enabled = false;
                    UpdateId = "";
                }
            }
            con.Close();
        }

        private void txtMobileNumber_TextChanged(object sender, EventArgs e)
        {
            if (txtCustomerNo.Text != "")
            {
                txtCustomerNo.Text = "";
            }
            //log.info("Going to Write Data:");
            //log.info(txtId.Text + ":" + txtPrice.Text + ":" + txtTotalStock.Text + ":" + txtUnitPrice.Text + ":" + cmbMeasuringUnit.SelectedItem + ":" + cmbProdDescription.SelectedItem + ":" + cmbProductType.SelectedItem);
            //SqlConnection con = new SqlConnection("Data Source=NiluNilesh;Integrated Security=True");  
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\db\One-O-One.mdf;Integrated Security=True;Connect Timeout=30");
            String query = "select * from Measurement where MobileNo='" + txtMobileNumber.Text + "'";

            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    //txtCustomerNo.Text = reader["CustomerNo"].ToString();
                    txtName.Text = reader["Name"].ToString();
                    btnSearchCustomer.Enabled = true;
                    UpdateId = txtMobileNumber.Text;
                }
                else
                {
                    //txtCustomerNo.Text = "";
                    txtName.Text = "";//reader["ProductType"].ToString();
                    btnSearchCustomer.Enabled = false;
                    UpdateId = "";

                }
            }
            con.Close();
        }
    }
}

