﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace One_O_One
{
    public partial class SingleMessaageWindow : Form
    {
        Logger log = new Logger();
        public SingleMessaageWindow()
        {
            InitializeComponent();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                string message = "https://alliedbusinesstech.com/api/sms/index.php?mask=One-O-One&cell=" + txtmobileNo.Text + "&msg=" + txtMessage.Text;
                log.info("single Message send as: " + message);
                WebRequest request = HttpWebRequest.Create(message);
                WebResponse response = request.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string urlText = reader.ReadToEnd(); // it takes the response from your url. now you can use as your need  
                string res = urlText.ToString();
                txtMessage.Text = "";
                if (res.Contains("Success"))
                {
                    txtMessage.Text = "";
                    MessageBox.Show("Message sent to Mr. " + "" + " successfully on mobile number: " + "txt");
                    log.info("Message sent to Mr. " + "" + " successfully on mobile number: " + "number" + " and order Number: " + " ");
                    //return 1;
                }
                else
                {
                    MessageBox.Show("Message not sent successfully !");
                    log.info("Message not sent to Mr. " + "" + " successfully on mobile number: " + "" + " and order Number: " + " ");
                    //return 0;
                }
            }
            catch (Exception ex)
            {
                log.info("Error while sending message" + ex);
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Dashboard db = new Dashboard();
            db.Show();
            this.Hide();
        }
    }
}
