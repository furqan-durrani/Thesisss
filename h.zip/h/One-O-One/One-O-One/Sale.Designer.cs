﻿namespace One_O_One
{
    partial class Sale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Sale));
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label17 = new System.Windows.Forms.Label();
            this.txtMobile = new System.Windows.Forms.TextBox();
            this.txtPQuantity = new System.Windows.Forms.TextBox();
            this.txtUnitPrice = new System.Windows.Forms.TextBox();
            this.txtTotalStock = new System.Windows.Forms.TextBox();
            this.txtMeasuringnUnit = new System.Windows.Forms.TextBox();
            this.txtProdDesc = new System.Windows.Forms.TextBox();
            this.txtProdType = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtOrderId = new System.Windows.Forms.TextBox();
            this.cmbItemName = new System.Windows.Forms.ComboBox();
            this.txtDiscount = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtafterdiscbill = new System.Windows.Forms.TextBox();
            this.txtBill = new System.Windows.Forms.TextBox();
            this.txtActualPrice = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lblPrice10 = new System.Windows.Forms.Label();
            this.lblQty10 = new System.Windows.Forms.Label();
            this.lblItem10 = new System.Windows.Forms.Label();
            this.lblPrice9 = new System.Windows.Forms.Label();
            this.lblQty9 = new System.Windows.Forms.Label();
            this.lblItem9 = new System.Windows.Forms.Label();
            this.lblPrice8 = new System.Windows.Forms.Label();
            this.lblQty8 = new System.Windows.Forms.Label();
            this.lblItem8 = new System.Windows.Forms.Label();
            this.lblPrice7 = new System.Windows.Forms.Label();
            this.lblQty7 = new System.Windows.Forms.Label();
            this.lblItem7 = new System.Windows.Forms.Label();
            this.lblPrice6 = new System.Windows.Forms.Label();
            this.lblQty6 = new System.Windows.Forms.Label();
            this.lblItem6 = new System.Windows.Forms.Label();
            this.lblPrice5 = new System.Windows.Forms.Label();
            this.lblQty5 = new System.Windows.Forms.Label();
            this.lblItem5 = new System.Windows.Forms.Label();
            this.lblPrice4 = new System.Windows.Forms.Label();
            this.lblQty4 = new System.Windows.Forms.Label();
            this.lblItem4 = new System.Windows.Forms.Label();
            this.lblPrice3 = new System.Windows.Forms.Label();
            this.lblQty3 = new System.Windows.Forms.Label();
            this.lblItem3 = new System.Windows.Forms.Label();
            this.lblPrice2 = new System.Windows.Forms.Label();
            this.lblQty2 = new System.Windows.Forms.Label();
            this.lblItem2 = new System.Windows.Forms.Label();
            this.lblPrice1 = new System.Windows.Forms.Label();
            this.lblQty1 = new System.Windows.Forms.Label();
            this.btnDelete4 = new System.Windows.Forms.Button();
            this.btnUpdate4 = new System.Windows.Forms.Button();
            this.btnDelete3 = new System.Windows.Forms.Button();
            this.btnUpdate3 = new System.Windows.Forms.Button();
            this.btnDelete2 = new System.Windows.Forms.Button();
            this.btnUpdate2 = new System.Windows.Forms.Button();
            this.btnDelete1 = new System.Windows.Forms.Button();
            this.btnUpdate1 = new System.Windows.Forms.Button();
            this.btnUpdate5 = new System.Windows.Forms.Button();
            this.btnUpdate6 = new System.Windows.Forms.Button();
            this.btnDelete5 = new System.Windows.Forms.Button();
            this.btnDelete6 = new System.Windows.Forms.Button();
            this.btnUpdate8 = new System.Windows.Forms.Button();
            this.btnUpdate7 = new System.Windows.Forms.Button();
            this.btnUpdate9 = new System.Windows.Forms.Button();
            this.btnUpdate10 = new System.Windows.Forms.Button();
            this.btnDelete7 = new System.Windows.Forms.Button();
            this.btnDelete8 = new System.Windows.Forms.Button();
            this.btnDelete9 = new System.Windows.Forms.Button();
            this.btnDelete10 = new System.Windows.Forms.Button();
            this.lblItem1 = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.lblTotalBill = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label10.Location = new System.Drawing.Point(312, 49);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 25);
            this.label10.TabIndex = 19;
            this.label10.Text = "Sale";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label9.ForeColor = System.Drawing.Color.Silver;
            this.label9.Location = new System.Drawing.Point(594, 606);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(267, 16);
            this.label9.TabIndex = 7;
            this.label9.Text = "For any support regarding this app, please email";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label8.Location = new System.Drawing.Point(594, 622);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(160, 16);
            this.label8.TabIndex = 6;
            this.label8.Text = "furqan_durrani@yahoo.com";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label6.Location = new System.Drawing.Point(6, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 25);
            this.label6.TabIndex = 15;
            this.label6.Text = "Dashboard";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.label17, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtMobile, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.txtPQuantity, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.txtUnitPrice, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtTotalStock, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.txtMeasuringnUnit, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtProdDesc, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtProdType, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.label18, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.label14, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.label11, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label12, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label19, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label16, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label13, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtOrderId, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.cmbItemName, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtDiscount, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.label20, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.btnSave, 2, 14);
            this.tableLayoutPanel1.Controls.Add(this.label21, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.label15, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.txtafterdiscbill, 2, 11);
            this.tableLayoutPanel1.Controls.Add(this.txtBill, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.txtActualPrice, 0, 14);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(276, 77);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 15;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(454, 444);
            this.tableLayoutPanel1.TabIndex = 20;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label17.Location = new System.Drawing.Point(3, 6);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(71, 21);
            this.label17.TabIndex = 28;
            this.label17.Text = "OrderId";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // txtMobile
            // 
            this.txtMobile.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMobile.Location = new System.Drawing.Point(229, 302);
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.Size = new System.Drawing.Size(211, 27);
            this.txtMobile.TabIndex = 23;
            this.txtMobile.TextChanged += new System.EventHandler(this.txtMobile_TextChanged);
            // 
            // txtPQuantity
            // 
            this.txtPQuantity.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPQuantity.Location = new System.Drawing.Point(229, 236);
            this.txtPQuantity.Name = "txtPQuantity";
            this.txtPQuantity.Size = new System.Drawing.Size(211, 27);
            this.txtPQuantity.TabIndex = 20;
            this.txtPQuantity.TextChanged += new System.EventHandler(this.txtPQuantity_TextChanged);
            this.txtPQuantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQuantity_KeyPress);
            // 
            // txtUnitPrice
            // 
            this.txtUnitPrice.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUnitPrice.Location = new System.Drawing.Point(229, 203);
            this.txtUnitPrice.Name = "txtUnitPrice";
            this.txtUnitPrice.ReadOnly = true;
            this.txtUnitPrice.Size = new System.Drawing.Size(211, 27);
            this.txtUnitPrice.TabIndex = 18;
            this.txtUnitPrice.TextChanged += new System.EventHandler(this.txtUnitPrice_TextChanged);
            this.txtUnitPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUnitPrice_KeyPress);
            // 
            // txtTotalStock
            // 
            this.txtTotalStock.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalStock.Location = new System.Drawing.Point(229, 170);
            this.txtTotalStock.Name = "txtTotalStock";
            this.txtTotalStock.ReadOnly = true;
            this.txtTotalStock.Size = new System.Drawing.Size(211, 27);
            this.txtTotalStock.TabIndex = 27;
            this.txtTotalStock.TextChanged += new System.EventHandler(this.txtTotalStock_TextChanged);
            // 
            // txtMeasuringnUnit
            // 
            this.txtMeasuringnUnit.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMeasuringnUnit.Location = new System.Drawing.Point(229, 137);
            this.txtMeasuringnUnit.Name = "txtMeasuringnUnit";
            this.txtMeasuringnUnit.ReadOnly = true;
            this.txtMeasuringnUnit.Size = new System.Drawing.Size(211, 27);
            this.txtMeasuringnUnit.TabIndex = 19;
            this.txtMeasuringnUnit.TextChanged += new System.EventHandler(this.txtMeasuringnUnit_TextChanged);
            // 
            // txtProdDesc
            // 
            this.txtProdDesc.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProdDesc.Location = new System.Drawing.Point(229, 104);
            this.txtProdDesc.Name = "txtProdDesc";
            this.txtProdDesc.ReadOnly = true;
            this.txtProdDesc.Size = new System.Drawing.Size(211, 27);
            this.txtProdDesc.TabIndex = 26;
            this.txtProdDesc.TextChanged += new System.EventHandler(this.txtProdDesc_TextChanged);
            // 
            // txtProdType
            // 
            this.txtProdType.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProdType.Location = new System.Drawing.Point(229, 71);
            this.txtProdType.Name = "txtProdType";
            this.txtProdType.ReadOnly = true;
            this.txtProdType.Size = new System.Drawing.Size(211, 27);
            this.txtProdType.TabIndex = 25;
            this.txtProdType.TextChanged += new System.EventHandler(this.txtProdType_TextChanged);
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label18.Location = new System.Drawing.Point(3, 305);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(129, 21);
            this.label18.TabIndex = 8;
            this.label18.Text = "Mobile Number";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label14.Location = new System.Drawing.Point(3, 239);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 21);
            this.label14.TabIndex = 17;
            this.label14.Text = "Quantity";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label11.Location = new System.Drawing.Point(3, 206);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(82, 21);
            this.label11.TabIndex = 16;
            this.label11.Text = "Unit Price";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label12.Location = new System.Drawing.Point(3, 173);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(132, 21);
            this.label12.TabIndex = 21;
            this.label12.Text = "Available Stock";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label19.Location = new System.Drawing.Point(3, 140);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(126, 21);
            this.label19.TabIndex = 9;
            this.label19.Text = "Measuring Unit";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label16.Location = new System.Drawing.Point(3, 107);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(163, 21);
            this.label16.TabIndex = 6;
            this.label16.Text = "Product Description";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label13.Location = new System.Drawing.Point(3, 74);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(113, 21);
            this.label13.TabIndex = 3;
            this.label13.Text = "Product Type";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label7.Location = new System.Drawing.Point(3, 40);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 21);
            this.label7.TabIndex = 0;
            this.label7.Text = "Name";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // txtOrderId
            // 
            this.txtOrderId.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOrderId.Location = new System.Drawing.Point(229, 3);
            this.txtOrderId.Name = "txtOrderId";
            this.txtOrderId.ReadOnly = true;
            this.txtOrderId.Size = new System.Drawing.Size(211, 27);
            this.txtOrderId.TabIndex = 29;
            this.txtOrderId.TextChanged += new System.EventHandler(this.txtOrderId_TextChanged);
            // 
            // cmbItemName
            // 
            this.cmbItemName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbItemName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbItemName.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbItemName.FormattingEnabled = true;
            this.cmbItemName.Location = new System.Drawing.Point(229, 36);
            this.cmbItemName.Name = "cmbItemName";
            this.cmbItemName.Size = new System.Drawing.Size(211, 29);
            this.cmbItemName.TabIndex = 30;
            this.cmbItemName.SelectedIndexChanged += new System.EventHandler(this.cmbItemName_SelectedIndexChanged);
            // 
            // txtDiscount
            // 
            this.txtDiscount.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiscount.Location = new System.Drawing.Point(229, 269);
            this.txtDiscount.Name = "txtDiscount";
            this.txtDiscount.Size = new System.Drawing.Size(211, 27);
            this.txtDiscount.TabIndex = 33;
            this.txtDiscount.TextChanged += new System.EventHandler(this.txtDiscount_TextChanged);
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label20.Location = new System.Drawing.Point(3, 272);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(78, 21);
            this.label20.TabIndex = 34;
            this.label20.Text = "Discount";
            // 
            // btnSave
            // 
            this.btnSave.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.btnSave.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSave.Location = new System.Drawing.Point(287, 404);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(164, 34);
            this.btnSave.TabIndex = 22;
            this.btnSave.Text = "add";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label21
            // 
            this.label21.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label21.Location = new System.Drawing.Point(3, 338);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(174, 21);
            this.label21.TabIndex = 35;
            this.label21.Text = "Total Bill without disc.";
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label15.Location = new System.Drawing.Point(3, 371);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(147, 21);
            this.label15.TabIndex = 31;
            this.label15.Text = "Total Bill after disc";
            // 
            // txtafterdiscbill
            // 
            this.txtafterdiscbill.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtafterdiscbill.Location = new System.Drawing.Point(229, 368);
            this.txtafterdiscbill.Name = "txtafterdiscbill";
            this.txtafterdiscbill.ReadOnly = true;
            this.txtafterdiscbill.Size = new System.Drawing.Size(211, 27);
            this.txtafterdiscbill.TabIndex = 36;
            // 
            // txtBill
            // 
            this.txtBill.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBill.Location = new System.Drawing.Point(229, 335);
            this.txtBill.Name = "txtBill";
            this.txtBill.ReadOnly = true;
            this.txtBill.Size = new System.Drawing.Size(211, 27);
            this.txtBill.TabIndex = 32;
            // 
            // txtActualPrice
            // 
            this.txtActualPrice.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtActualPrice.Location = new System.Drawing.Point(3, 401);
            this.txtActualPrice.Name = "txtActualPrice";
            this.txtActualPrice.Size = new System.Drawing.Size(175, 27);
            this.txtActualPrice.TabIndex = 37;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 647);
            this.panel1.TabIndex = 7;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(149, 484);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Furqan Durrani";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 6.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(149, 467);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "Developed By:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(50, 270);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Store for Men";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(58, 231);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "One O One";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(29, 196);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(194, 25);
            this.label2.TabIndex = 0;
            this.label2.Text = "Welcome To The";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(60, 35);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(120, 120);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel2.Controls.Add(this.tableLayoutPanel2);
            this.panel2.Controls.Add(this.tableLayoutPanel1);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.button15);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1211, 647);
            this.panel2.TabIndex = 8;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 5;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.Controls.Add(this.lblPrice10, 4, 9);
            this.tableLayoutPanel2.Controls.Add(this.lblQty10, 3, 9);
            this.tableLayoutPanel2.Controls.Add(this.lblItem10, 2, 9);
            this.tableLayoutPanel2.Controls.Add(this.lblPrice9, 4, 8);
            this.tableLayoutPanel2.Controls.Add(this.lblQty9, 3, 8);
            this.tableLayoutPanel2.Controls.Add(this.lblItem9, 2, 8);
            this.tableLayoutPanel2.Controls.Add(this.lblPrice8, 4, 7);
            this.tableLayoutPanel2.Controls.Add(this.lblQty8, 3, 7);
            this.tableLayoutPanel2.Controls.Add(this.lblItem8, 2, 7);
            this.tableLayoutPanel2.Controls.Add(this.lblPrice7, 4, 6);
            this.tableLayoutPanel2.Controls.Add(this.lblQty7, 3, 6);
            this.tableLayoutPanel2.Controls.Add(this.lblItem7, 2, 6);
            this.tableLayoutPanel2.Controls.Add(this.lblPrice6, 4, 5);
            this.tableLayoutPanel2.Controls.Add(this.lblQty6, 3, 5);
            this.tableLayoutPanel2.Controls.Add(this.lblItem6, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.lblPrice5, 4, 4);
            this.tableLayoutPanel2.Controls.Add(this.lblQty5, 3, 4);
            this.tableLayoutPanel2.Controls.Add(this.lblItem5, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.lblPrice4, 4, 3);
            this.tableLayoutPanel2.Controls.Add(this.lblQty4, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this.lblItem4, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.lblPrice3, 4, 2);
            this.tableLayoutPanel2.Controls.Add(this.lblQty3, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.lblItem3, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.lblPrice2, 4, 1);
            this.tableLayoutPanel2.Controls.Add(this.lblQty2, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.lblItem2, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.lblPrice1, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.lblQty1, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.btnDelete4, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.btnUpdate4, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.btnDelete3, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.btnUpdate3, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.btnDelete2, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.btnUpdate2, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.btnDelete1, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.btnUpdate1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.btnUpdate5, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.btnUpdate6, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.btnDelete5, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.btnDelete6, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.btnUpdate8, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.btnUpdate7, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.btnUpdate9, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.btnUpdate10, 0, 9);
            this.tableLayoutPanel2.Controls.Add(this.btnDelete7, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.btnDelete8, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.btnDelete9, 1, 8);
            this.tableLayoutPanel2.Controls.Add(this.btnDelete10, 1, 9);
            this.tableLayoutPanel2.Controls.Add(this.lblItem1, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.btnConfirm, 4, 11);
            this.tableLayoutPanel2.Controls.Add(this.lblTotalBill, 4, 10);
            this.tableLayoutPanel2.Controls.Add(this.label22, 2, 10);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(774, 74);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 12;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.Size = new System.Drawing.Size(363, 398);
            this.tableLayoutPanel2.TabIndex = 21;
            // 
            // lblPrice10
            // 
            this.lblPrice10.AutoSize = true;
            this.lblPrice10.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice10.Location = new System.Drawing.Point(291, 261);
            this.lblPrice10.Name = "lblPrice10";
            this.lblPrice10.Size = new System.Drawing.Size(52, 18);
            this.lblPrice10.TabIndex = 49;
            this.lblPrice10.Text = "label51";
            this.lblPrice10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPrice10.Visible = false;
            // 
            // lblQty10
            // 
            this.lblQty10.AutoSize = true;
            this.lblQty10.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQty10.Location = new System.Drawing.Point(219, 261);
            this.lblQty10.Name = "lblQty10";
            this.lblQty10.Size = new System.Drawing.Size(52, 18);
            this.lblQty10.TabIndex = 48;
            this.lblQty10.Text = "label50";
            this.lblQty10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblQty10.Visible = false;
            // 
            // lblItem10
            // 
            this.lblItem10.AutoSize = true;
            this.lblItem10.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItem10.Location = new System.Drawing.Point(111, 261);
            this.lblItem10.Name = "lblItem10";
            this.lblItem10.Size = new System.Drawing.Size(52, 18);
            this.lblItem10.TabIndex = 47;
            this.lblItem10.Text = "label49";
            this.lblItem10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblItem10.Visible = false;
            // 
            // lblPrice9
            // 
            this.lblPrice9.AutoSize = true;
            this.lblPrice9.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice9.Location = new System.Drawing.Point(291, 232);
            this.lblPrice9.Name = "lblPrice9";
            this.lblPrice9.Size = new System.Drawing.Size(52, 18);
            this.lblPrice9.TabIndex = 46;
            this.lblPrice9.Text = "label48";
            this.lblPrice9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPrice9.Visible = false;
            // 
            // lblQty9
            // 
            this.lblQty9.AutoSize = true;
            this.lblQty9.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQty9.Location = new System.Drawing.Point(219, 232);
            this.lblQty9.Name = "lblQty9";
            this.lblQty9.Size = new System.Drawing.Size(52, 18);
            this.lblQty9.TabIndex = 45;
            this.lblQty9.Text = "label47";
            this.lblQty9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblQty9.Visible = false;
            // 
            // lblItem9
            // 
            this.lblItem9.AutoSize = true;
            this.lblItem9.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItem9.Location = new System.Drawing.Point(111, 232);
            this.lblItem9.Name = "lblItem9";
            this.lblItem9.Size = new System.Drawing.Size(52, 18);
            this.lblItem9.TabIndex = 44;
            this.lblItem9.Text = "label46";
            this.lblItem9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblItem9.Visible = false;
            // 
            // lblPrice8
            // 
            this.lblPrice8.AutoSize = true;
            this.lblPrice8.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice8.Location = new System.Drawing.Point(291, 203);
            this.lblPrice8.Name = "lblPrice8";
            this.lblPrice8.Size = new System.Drawing.Size(52, 18);
            this.lblPrice8.TabIndex = 43;
            this.lblPrice8.Text = "label45";
            this.lblPrice8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPrice8.Visible = false;
            // 
            // lblQty8
            // 
            this.lblQty8.AutoSize = true;
            this.lblQty8.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQty8.Location = new System.Drawing.Point(219, 203);
            this.lblQty8.Name = "lblQty8";
            this.lblQty8.Size = new System.Drawing.Size(52, 18);
            this.lblQty8.TabIndex = 42;
            this.lblQty8.Text = "label44";
            this.lblQty8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblQty8.Visible = false;
            // 
            // lblItem8
            // 
            this.lblItem8.AutoSize = true;
            this.lblItem8.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItem8.Location = new System.Drawing.Point(111, 203);
            this.lblItem8.Name = "lblItem8";
            this.lblItem8.Size = new System.Drawing.Size(52, 18);
            this.lblItem8.TabIndex = 41;
            this.lblItem8.Text = "label43";
            this.lblItem8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblItem8.Visible = false;
            // 
            // lblPrice7
            // 
            this.lblPrice7.AutoSize = true;
            this.lblPrice7.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice7.Location = new System.Drawing.Point(291, 174);
            this.lblPrice7.Name = "lblPrice7";
            this.lblPrice7.Size = new System.Drawing.Size(52, 18);
            this.lblPrice7.TabIndex = 40;
            this.lblPrice7.Text = "label42";
            this.lblPrice7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPrice7.Visible = false;
            // 
            // lblQty7
            // 
            this.lblQty7.AutoSize = true;
            this.lblQty7.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQty7.Location = new System.Drawing.Point(219, 174);
            this.lblQty7.Name = "lblQty7";
            this.lblQty7.Size = new System.Drawing.Size(52, 18);
            this.lblQty7.TabIndex = 39;
            this.lblQty7.Text = "label41";
            this.lblQty7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblQty7.Visible = false;
            // 
            // lblItem7
            // 
            this.lblItem7.AutoSize = true;
            this.lblItem7.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItem7.Location = new System.Drawing.Point(111, 174);
            this.lblItem7.Name = "lblItem7";
            this.lblItem7.Size = new System.Drawing.Size(52, 18);
            this.lblItem7.TabIndex = 38;
            this.lblItem7.Text = "label40";
            this.lblItem7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblItem7.Visible = false;
            // 
            // lblPrice6
            // 
            this.lblPrice6.AutoSize = true;
            this.lblPrice6.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice6.Location = new System.Drawing.Point(291, 145);
            this.lblPrice6.Name = "lblPrice6";
            this.lblPrice6.Size = new System.Drawing.Size(52, 18);
            this.lblPrice6.TabIndex = 37;
            this.lblPrice6.Text = "label39";
            this.lblPrice6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPrice6.Visible = false;
            // 
            // lblQty6
            // 
            this.lblQty6.AutoSize = true;
            this.lblQty6.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQty6.Location = new System.Drawing.Point(219, 145);
            this.lblQty6.Name = "lblQty6";
            this.lblQty6.Size = new System.Drawing.Size(52, 18);
            this.lblQty6.TabIndex = 36;
            this.lblQty6.Text = "label38";
            this.lblQty6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblQty6.Visible = false;
            // 
            // lblItem6
            // 
            this.lblItem6.AutoSize = true;
            this.lblItem6.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItem6.Location = new System.Drawing.Point(111, 145);
            this.lblItem6.Name = "lblItem6";
            this.lblItem6.Size = new System.Drawing.Size(52, 18);
            this.lblItem6.TabIndex = 35;
            this.lblItem6.Text = "label37";
            this.lblItem6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblItem6.Visible = false;
            // 
            // lblPrice5
            // 
            this.lblPrice5.AutoSize = true;
            this.lblPrice5.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice5.Location = new System.Drawing.Point(291, 116);
            this.lblPrice5.Name = "lblPrice5";
            this.lblPrice5.Size = new System.Drawing.Size(52, 18);
            this.lblPrice5.TabIndex = 34;
            this.lblPrice5.Text = "label36";
            this.lblPrice5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPrice5.Visible = false;
            // 
            // lblQty5
            // 
            this.lblQty5.AutoSize = true;
            this.lblQty5.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQty5.Location = new System.Drawing.Point(219, 116);
            this.lblQty5.Name = "lblQty5";
            this.lblQty5.Size = new System.Drawing.Size(52, 18);
            this.lblQty5.TabIndex = 33;
            this.lblQty5.Text = "label35";
            this.lblQty5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblQty5.Visible = false;
            // 
            // lblItem5
            // 
            this.lblItem5.AutoSize = true;
            this.lblItem5.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItem5.Location = new System.Drawing.Point(111, 116);
            this.lblItem5.Name = "lblItem5";
            this.lblItem5.Size = new System.Drawing.Size(52, 18);
            this.lblItem5.TabIndex = 32;
            this.lblItem5.Text = "label34";
            this.lblItem5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblItem5.Visible = false;
            // 
            // lblPrice4
            // 
            this.lblPrice4.AutoSize = true;
            this.lblPrice4.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice4.Location = new System.Drawing.Point(291, 87);
            this.lblPrice4.Name = "lblPrice4";
            this.lblPrice4.Size = new System.Drawing.Size(52, 18);
            this.lblPrice4.TabIndex = 31;
            this.lblPrice4.Text = "label33";
            this.lblPrice4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPrice4.Visible = false;
            // 
            // lblQty4
            // 
            this.lblQty4.AutoSize = true;
            this.lblQty4.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQty4.Location = new System.Drawing.Point(219, 87);
            this.lblQty4.Name = "lblQty4";
            this.lblQty4.Size = new System.Drawing.Size(52, 18);
            this.lblQty4.TabIndex = 30;
            this.lblQty4.Text = "label32";
            this.lblQty4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblQty4.Visible = false;
            // 
            // lblItem4
            // 
            this.lblItem4.AutoSize = true;
            this.lblItem4.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItem4.Location = new System.Drawing.Point(111, 87);
            this.lblItem4.Name = "lblItem4";
            this.lblItem4.Size = new System.Drawing.Size(52, 18);
            this.lblItem4.TabIndex = 29;
            this.lblItem4.Text = "label31";
            this.lblItem4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblItem4.Visible = false;
            // 
            // lblPrice3
            // 
            this.lblPrice3.AutoSize = true;
            this.lblPrice3.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice3.Location = new System.Drawing.Point(291, 58);
            this.lblPrice3.Name = "lblPrice3";
            this.lblPrice3.Size = new System.Drawing.Size(52, 18);
            this.lblPrice3.TabIndex = 28;
            this.lblPrice3.Text = "label30";
            this.lblPrice3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPrice3.Visible = false;
            // 
            // lblQty3
            // 
            this.lblQty3.AutoSize = true;
            this.lblQty3.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQty3.Location = new System.Drawing.Point(219, 58);
            this.lblQty3.Name = "lblQty3";
            this.lblQty3.Size = new System.Drawing.Size(52, 18);
            this.lblQty3.TabIndex = 27;
            this.lblQty3.Text = "label29";
            this.lblQty3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblQty3.Visible = false;
            // 
            // lblItem3
            // 
            this.lblItem3.AutoSize = true;
            this.lblItem3.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItem3.Location = new System.Drawing.Point(111, 58);
            this.lblItem3.Name = "lblItem3";
            this.lblItem3.Size = new System.Drawing.Size(52, 18);
            this.lblItem3.TabIndex = 26;
            this.lblItem3.Text = "label28";
            this.lblItem3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblItem3.Visible = false;
            // 
            // lblPrice2
            // 
            this.lblPrice2.AutoSize = true;
            this.lblPrice2.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice2.Location = new System.Drawing.Point(291, 29);
            this.lblPrice2.Name = "lblPrice2";
            this.lblPrice2.Size = new System.Drawing.Size(52, 18);
            this.lblPrice2.TabIndex = 25;
            this.lblPrice2.Text = "label27";
            this.lblPrice2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPrice2.Visible = false;
            // 
            // lblQty2
            // 
            this.lblQty2.AutoSize = true;
            this.lblQty2.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQty2.Location = new System.Drawing.Point(219, 29);
            this.lblQty2.Name = "lblQty2";
            this.lblQty2.Size = new System.Drawing.Size(52, 18);
            this.lblQty2.TabIndex = 24;
            this.lblQty2.Text = "label26";
            this.lblQty2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblQty2.Visible = false;
            // 
            // lblItem2
            // 
            this.lblItem2.AutoSize = true;
            this.lblItem2.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItem2.Location = new System.Drawing.Point(111, 29);
            this.lblItem2.Name = "lblItem2";
            this.lblItem2.Size = new System.Drawing.Size(52, 18);
            this.lblItem2.TabIndex = 23;
            this.lblItem2.Text = "label25";
            this.lblItem2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblItem2.Visible = false;
            // 
            // lblPrice1
            // 
            this.lblPrice1.AutoSize = true;
            this.lblPrice1.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice1.Location = new System.Drawing.Point(291, 0);
            this.lblPrice1.Name = "lblPrice1";
            this.lblPrice1.Size = new System.Drawing.Size(52, 18);
            this.lblPrice1.TabIndex = 22;
            this.lblPrice1.Text = "label24";
            this.lblPrice1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPrice1.Visible = false;
            // 
            // lblQty1
            // 
            this.lblQty1.AutoSize = true;
            this.lblQty1.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQty1.Location = new System.Drawing.Point(219, 0);
            this.lblQty1.Name = "lblQty1";
            this.lblQty1.Size = new System.Drawing.Size(52, 18);
            this.lblQty1.TabIndex = 21;
            this.lblQty1.Text = "label23";
            this.lblQty1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblQty1.Visible = false;
            // 
            // btnDelete4
            // 
            this.btnDelete4.Location = new System.Drawing.Point(57, 90);
            this.btnDelete4.Name = "btnDelete4";
            this.btnDelete4.Size = new System.Drawing.Size(48, 23);
            this.btnDelete4.TabIndex = 16;
            this.btnDelete4.Text = "Delete";
            this.btnDelete4.UseVisualStyleBackColor = true;
            this.btnDelete4.Visible = false;
            this.btnDelete4.Click += new System.EventHandler(this.btnDelete4_Click);
            // 
            // btnUpdate4
            // 
            this.btnUpdate4.Location = new System.Drawing.Point(3, 90);
            this.btnUpdate4.Name = "btnUpdate4";
            this.btnUpdate4.Size = new System.Drawing.Size(48, 23);
            this.btnUpdate4.TabIndex = 15;
            this.btnUpdate4.Text = "Update";
            this.btnUpdate4.UseVisualStyleBackColor = true;
            // 
            // btnDelete3
            // 
            this.btnDelete3.Location = new System.Drawing.Point(57, 61);
            this.btnDelete3.Name = "btnDelete3";
            this.btnDelete3.Size = new System.Drawing.Size(48, 23);
            this.btnDelete3.TabIndex = 11;
            this.btnDelete3.Text = "Delete";
            this.btnDelete3.UseVisualStyleBackColor = true;
            this.btnDelete3.Visible = false;
            this.btnDelete3.Click += new System.EventHandler(this.btnDelete3_Click);
            // 
            // btnUpdate3
            // 
            this.btnUpdate3.Location = new System.Drawing.Point(3, 61);
            this.btnUpdate3.Name = "btnUpdate3";
            this.btnUpdate3.Size = new System.Drawing.Size(48, 23);
            this.btnUpdate3.TabIndex = 10;
            this.btnUpdate3.Text = "Update";
            this.btnUpdate3.UseVisualStyleBackColor = true;
            // 
            // btnDelete2
            // 
            this.btnDelete2.Location = new System.Drawing.Point(57, 32);
            this.btnDelete2.Name = "btnDelete2";
            this.btnDelete2.Size = new System.Drawing.Size(48, 23);
            this.btnDelete2.TabIndex = 6;
            this.btnDelete2.Text = "Delete";
            this.btnDelete2.UseVisualStyleBackColor = true;
            this.btnDelete2.Visible = false;
            this.btnDelete2.Click += new System.EventHandler(this.btnDelete2_Click);
            // 
            // btnUpdate2
            // 
            this.btnUpdate2.Location = new System.Drawing.Point(3, 32);
            this.btnUpdate2.Name = "btnUpdate2";
            this.btnUpdate2.Size = new System.Drawing.Size(48, 23);
            this.btnUpdate2.TabIndex = 5;
            this.btnUpdate2.Text = "Update";
            this.btnUpdate2.UseVisualStyleBackColor = true;
            // 
            // btnDelete1
            // 
            this.btnDelete1.Location = new System.Drawing.Point(57, 3);
            this.btnDelete1.Name = "btnDelete1";
            this.btnDelete1.Size = new System.Drawing.Size(48, 23);
            this.btnDelete1.TabIndex = 1;
            this.btnDelete1.Text = "Delete";
            this.btnDelete1.UseVisualStyleBackColor = true;
            this.btnDelete1.Visible = false;
            this.btnDelete1.Click += new System.EventHandler(this.btnDelete1_Click);
            // 
            // btnUpdate1
            // 
            this.btnUpdate1.Location = new System.Drawing.Point(3, 3);
            this.btnUpdate1.Name = "btnUpdate1";
            this.btnUpdate1.Size = new System.Drawing.Size(48, 23);
            this.btnUpdate1.TabIndex = 0;
            this.btnUpdate1.Text = "Update";
            this.btnUpdate1.UseVisualStyleBackColor = true;
            this.btnUpdate1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnUpdate5
            // 
            this.btnUpdate5.Location = new System.Drawing.Point(3, 119);
            this.btnUpdate5.Name = "btnUpdate5";
            this.btnUpdate5.Size = new System.Drawing.Size(48, 23);
            this.btnUpdate5.TabIndex = 2;
            this.btnUpdate5.Text = "Update";
            this.btnUpdate5.UseVisualStyleBackColor = true;
            // 
            // btnUpdate6
            // 
            this.btnUpdate6.Location = new System.Drawing.Point(3, 148);
            this.btnUpdate6.Name = "btnUpdate6";
            this.btnUpdate6.Size = new System.Drawing.Size(48, 23);
            this.btnUpdate6.TabIndex = 7;
            this.btnUpdate6.Text = "Update";
            this.btnUpdate6.UseVisualStyleBackColor = true;
            // 
            // btnDelete5
            // 
            this.btnDelete5.Location = new System.Drawing.Point(57, 119);
            this.btnDelete5.Name = "btnDelete5";
            this.btnDelete5.Size = new System.Drawing.Size(48, 23);
            this.btnDelete5.TabIndex = 12;
            this.btnDelete5.Text = "Delete";
            this.btnDelete5.UseVisualStyleBackColor = true;
            this.btnDelete5.Visible = false;
            this.btnDelete5.Click += new System.EventHandler(this.btnDelete5_Click);
            // 
            // btnDelete6
            // 
            this.btnDelete6.Location = new System.Drawing.Point(57, 148);
            this.btnDelete6.Name = "btnDelete6";
            this.btnDelete6.Size = new System.Drawing.Size(48, 23);
            this.btnDelete6.TabIndex = 17;
            this.btnDelete6.Text = "Delete";
            this.btnDelete6.UseVisualStyleBackColor = true;
            this.btnDelete6.Visible = false;
            this.btnDelete6.Click += new System.EventHandler(this.btnDelete6_Click);
            // 
            // btnUpdate8
            // 
            this.btnUpdate8.Location = new System.Drawing.Point(3, 206);
            this.btnUpdate8.Name = "btnUpdate8";
            this.btnUpdate8.Size = new System.Drawing.Size(48, 23);
            this.btnUpdate8.TabIndex = 3;
            this.btnUpdate8.Text = "Update";
            this.btnUpdate8.UseVisualStyleBackColor = true;
            // 
            // btnUpdate7
            // 
            this.btnUpdate7.Location = new System.Drawing.Point(3, 177);
            this.btnUpdate7.Name = "btnUpdate7";
            this.btnUpdate7.Size = new System.Drawing.Size(48, 23);
            this.btnUpdate7.TabIndex = 8;
            this.btnUpdate7.Text = "Update";
            this.btnUpdate7.UseVisualStyleBackColor = true;
            // 
            // btnUpdate9
            // 
            this.btnUpdate9.Location = new System.Drawing.Point(3, 235);
            this.btnUpdate9.Name = "btnUpdate9";
            this.btnUpdate9.Size = new System.Drawing.Size(48, 23);
            this.btnUpdate9.TabIndex = 13;
            this.btnUpdate9.Text = "Update";
            this.btnUpdate9.UseVisualStyleBackColor = true;
            // 
            // btnUpdate10
            // 
            this.btnUpdate10.Location = new System.Drawing.Point(3, 264);
            this.btnUpdate10.Name = "btnUpdate10";
            this.btnUpdate10.Size = new System.Drawing.Size(48, 23);
            this.btnUpdate10.TabIndex = 18;
            this.btnUpdate10.Text = "Update";
            this.btnUpdate10.UseVisualStyleBackColor = true;
            // 
            // btnDelete7
            // 
            this.btnDelete7.Location = new System.Drawing.Point(57, 177);
            this.btnDelete7.Name = "btnDelete7";
            this.btnDelete7.Size = new System.Drawing.Size(48, 23);
            this.btnDelete7.TabIndex = 4;
            this.btnDelete7.Text = "Delete";
            this.btnDelete7.UseVisualStyleBackColor = true;
            this.btnDelete7.Visible = false;
            this.btnDelete7.Click += new System.EventHandler(this.btnDelete7_Click);
            // 
            // btnDelete8
            // 
            this.btnDelete8.Location = new System.Drawing.Point(57, 206);
            this.btnDelete8.Name = "btnDelete8";
            this.btnDelete8.Size = new System.Drawing.Size(48, 23);
            this.btnDelete8.TabIndex = 9;
            this.btnDelete8.Text = "Delete";
            this.btnDelete8.UseVisualStyleBackColor = true;
            this.btnDelete8.Visible = false;
            this.btnDelete8.Click += new System.EventHandler(this.btnDelete8_Click);
            // 
            // btnDelete9
            // 
            this.btnDelete9.Location = new System.Drawing.Point(57, 235);
            this.btnDelete9.Name = "btnDelete9";
            this.btnDelete9.Size = new System.Drawing.Size(48, 23);
            this.btnDelete9.TabIndex = 19;
            this.btnDelete9.Text = "Delete";
            this.btnDelete9.UseVisualStyleBackColor = true;
            this.btnDelete9.Visible = false;
            this.btnDelete9.Click += new System.EventHandler(this.btnDelete9_Click);
            // 
            // btnDelete10
            // 
            this.btnDelete10.Location = new System.Drawing.Point(57, 264);
            this.btnDelete10.Name = "btnDelete10";
            this.btnDelete10.Size = new System.Drawing.Size(48, 23);
            this.btnDelete10.TabIndex = 14;
            this.btnDelete10.Text = "Delete";
            this.btnDelete10.UseVisualStyleBackColor = true;
            this.btnDelete10.Visible = false;
            this.btnDelete10.Click += new System.EventHandler(this.btnDelete10_Click);
            // 
            // lblItem1
            // 
            this.lblItem1.AutoSize = true;
            this.lblItem1.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItem1.Location = new System.Drawing.Point(111, 0);
            this.lblItem1.Name = "lblItem1";
            this.lblItem1.Size = new System.Drawing.Size(52, 18);
            this.lblItem1.TabIndex = 20;
            this.lblItem1.Text = "label22";
            this.lblItem1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblItem1.Visible = false;
            // 
            // btnConfirm
            // 
            this.btnConfirm.Location = new System.Drawing.Point(291, 311);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(69, 23);
            this.btnConfirm.TabIndex = 50;
            this.btnConfirm.Text = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // button15
            // 
            this.button15.FlatAppearance.BorderSize = 0;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold);
            this.button15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.button15.Location = new System.Drawing.Point(747, 3);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(119, 30);
            this.button15.TabIndex = 18;
            this.button15.Text = "DashBoard";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // lblTotalBill
            // 
            this.lblTotalBill.AutoSize = true;
            this.lblTotalBill.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalBill.Location = new System.Drawing.Point(291, 290);
            this.lblTotalBill.Name = "lblTotalBill";
            this.lblTotalBill.Size = new System.Drawing.Size(27, 18);
            this.lblTotalBill.TabIndex = 52;
            this.lblTotalBill.Text = "0.0";
            this.lblTotalBill.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Centaur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(111, 290);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(42, 18);
            this.label22.TabIndex = 53;
            this.label22.Text = "Total";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Sale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1211, 647);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.MaximizeBox = false;
            this.Name = "Sale";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sale";
            this.Load += new System.EventHandler(this.Sale_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtMobile;
        private System.Windows.Forms.TextBox txtPQuantity;
        private System.Windows.Forms.TextBox txtUnitPrice;
        private System.Windows.Forms.TextBox txtTotalStock;
        private System.Windows.Forms.TextBox txtMeasuringnUnit;
        private System.Windows.Forms.TextBox txtProdDesc;
        private System.Windows.Forms.TextBox txtProdType;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtOrderId;
        private System.Windows.Forms.ComboBox cmbItemName;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtBill;
        private System.Windows.Forms.TextBox txtDiscount;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtafterdiscbill;
        private System.Windows.Forms.TextBox txtActualPrice;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button btnDelete4;
        private System.Windows.Forms.Button btnUpdate4;
        private System.Windows.Forms.Button btnDelete3;
        private System.Windows.Forms.Button btnUpdate3;
        private System.Windows.Forms.Button btnDelete2;
        private System.Windows.Forms.Button btnUpdate2;
        private System.Windows.Forms.Button btnDelete1;
        private System.Windows.Forms.Button btnUpdate1;
        private System.Windows.Forms.Button btnUpdate5;
        private System.Windows.Forms.Button btnUpdate6;
        private System.Windows.Forms.Button btnDelete5;
        private System.Windows.Forms.Button btnDelete6;
        private System.Windows.Forms.Button btnUpdate8;
        private System.Windows.Forms.Button btnUpdate7;
        private System.Windows.Forms.Button btnUpdate9;
        private System.Windows.Forms.Button btnUpdate10;
        private System.Windows.Forms.Button btnDelete7;
        private System.Windows.Forms.Button btnDelete8;
        private System.Windows.Forms.Button btnDelete9;
        private System.Windows.Forms.Button btnDelete10;
        private System.Windows.Forms.Label lblPrice10;
        private System.Windows.Forms.Label lblQty10;
        private System.Windows.Forms.Label lblItem10;
        private System.Windows.Forms.Label lblPrice9;
        private System.Windows.Forms.Label lblQty9;
        private System.Windows.Forms.Label lblItem9;
        private System.Windows.Forms.Label lblPrice8;
        private System.Windows.Forms.Label lblQty8;
        private System.Windows.Forms.Label lblItem8;
        private System.Windows.Forms.Label lblPrice7;
        private System.Windows.Forms.Label lblQty7;
        private System.Windows.Forms.Label lblItem7;
        private System.Windows.Forms.Label lblPrice6;
        private System.Windows.Forms.Label lblQty6;
        private System.Windows.Forms.Label lblItem6;
        private System.Windows.Forms.Label lblPrice5;
        private System.Windows.Forms.Label lblQty5;
        private System.Windows.Forms.Label lblItem5;
        private System.Windows.Forms.Label lblPrice4;
        private System.Windows.Forms.Label lblQty4;
        private System.Windows.Forms.Label lblItem4;
        private System.Windows.Forms.Label lblPrice3;
        private System.Windows.Forms.Label lblQty3;
        private System.Windows.Forms.Label lblItem3;
        private System.Windows.Forms.Label lblPrice2;
        private System.Windows.Forms.Label lblQty2;
        private System.Windows.Forms.Label lblItem2;
        private System.Windows.Forms.Label lblPrice1;
        private System.Windows.Forms.Label lblQty1;
        private System.Windows.Forms.Label lblItem1;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Label lblTotalBill;
        private System.Windows.Forms.Label label22;
    }
}